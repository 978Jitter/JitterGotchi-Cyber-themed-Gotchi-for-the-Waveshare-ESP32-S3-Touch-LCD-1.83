# Features that must always be present (enforced by check_features.sh)

1. **Clock** - TIME opens the clock directly in set mode with FOUR buttons: `+1`, `H/M` (hour -> minute -> second),
   `RUN` (apply + back to face), `CAL` (calibrate touch, then back to face). Never "FACE / FACE / FACE".
   Leaving without edits does not move the time backwards (it catches up by the seconds spent there).
2. **Time persists** - RTC when valid; otherwise the saved wall-clock (NVS `jitter_clk`, saved every 60 s and on every
   save). The clock screen shows `RTC OK` / `RTC LOST POWER - USING SAVED TIME` / `NO RTC CHIP FOUND`.
3. **XP persists** - NVS `jitter_xp` key `v` is a plain u32 (never use getBytesLength on it); saved within ~10 s.
4. **Foraging (Wi-Fi food)** - `JG_WIFI_FOOD 1` and `JG_WIFI_HARD 1`.
5. **Dimming** - backlight dims whenever the pet's lights are off.
6. **Battery bar** - shown on the main screen.
7. **Touch calibration** - 2-point, saved in NVS `jitter_cal`.

S3 specifics: battery comes from the AXP2101 power chip (I2C 0x34): percent from its fuel gauge, with a voltage
fallback; shows `USB` when running without a battery. Bar is in the top-right of the main screen.
Dimming: lights off = level 25 always; plus the existing idle dim after 2 min without a touch.
