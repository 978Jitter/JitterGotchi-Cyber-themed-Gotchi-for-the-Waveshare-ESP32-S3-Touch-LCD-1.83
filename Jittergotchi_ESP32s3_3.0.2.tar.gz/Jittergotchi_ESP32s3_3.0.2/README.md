# JitterGotchi for Waveshare ESP32-S3-Touch-LCD-1.83 (240x284)

```
bash build.sh      # does everything: installs tools on first run, checks features, builds, uploads
bash flash.sh      # re-flash firmware_bin/ later (auto-rebuilds if stale)
bash monitor.sh    # serial log
```
You never need to edit anything in this folder to use it. See FEATURES.md for what is guaranteed.
If the board is not detected: hold BOOT, tap RESET, release BOOT, then run again.

## What changed from the original port
- **Clock:** TIME opens the clock straight into set mode with four buttons: `+1`, `H/M` (hour/minute/second),
  `RUN` (apply, back to face), `CAL` (calibrate touch, back to face). BOOT button: hold 1.4 s = CAL on the clock screen.
- **Battery bar** (AXP2101) in the top-right of the main screen.
- **XP persists** across power-off (the load bug is fixed) and is saved within ~10 s.
- **Time persists** (RTC if valid, else saved wall-clock); the clock screen shows the RTC state.
- **Dimming** whenever the lights are off.
- Foraging (Wi-Fi food) stays on.

The rest of the original manual follows.

---

Port of the JitterBox6 pet (same species, evolutions, decay, XP and NVS save
format) to the Waveshare 1.83" SPI screen (ST7789P + CST816D). The UI is laid out
landscape (284x240), rotated 90 deg clockwise. Pins come from Waveshare's own `pin_config.h`.

> Not yet confirmed on hardware. On boot you should see a red/green/blue flash
> test, then the pet. If something is off, see Troubleshooting. Every
> fix is a one-line `#define` at the top of `JitterGotchi/JitterGotchi.ino`.

## Quick start (Kali)

```bash
unzip JitterGotchi.zip && cd JitterGotchi_pkg
./setup.sh        # once: arduino-cli + ESP32 core + display library
./flash.sh        # compile + upload (auto-detects /dev/ttyACM0)
./monitor.sh      # optional serial log
```

If `setup.sh` says it added you to `dialout`, log out/in once (or reboot).
If the board isn't detected: hold **BOOT**, tap **RESET**, release BOOT, then
run `./flash.sh` again.

First build downloads the ESP32 toolchain (a few hundred MB), so the first
run takes a while.

## Controls

| Action | Touch | BOOT button (GPIO0) |
|---|---|---|
| A (cycle icon / left) | tap lower-left | single tap |
| B (select / middle) | tap lower-middle | double tap |
| C (clear / back) | tap lower-right | hold 0.55 s |
| A+C combo (set clock, new egg) | **hold lower-middle 1 s** | hold 1.4 s |
| Pick icon directly | tap icon in top strip (tap twice to run it) | - |

Icons, left to right: FD feed, GM game, DF defrag, LT lights, PT patch,
SC scold, ST stats. The selected icon's full name shows above the strip.

## Differences from JitterBox6

- **Food**: no nRF24/CC1101, so "RF signals" come from passive Wi-Fi scans
  every 45 s (more networks seen = more food + XP). Set `JG_WIFI_FOOD 0` to
  turn it off; feeding from the menu still works.
- **Saves**: NVS only (same keys as before). The SD backup file is gone. Your
  old pet does not transfer from the ESP32-DIV, so this starts a new egg.
- **XP** is written to flash in batches (max once a minute) to spare the flash.
- **Backlight** dims when the pet sleeps with lights off.
- Removed: radios, IR, USB-HID/Ducky, NeoPixel health LEDs.
- Serial: the `J` pet commands and `Y<xp>` (JitterFood) still work.
  Extra debug keys: `s` status, `d` touch debug, `i` I2C scan, `r` fake 25
  signals. `JT` cycles time speed 1x/10x/60x (handy for testing evolutions).

## Settings (top of JitterGotchi.ino)

| Define | Meaning |
|---|---|
| `JG_ROTATION` | 1 = landscape, 90 deg clockwise (default). 3 = the other landscape (use if upside-down). |
| `JG_IPS_PANEL` | flip 1<->0 if colors look inverted |
| `JG_TOUCH_SWAP_XY / FLIP_X / FLIP_Y` | fix touch if taps land mirrored/rotated |
| `JG_WIFI_FOOD` | Wi-Fi scan feeding on/off |

Pins (LCD_DC 4, CS 5, SCK 6, MOSI 7, RST 38, BL 40, I2C 15/14, TP_RST 39,
TP_INT 13) live in `JitterGotchi/pin_config.h`, copied from Waveshare's demo.

## Petting, upside-down, 5 hearts

- **Petting:** touch him anywhere between the icon strip and the buttons. He squints, shakes
  happily and throws red sparks, with a little chirp. Holding for 2 s gives +1 happy (at most once
  a minute; `JG_PET_HAPPY 0` turns the reward off).
- **Upside-down:** turn the device over and he falls to the screen's top edge (the new floor),
  bounces and squashes with a thud. The title strip hides while he is up there. Flip back and he
  falls back down. He learns which way is "upright" from how you hold him (slow average, so start him upright), so the sensor mounting doesn't matter. Press `g` in the
  serial monitor to see the live sensor values.
- **Hearts:** hunger and happy now go up to 5 (`JG_MAX_HEARTS`). Saved pets keep their current
  hearts and can fill up to 5.

## Tuning knobs (top of JitterGotchi.ino)

| Define | What it does |
|---|---|
| `JG_GENTLE` | 1 = kid-friendly: calls last 45 min, 14 care mistakes before death, sickness kills after 8 h, hearts/fragments 25% slower |
| `JG_QUIET_HOURS/START/END` | no alert or event sounds between 21:00 and 07:00 (pet clock). Button sounds still work |
| `JG_DIM_MS / JG_DIM_LEVEL` | dim the backlight after 2 min with no touch; any touch wakes it |
| `JG_WIFI_SCAN_MS` | scan every 2.5 min |
| `JG_SIGNALS_PER_HEART`, `JG_FORAGE_MS` | foraging balance: 20 fresh signals per heart, networks pay again after 45 min |
| `JG_IMU`, `JG_IMU_INVERT` | tilt slides his eyes, flip = he falls. Flip `JG_IMU_INVERT` if the eyes slide the wrong way |
| `JG_SHAKE` | OFF by default. 1 = shaking makes him dizzy (3 spells in 2 min = cranky, -1 happy) |
| `JG_CATCHUP_MAX_SEC` | while switched off he ages at most this long (12 h) |

Real-time clock: the board's RTC keeps time while he is off. On boot the pet clock is set from
it and he is aged for the time away (hearts never drop below 1, at most one fragment, no sickness,
no deaths while off). The first time, set the clock once on the clock screen (hold the middle
button); that also sets the RTC. If the RTC has no backup battery it loses time on power-off
and he just resumes without catch-up.

While he sleeps a moon and drifting Zs appear as a night-light.

## Foraging (Wi-Fi food)

With `JG_WIFI_HARD 1` he only gets fed by networks he has not "tasted" recently
(`JG_FORAGE_MS`, 45 min). Each scan remembers a short hash of each network's hardware address
in RAM only (no names or addresses, forgotten on reboot). Fresh networks give XP and
count toward hunger only (20 signals = 1 heart). Sitting in one spot barely feeds him;
carrying him somewhere new does. Set `JG_WIFI_HARD 0` for the old easy mode.

## Sound (JitterAudio.h)

Synthesized cyber sound set played through the board's ES8311 codec and speaker:
boot, button ticks, feed/snack/defrag/lights/patch/scold, game win/lose/fanfare,
per-type alert calls (hungry / bored / lights / scold, repeated every
`JG_SND_REMIND_MS`), sickness, fragments, hatch, evolution, death, wake/sleep, and a
zap when he smashes into the wall. Wi-Fi scan reactions are silent on purpose. Output is capped at 80% of the original max level.
He is quiet while asleep (except the bedtime lights call).

- Tap the **title row** at the top of the screen to cycle volume (mute, 25, 50, 75, 100%).
- `JG_SOUND 0` turns all sound off at compile time.
- Serial keys in `./monitor.sh`: `t` plays every sound in turn (prints its name),
  `v` cycles volume, `k` tests the smash (left, right, down, up).
- (Off by default: set `JG_SMASH 1` to enable.) Touching a button makes him smash toward it: A = left wall, B = down, C = right,
  icon strip = up. Impact makes red static.

## Troubleshooting

- **Build error in `Arduino_ESP32LCD8.cpp` (`int8_t` to `gpio_num_t`)**: the ESP32 core is
  4.x. Run `arduino-cli core install esp32:esp32@3.3.5` (setup.sh pins this now).

- **Backlight but no picture**: you should see a red/green/blue flash at boot.
  If not, check serial for `display init failed`. PSRAM must be OPI (scripts
  set it; in Arduino IDE use PSRAM = OPI PSRAM, Flash = 16MB, USB CDC On Boot
  = Enabled). If the image is shifted or a strip is garbage, try row offset 20
  in the `Arduino_ST7789(...)` line (`0, 20, 0, 0`).
- **No sound**: check the serial log at boot for `AUDIO:` lines (ES8311 chip id should read 83 11).
  Press `t` in the monitor to test. Volume may be muted (tap the title row).
- **Colors inverted**: flip `JG_IPS_PANEL`.
- **Touch does nothing**: `./monitor.sh`, press `i` (expect 0x15 and others on
  the I2C bus), press `d` and tap to see coordinates; use `JG_TOUCH_*` flags.
  The BOOT button always works as a fallback.
- **Won't compile on library errors**: `arduino-cli lib install "GFX Library for Arduino"`.
