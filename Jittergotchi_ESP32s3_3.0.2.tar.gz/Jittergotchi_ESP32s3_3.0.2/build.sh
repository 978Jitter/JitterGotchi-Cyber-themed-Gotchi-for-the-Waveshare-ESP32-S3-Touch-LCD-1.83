#!/usr/bin/env bash
# Build JitterGotchi (S3) from source, check that no feature has regressed, refresh firmware_bin/, then upload.
#   bash build.sh [port]        compile + export + upload
#   NOUPLOAD=1 bash build.sh    compile + export only
# Everything needed is installed automatically the first time.
set -euo pipefail
export PATH="$HOME/.local/bin:$PATH"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FQBN="esp32:esp32:esp32s3:USBMode=hwcdc,CDCOnBoot=cdc,PSRAM=opi,FlashMode=qio,FlashSize=16M,PartitionScheme=app3M_fat9M_16MB"
SKETCH="$DIR/JitterGotchi"

# 1) environment (auto-runs setup.sh when anything is missing)
need=0
command -v arduino-cli >/dev/null 2>&1 || need=1
if [ "$need" = 0 ]; then
  arduino-cli core list 2>/dev/null | grep -q '^esp32:esp32' || need=1
  libs="$(arduino-cli lib list 2>/dev/null || true)"
  for l in "GFX Library for Arduino"; do echo "$libs" | grep -qi "$l" || need=1; done
fi
if [ "$need" = 1 ]; then echo "==> First-time setup (installing tools + libraries)..."; bash "$DIR/setup.sh"; fi

# 2) regression guard: refuses to build if a feature we added is missing from the code
bash "$DIR/check_features.sh"

# 3) compile + export binaries
arduino-cli compile --clean --export-binaries --fqbn "$FQBN" "$SKETCH"
mkdir -p "$DIR/firmware_bin"
rm -f "$DIR"/firmware_bin/*.bin
find "$SKETCH/build" -name 'JitterGotchi.ino*.bin' -exec cp {} "$DIR/firmware_bin/" \;
[ -f "$DIR/firmware_bin/JitterGotchi.ino.bin" ] || { echo "Export failed: no .bin found"; exit 1; }
echo "==> Fresh binaries in firmware_bin/:"; ls -l "$DIR/firmware_bin"

# 4) upload
if [ -z "${NOUPLOAD:-}" ]; then
  PORT="${1:-$(ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null | head -n 1 || true)}"
  if [ -n "$PORT" ]; then
    arduino-cli upload -p "$PORT" --fqbn "$FQBN" "$SKETCH"
    echo "==> Uploaded. Done."
  else
    echo "No serial port found - skipped upload (plug the board in and run: bash flash.sh)"
  fi
fi
