// =============================================================================
//  JITTERGOTCHI  -  Waveshare ESP32-S3-Touch-LCD-1.83 port (240x284 SPI)
//  Ported from JitterBox6 (ESP32-DIV v2.1 / ILI9341). Pet logic, species,
//  evolutions, decay timers, XP and NVS save format are unchanged.
//
//  What changed vs JitterBox6:
//    - Display : ST7789P 240x284, plain SPI (Arduino_GFX + PSRAM canvas)
//    - Touch   : CST816D over I2C (was XPT2046)
//    - Buttons : BOOT button (GPIO0) replaces the PCF8574 center button
//    - UI      : landscape 284x240 (JG_ROTATION 1 or 3)
//    - Removed : nRF24 / CC1101 / IR / USB-HID / SD / NeoPixels
//    - Food    : "RF signals" now come from passive Wi-Fi scans (optional)
//
//  BUILD (see README):  PSRAM = OPI, Flash = 16MB, USB CDC On Boot = enabled
// =============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>
#include <esp_system.h>
#include <Arduino_GFX_Library.h>

// ----------------------------------------------------------------------------
//  USER SETTINGS
// ----------------------------------------------------------------------------
#define JG_ROTATION      1   // landscape: 1 = 90 deg clockwise, 3 = 270 (flip if it's upside-down)
#define JG_WIFI_FOOD     1   // 1 = passive Wi-Fi scans feed the pet (+XP)
#define JG_WIFI_SCAN_MS  150000UL  // scan every 2.5 min (only new networks pay out, so no need for more)
#define JG_WIFI_HARD     1   // 1 = foraging: only NEW networks feed him, and only hunger (0 = old easy mode)
#define JG_FORAGE_MS     2700000UL   // a network can pay out again after this long (45 min)
#define JG_SIGNALS_PER_HEART 20      // fresh Wi-Fi signals needed for one hunger heart

#define JG_MAX_HEARTS    5   // hunger and happy hearts (was 4)
#define JG_PET_HAPPY     1   // 1 = petting him for 2 s gives +1 happy (at most once a minute)
#define JG_IMU_FLIP_INVERT 0 // flip if "upside down" is detected the wrong way round (use serial key g)
#define JG_GENTLE        1   // 1 = kid-friendly rules: slower drain, longer call timeouts, far fewer deaths
#define JG_QUIET_HOURS   1   // 1 = no alert/event sounds between START and END (pet-clock hours)
#define JG_QUIET_START   21
#define JG_QUIET_END     7
#define JG_DIM_MS        120000UL  // dim the screen after this long without a touch (0 = never)
#define JG_DIM_LEVEL     30        // dimmed backlight, 0..255
#define JG_IMU           1   // 1 = use the motion sensor: tilt slides his eyes, shaking makes him dizzy
#define JG_SHAKE         0   // 1 = shaking makes him dizzy (OFF: was triggering constantly)
#define JG_IMU_INVERT    0   // flip tilt direction if his eyes slide the wrong way
#define JG_CATCHUP_MAX_SEC 43200UL  // while powered off, age him at most this much (12 h)

#if JG_GENTLE
#define JG_ATTN_SEC        2700     // a call expires after 45 min (was 15)
#define JG_MAXCM           14       // care mistakes before he dies (was 9)
#define JG_MAXCM_ROT       10       // Rotbit (was 6)
#define JG_SICK_DEATH_SEC  28800UL  // untreated sickness kills after 8 h (was 4)
#define JG_SNACK_KILL      20       // snack overdose death threshold (was 12)
#define JG_DRAIN_NUM       5        // hearts and fragments come 25% slower
#define JG_DRAIN_DEN       4
#else
#define JG_ATTN_SEC        900
#define JG_MAXCM           9
#define JG_MAXCM_ROT       6
#define JG_SICK_DEATH_SEC  14400UL
#define JG_SNACK_KILL      12
#define JG_DRAIN_NUM       1
#define JG_DRAIN_DEN       1
#endif
#define JG_TOUCH_SWAP_XY 0   // touch axis fixes if taps land in the wrong place
#define JG_TOUCH_FLIP_X  0
#define JG_TOUCH_FLIP_Y  0
#define JG_IPS_PANEL     1   // if colors look inverted, flip this 1 <-> 0
#define JG_SMASH         0   // 1 = he smashes toward the button you press (red static + zap), 0 = off
#define JG_SOUND         1   // 1 = cyber sound set (ES8311 + speaker), 0 = silent
#define JG_SND_REMIND_MS 60000UL  // repeat an unanswered alert (hungry/bored/scold) this often

#if JG_WIFI_FOOD
#include <WiFi.h>
#endif

// ----------------------------------------------------------------------------
//  PINS - all LCD/touch pins come from Waveshare's own pin_config.h
//  (LCD_DC 4, LCD_CS 5, LCD_SCK 6, LCD_MOSI 7, LCD_RST 38, LCD_BL 40,
//   IIC_SDA 15, IIC_SCL 14, TP_RST 39, TP_INT 13)
// ----------------------------------------------------------------------------
#include "pin_config.h"

#if JG_SOUND
#include "JitterAudio.h"
#else
#define sndInit()        ((void)0)
#define sndPlay(x)       ((void)0)
#define sndCycleLevel()  ((void)0)
#endif

// (declared up here so Arduino's auto-generated prototypes can see it)
struct RtcTime { uint16_t y; uint8_t mo, d, h, mi, s; bool valid; };

#define TP_ADDR    0x15         // CST816D
#define TP_INT_PIN TP_INT
#define BOOT_BTN   0
#define PW 240          // panel native size (portrait)
#define PH 284
#define SW 284          // logical size after rotation (landscape) - layout uses these
#define SH 240
#if (JG_ROTATION != 1) && (JG_ROTATION != 3)
#error "JG_ROTATION must be 1 or 3 (layout is landscape)"
#endif

// ----------------------------------------------------------------------------
//  DISPLAY: SPI ST7789P -> PSRAM canvas -> flush  (same setup as Waveshare's
//  01_HelloWorld: Arduino_ESP32SPI + Arduino_ST7789, IPS, offsets 0,0,0,0)
// ----------------------------------------------------------------------------
Arduino_DataBus *bus   = new Arduino_ESP32SPI(LCD_DC, LCD_CS, LCD_SCK, LCD_MOSI);
Arduino_GFX     *panel = new Arduino_ST7789(bus, LCD_RST, 0 /*rot*/, JG_IPS_PANEL,
                                            PW, PH, 0, 0, 0, 0);
Arduino_Canvas  *gfx   = new Arduino_Canvas(PW, PH, panel);

bool frameDirty = true;
uint32_t lastFlushMs = 0;

// colors (RGB565), same palette as JitterBox
const uint16_t COL_BG      = 0x0841;
const uint16_t COL_PANEL   = 0x1082;
const uint16_t COL_ACCENT  = 0x98C5;
const uint16_t COL_CRIMSON = 0x6043;
const uint16_t COL_DIM     = 0x3186;
const uint16_t COL_SILVER  = 0xBE18;
const uint16_t COL_WHITE   = 0xF79E;
const uint16_t COL_AMBER   = 0xFD20;
const uint16_t JC_RED      = 0xF800;
const uint16_t JC_ORANGE   = 0xFD20;
const uint16_t JC_YELLOW   = 0xFFE0;
const uint16_t JC_GREEN    = 0x07E0;
const uint16_t JC_CYAN     = 0x07FF;
const uint16_t JC_MAGENTA  = 0xF81F;

// layout (logical, after rotation) - everything is kept inside the circle
#define ICON_X0   9
#define ICON_W    38
#define ICON_Y    28
#define ICON_H    26
#define BTN_Y     220
#define BTN_H     20
#define EYE_CLIP_Y0  58
#define EYE_CLIP_Y1  148

// ----------------------------------------------------------------------------
//  STATE
// ----------------------------------------------------------------------------
struct JitterXpState { uint32_t v; uint32_t magic; };
JitterXpState Jx;
static const uint32_t JX_MAGIC = 0x58505850UL;
bool jxDirty = false;
uint32_t jxLastSave = 0;

enum CyberSpecies : uint8_t {
  SP_EGG = 0, SP_BITLING, SP_BYTEKIN, SP_SYNTHRA, SP_GLITCHLING, SP_AEGIS9,
  SP_PROXYFOX, SP_NULLMIND, SP_HEXHOUND, SP_VOIDCRAWLER, SP_ROTBIT, SP_ARCHONX, SP_DEAD
};

enum MenuIcon : uint8_t {
  ICON_NONE = 0, ICON_FEED, ICON_GAME, ICON_CLEAN, ICON_LIGHT, ICON_MEDS, ICON_SCOLD, ICON_STATS, ICON_COUNT
};

enum UIScreen : uint8_t {
  SCR_MAIN = 0, SCR_FEED_MENU, SCR_GAME_HILO, SCR_STATS_1, SCR_STATS_2, SCR_CLOCK, SCR_DEAD
};

enum AttentionReason : uint8_t { ATT_NONE = 0, ATT_HUNGRY, ATT_HAPPY, ATT_SLEEP, ATT_DISCIPLINE };

enum CyberSickType : uint8_t { SICK_NONE = 0, SICK_CORRUPT, SICK_THERMAL, SICK_MALWARE };

static const char* const SICK_BADGE_TXT[4] = { "", "CRPT", "THRM", "WORM" };
static const char* const SICK_FULL_NAME[4] = { "HEALTHY", "CORRUPT", "THERMAL", "MALWARE" };

#define TAMA_MAGIC 0x47454E33UL   // same as JitterBox6 -> same NVS layout

struct TamaState {
  uint32_t magic;
  uint32_t id;
  uint8_t  species;
  uint8_t  hungry;
  uint8_t  happy;
  uint8_t  discipline;
  uint8_t  weightOz;
  uint8_t  careMistakes;
  uint8_t  totalMistakes;
  uint8_t  discMistakes;
  uint8_t  poopCount;
  uint8_t  sickDosesLeft;
  uint8_t  sickType;
  uint8_t  snackCount;
  uint8_t  lightsOff;
  uint8_t  sleeping;
  uint8_t  babyNapDone;
  uint8_t  babySickDone;
  uint8_t  deathCause;
  uint8_t  timeScale;
  uint8_t  clockHour;
  uint8_t  clockMin;
  uint8_t  clockSec;
  uint32_t ageSec;
  uint32_t stageSec;
  uint32_t hungryAccSec;
  uint32_t happyAccSec;
  uint32_t poopAccSec;
  uint32_t discCallAccSec;
  uint32_t sickAccSec;
  uint32_t attnTimerSec;
  uint8_t  attnReason;
  uint32_t rfSignals;
};

TamaState T;
Preferences tPrefs;
bool tDirty = false;
uint32_t tLastSave = 0;
uint32_t tLastTickMs = 0;
uint32_t alertAt = 0;           // when the current alert last sounded
uint32_t volShownAt = 0;        // title shows the volume for a moment after a change
uint32_t lastActivityMs = 0;    // last touch/button/shake (for screen dimming)
void markActivity() { lastActivityMs = millis(); }
static bool inQuietHours() {
#if JG_QUIET_HOURS
  uint8_t h = T.clockHour;
  return (JG_QUIET_START > JG_QUIET_END) ? (h >= JG_QUIET_START || h < JG_QUIET_END)
                                          : (h >= JG_QUIET_START && h < JG_QUIET_END);
#else
  return false;
#endif
}
#define sfxQuiet(id) do { if (!T.sleeping && !inQuietHours()) sndPlay(id); } while (0)   // not asleep / quiet hours

uint8_t uiScreen = SCR_MAIN;
uint8_t selIcon = ICON_NONE;
uint8_t feedChoice = 0;
bool clockSetMode = false;
uint8_t clockSetField = 0;
bool clockEdited = false;
uint32_t clockEnterMs = 0;
void runTouchCal();
bool uiNeedsFullRedraw = true;
bool uiHudDirty = true;

uint8_t gameRound = 0, gameWins = 0, gameLeftNum = 5, gameRightNum = 5, gameRevealState = 0;
uint32_t gameRevealAt = 0;
bool gameLastWon = false;

bool evoDanceActive = false;
uint32_t evoDanceStart = 0;
char evoBanner[28] = "";

static const char* const SP_NAME[13] = {
  "CYBER-EGG", "BITLING", "BYTEKIN", "SYNTHRA", "GLITCHLING",
  "AEGIS-9", "PROXYFOX", "NULLMIND", "HEXHOUND", "VOIDCRAWLER",
  "ROTBIT", "ARCHON-X", "CORE-DUMP"
};
static const uint8_t SP_BASE_WT[13]   = { 5, 5, 10, 20, 20, 30, 30, 30, 30, 30, 20, 30, 0 };
static const uint16_t SP_HEART_INT[13] = { 0, 240, 2700, 3600, 3000, 4800, 4200, 3600, 3900, 3300, 2400, 5400, 0 };
static const uint8_t SP_BED_HR[13]    = { 25, 25, 20, 21, 21, 22, 22, 22, 22, 22, 21, 23, 25 };
static const uint8_t SP_WAKE_HR[13]   = { 0, 0, 8, 8, 9, 8, 8, 9, 8, 9, 9, 8, 0 };

// ----------------------------------------------------------------------------
//  EYES
// ----------------------------------------------------------------------------
struct EyeHover { int16_t curX, curY, fromX, fromY, toX, toY; uint32_t moveStart, moveDur; };

const int16_t EYE_BASE_CX[2] = {96, 188};
const int16_t EYE_BASE_CY = 102;
const int16_t EYE_W = 52, EYE_H = 30;
const uint16_t EYE_FRAME_MS = 40;

EyeHover eyeHover[2];
uint32_t lastEyeFrame = 0;
bool eyeHasLastDraw = false;
int16_t lastDrawX[2], lastDrawY[2], lastDrawW[2], lastDrawH[2];
float eyeLid = 1.0f;
uint32_t eyeChompAt = 0;
bool eyeChomping = false;

// "smash into the wall" reaction when you press a button (direction = where you touched)
bool smashActive = false, smashHit = false;
uint32_t smashAt = 0;
int8_t smashDX = 0, smashDY = 0;
bool dizzyActive = false; uint32_t dizzyAt = 0;   // shaken
// upside-down gravity (eyes fall to the screen's top edge when the device is flipped)
bool flipped = false, flipMoving = false;
float flipOff = 0.0f, flipVel = 0.0f;
uint32_t flipImpactAt = 0;
int16_t gEyeTop = EYE_CLIP_Y0;                      // top of the eye area (0 while flipped)
// petting + red sparks
uint32_t petLastTouch = 0, petStart = 0, lastPetSnd = 0, lastPetReward = 0;
bool petRewarded = false;
uint8_t petBurst = 0;
bool eyeFast = false;
struct Spark { float x, y, vx, vy; uint32_t born; bool alive; int16_t dpx, dpy; bool drawn; };
Spark sparks[28];
uint32_t lastSparkT = 0;
int16_t eyeTiltPx = 0;                              // IMU tilt slide, set by serviceImu()
float gSqW = 1.0f, gSqH = 1.0f;                // squash factors used by drawEye
struct SRect { int16_t x, y, w, h; };
SRect staticR[2]; uint8_t staticN = 0;         // red static rectangles to erase next frame

void triggerSmash(int8_t dx, int8_t dy) {
  if (!JG_SMASH) return;
  if (uiScreen != SCR_MAIN || T.sleeping || T.species == SP_DEAD || evoDanceActive) return;
  smashActive = true; smashHit = false; smashAt = millis(); smashDX = dx; smashDY = dy;
}
// lx,ly = touch position in logical (landscape) coordinates
void triggerSmashAt(int16_t lx, int16_t ly) {
  if (ly >= BTN_Y - 10) {                        // bottom buttons: A=left, B=down, C=right
    if (lx < SW / 3) triggerSmash(-1, 0);
    else if (lx < (2 * SW) / 3) triggerSmash(0, 1);
    else triggerSmash(1, 0);
    return;
  }
  float nx = (lx - SW / 2) / (SW / 2.0f), ny = (ly - 102) / 110.0f;
  if (fabsf(nx) >= fabsf(ny)) triggerSmash(nx < 0 ? -1 : 1, 0);
  else                        triggerSmash(0, ny < 0 ? -1 : 1);
}

uint32_t eyeRfRxAt = 0;  bool eyeRfRxActive = false;
uint32_t eyeRfTxAt = 0;  bool eyeRfTxActive = false;
uint32_t eyeIrAt = 0;    bool eyeIrActive = false;
uint8_t rfFeedBurstAcc = 0;

void tamaClearAttention(uint8_t reason);
void tamaRaiseAttention(uint8_t reason);
void tamaSave();

// ----------------------------------------------------------------------------
//  BACKLIGHT (PWM)
// ----------------------------------------------------------------------------
uint8_t blDuty = 0;
void backlightInit() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(LCD_BL, 5000, 8);
#else
  ledcSetup(0, 5000, 8);
  ledcAttachPin(LCD_BL, 0);
#endif
}
void backlightSet(uint8_t duty) {
  if (duty == blDuty) return;
  blDuty = duty;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(LCD_BL, duty);
#else
  ledcWrite(0, duty);
#endif
}

// ----------------------------------------------------------------------------
//  XP
// ----------------------------------------------------------------------------
void jxLoad() {
  memset(&Jx, 0, sizeof(Jx));
  Jx.magic = JX_MAGIC;
  Preferences p;
  if (p.begin("jitter_xp", true)) {
    Jx.v = p.getULong("v", 0);   // plain u32 key, NOT a blob: getBytesLength() always returned 0 here
    p.end();
  }
}
void jxSave() {
  Preferences p;
  if (p.begin("jitter_xp", false)) { p.putULong("v", Jx.v); p.end(); }
  jxDirty = false;
  jxLastSave = millis();
}
void jxAward(uint32_t n) {
  if (n == 0) return;
  Jx.v += n;
  jxDirty = true;          // saved in batches (flash wear), see loop()
  uiHudDirty = true;
}

// ----------------------------------------------------------------------------
//  EYE REACTIONS / REWARDS
// ----------------------------------------------------------------------------
float eyeEase(float t) { return t * t * (3.0f - 2.0f * t); }

void triggerEyeChomp() { eyeChomping = true; eyeChompAt = millis(); }

void triggerEyeRfRx() {
  uint32_t now = millis();
  if (!eyeRfRxActive || now - eyeRfRxAt > 180) { eyeRfRxActive = true; eyeRfRxAt = now; }
}
void triggerEyeRfTx() { eyeRfTxActive = true; eyeRfTxAt = millis(); }

void triggerEyeIrBlast() {
  eyeIrActive = true;
  eyeIrAt = millis();
  jxAward(5);
  if (T.species != SP_EGG && T.species != SP_DEAD && !T.sleeping && T.sickDosesLeft == 0) {
    if (T.attnReason == ATT_DISCIPLINE) {
      triggerEyeChomp();
    } else if (T.happy < JG_MAX_HEARTS) {
      T.happy++;
      tamaClearAttention(ATT_HAPPY);
      uiHudDirty = true;
      tDirty = true;
    }
  }
}

void rewardRfSignalActivity(uint8_t weight = 1) {
  T.rfSignals += weight;
  jxAward(weight);
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  if (T.sleeping || T.sickDosesLeft > 0) return;
  if (T.attnReason == ATT_DISCIPLINE) { triggerEyeChomp(); return; }

  rfFeedBurstAcc += weight;
  if (rfFeedBurstAcc >= JG_SIGNALS_PER_HEART) {
    rfFeedBurstAcc %= JG_SIGNALS_PER_HEART;
    if (T.hungry < JG_MAX_HEARTS) {
      T.hungry++;
      tamaClearAttention(ATT_HUNGRY);
      uiHudDirty = true; tDirty = true;
    }
#if !JG_WIFI_HARD
    else if (T.happy < JG_MAX_HEARTS) {
      T.happy++;
      tamaClearAttention(ATT_HAPPY);
      uiHudDirty = true; tDirty = true;
    }
#endif
  }
}

void triggerEvolutionDance(const char* newName) {
  markActivity();
  evoDanceActive = true;
  evoDanceStart = millis();
  strncpy(evoBanner, newName, sizeof(evoBanner) - 1);
  evoBanner[sizeof(evoBanner) - 1] = 0;
  uiHudDirty = true;
}

void pickPairedHoverTarget(uint32_t now) {
  eyeHover[0].fromX = eyeHover[0].curX;
  eyeHover[0].fromY = eyeHover[0].curY;
  eyeHover[0].toX = EYE_BASE_CX[0] + (int16_t)random(-16, 17);
  eyeHover[0].toY = EYE_BASE_CY + (int16_t)random(-10, 11);
  eyeHover[0].moveStart = now;
  eyeHover[0].moveDur = 750 + (uint32_t)random(0, 750);
}

void initEyes() {
  randomSeed(micros());
  uint32_t now = millis();
  eyeHover[0].curX = EYE_BASE_CX[0];
  eyeHover[0].curY = EYE_BASE_CY;
  pickPairedHoverTarget(now);
  eyeHover[1].curX = EYE_BASE_CX[1];
  eyeHover[1].curY = EYE_BASE_CY;
  eyeHasLastDraw = false;
}

void stepPairedHover(uint32_t now) {
  uint32_t elapsed = now - eyeHover[0].moveStart;
  if (elapsed >= eyeHover[0].moveDur) { pickPairedHoverTarget(now); elapsed = 0; }
  float t = eyeEase((float)elapsed / (float)eyeHover[0].moveDur);
  eyeHover[0].curX = eyeHover[0].fromX + (int16_t)((eyeHover[0].toX - eyeHover[0].fromX) * t);
  eyeHover[0].curY = eyeHover[0].fromY + (int16_t)((eyeHover[0].toY - eyeHover[0].fromY) * t);
  eyeHover[1].curX = eyeHover[0].curX + (EYE_BASE_CX[1] - EYE_BASE_CX[0]);
  eyeHover[1].curY = eyeHover[0].curY;
}

void drawEye(int16_t cx, int16_t cy, bool leftEye, float openness, uint16_t color, float lid) {
  int16_t w = (int16_t)((EYE_W + (int16_t)(openness * 22)) * gSqW);
  int16_t hFull = EYE_H + (int16_t)(openness * 22);
  int16_t h = (int16_t)(hFull * lid * gSqH);
  if (h < 4) h = 4;
  int16_t x0 = cx - w / 2, y0 = cy - h / 2;

  gfx->fillRoundRect(x0, y0, w, h, h / 3, color);

  if (!evoDanceActive && lid > 0.6f) {
    int16_t slant = (int16_t)((1.0f - openness) * (h / 3));
    if (slant > 2) {
      if (leftEye) gfx->fillTriangle(x0, y0, x0 + w, y0, x0 + w, y0 + slant, COL_BG);
      else         gfx->fillTriangle(x0, y0, x0 + w, y0, x0, y0 + slant, COL_BG);
    }
  }
  if (T.species >= SP_BYTEKIN && T.species != SP_DEAD && h > 14) {
    gfx->fillRect(cx - 3, cy - (h * 32) / 100, 6, (h * 64) / 100, COL_BG);
  }
  if (T.species >= SP_SYNTHRA && T.species != SP_DEAD) {
    gfx->fillRect(x0, y0 - 7, w, 2, COL_CRIMSON);
  }
  if (T.species >= SP_AEGIS9 && T.species <= SP_ARCHONX) {
    gfx->fillCircle(leftEye ? x0 - 7 : x0 + w + 7, y0 - 3, 2, color);
  }

  if (T.poopCount > 0 && T.species != SP_EGG && T.species != SP_DEAD) {
    uint8_t fragLevel = min((uint8_t)4, T.poopCount);
    uint32_t phase = millis() / 90;
    uint8_t slices = fragLevel * 2 + 1;
    for (uint8_t s = 0; s < slices; s++) {
      int16_t sy = y0 + ((s * 7 + (phase % 5)) * max(1, (int)h - 3)) / (slices * 5 + 1);
      int16_t sh = (fragLevel >= 3) ? 3 : 2;
      int16_t sx = x0 + ((s * 13 + (leftEye ? 3 : 11) + (phase * 5)) % max(1, (int)w - 14));
      int16_t sw = 8 + fragLevel * 4;
      if (sx + sw > x0 + w) sw = (x0 + w) - sx;
      if (sw > 0 && sy + sh <= y0 + h) gfx->fillRect(sx, sy, sw, sh, COL_BG);
      if (fragLevel >= 2 && (s % 2 == 0)) {
        int16_t jx = ((s + phase + (leftEye ? 0 : 1)) & 1) ? (x0 + w - 2) : (x0 - 4);
        gfx->fillRect(jx, sy, 5, 2, color);
      }
    }
  }
}

void serviceEyes() {
  if (uiScreen != SCR_MAIN) return;
  uint32_t now = millis();
  if (now - lastEyeFrame < ((smashActive || eyeFast) ? 20 : EYE_FRAME_MS)) return;
  lastEyeFrame = now;

  if (evoDanceActive && (now - evoDanceStart >= 3200)) {
    evoDanceActive = false;
    evoBanner[0] = 0;
    uiHudDirty = true;
  }

  stepPairedHover(now);

  float lidTarget = 1.0f, openness = 0.0f;
  uint16_t color = COL_ACCENT;
  int16_t dx = 0, dy = 0;

  if (T.species == SP_EGG) {
    lidTarget = 0.35f; color = COL_SILVER;
    dx = (int16_t)(4.0f * sinf(now / 260.0f));
    eyeHover[0].curX = EYE_BASE_CX[0]; eyeHover[0].curY = EYE_BASE_CY;
    eyeHover[1].curX = EYE_BASE_CX[1]; eyeHover[1].curY = EYE_BASE_CY;
  } else if (T.sleeping) {
    lidTarget = 0.14f; color = COL_DIM;
    dy = (int16_t)(2.0f * sinf(now / 850.0f));
    eyeHover[0].curX = EYE_BASE_CX[0]; eyeHover[0].curY = EYE_BASE_CY;
    eyeHover[1].curX = EYE_BASE_CX[1]; eyeHover[1].curY = EYE_BASE_CY;
  } else if (T.sickDosesLeft > 0) {
    lidTarget = 0.45f;
    color = (T.sickType == SICK_THERMAL) ? JC_ORANGE : ((T.sickType == SICK_MALWARE) ? JC_MAGENTA : COL_AMBER);
  }

  if (eyeChomping) {
    uint32_t age = now - eyeChompAt;
    if (age >= 380) eyeChomping = false;
    else { openness = 0.65f; dx = (age < 190) ? 16 : 0; }
  }
  if (eyeRfRxActive) {
    uint32_t age = now - eyeRfRxAt;
    if (age >= 420) eyeRfRxActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.55f;
      color = ((age / 60) % 2 == 0) ? JC_CYAN : COL_WHITE;
      dx = (int16_t)(12.0f * sinf(age / 35.0f));
    }
  }
  if (eyeRfTxActive) {
    uint32_t age = now - eyeRfTxAt;
    if (age >= 500) eyeRfTxActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.70f;
      color = ((age / 70) % 2 == 0) ? COL_AMBER : JC_RED;
      dy = -6;
    }
  }
  if (eyeIrActive) {
    uint32_t age = now - eyeIrAt;
    if (age >= 650) eyeIrActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.85f;
      color = ((age / 55) % 2 == 0) ? JC_MAGENTA : JC_RED;
      dx = (int16_t)(8.0f * cosf(age / 25.0f));
      dy = (int16_t)(6.0f * sinf(age / 25.0f));
    }
  }
  if (evoDanceActive) {
    static const uint16_t RAINBOW[6] = { JC_RED, JC_ORANGE, JC_YELLOW, JC_GREEN, JC_CYAN, JC_MAGENTA };
    color = RAINBOW[(uint8_t)((now / 75) % 6)];
    openness = 0.75f + 0.25f * sinf(now / 60.0f);
    lidTarget = 1.0f;
    dx = (int16_t)(16.0f * cosf(now / 85.0f));
    dy = (int16_t)(10.0f * sinf(now / 65.0f));
  }

  if (dizzyActive) {
    uint32_t age = now - dizzyAt;
    if (age >= 1600) dizzyActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.5f;
      color = ((age / 90) % 2 == 0) ? JC_YELLOW : COL_WHITE;
      dx = (int16_t)(14.0f * cosf(age / 110.0f));
      dy = (int16_t)(9.0f * sinf(age / 110.0f));
    }
  }
  if (!T.sleeping && T.species != SP_EGG && !dizzyActive) dx += eyeTiltPx;

  // petting: happy squint + quick shake, red sparks are emitted further down
  bool petting = petLastTouch && (now - petLastTouch < 300) && !T.sleeping && !flipped &&
                 T.species != SP_EGG && T.species != SP_DEAD && uiScreen == SCR_MAIN;
  if (petting && !dizzyActive) {
    lidTarget = 0.5f; openness = 0.2f;
    dx += (int16_t)(4.0f * sinf(now / 28.0f));
    dy += (int16_t)(2.0f * sinf(now / 41.0f));
  }

  // ---- smash: wind-up, lunge into the wall, squash + red static, rebound
  uint32_t smAge = 0;
  const uint32_t SM_WIND = 80, SM_LUNGE = 190, SM_HOLD = 400, SM_END = 680;
  gSqW = 1.0f; gSqH = 1.0f;
  if (smashActive) {
    smAge = now - smashAt;
    if (smAge >= SM_END) {
      smashActive = false;
    } else {
      lidTarget = 1.0f;
      openness = (smAge < SM_WIND) ? 0.45f : 0.05f;
      if (smAge >= SM_LUNGE && smAge < SM_HOLD) {
        float sq = 1.0f - (float)(smAge - SM_LUNGE) / (float)(SM_HOLD - SM_LUNGE);
        if (smashDX != 0) { gSqW = 1.0f - 0.35f * sq; gSqH = 1.0f + 0.25f * sq; }
        else              { gSqH = 1.0f - 0.40f * sq; gSqW = 1.0f + 0.20f * sq; }
        color = (smAge < SM_LUNGE + 70) ? COL_WHITE : JC_RED;
        if (!smashHit) { smashHit = true; sndPlay(SND_SMASH); }
      }
    }
  }

  // ---- gravity: flip the device and he falls to the screen's top edge (the new floor)
  int16_t flipDy = 0;
  {
    static uint32_t lastFlipT = 0;
    float fdt = lastFlipT ? (now - lastFlipT) / 1000.0f : 0.02f;
    if (fdt > 0.05f) fdt = 0.05f;
    lastFlipT = now;
    if (flipped && gEyeTop != 0) { gEyeTop = 0; uiHudDirty = true; }     // hide the title strip while he falls up there
    const float ceilOff = (float)(0 + 4 + 22 - EYE_BASE_CY);
    bool moving = flipped ? (flipOff > ceilOff + 0.5f || fabsf(flipVel) > 1.0f)
                          : (flipOff < -0.5f || fabsf(flipVel) > 1.0f);
    if (moving) {
      flipVel += (flipped ? -1500.0f : 1500.0f) * fdt;
      flipOff += flipVel * fdt;
      if (flipped && flipOff <= ceilOff) {
        flipOff = ceilOff;
        if (flipVel < -140.0f) { flipVel = -flipVel * 0.4f; flipImpactAt = now; sndPlay(SND_THUD); }
        else flipVel = 0.0f;
      }
      if (!flipped && flipOff >= 0.0f) {
        flipOff = 0.0f;
        if (flipVel > 180.0f) { flipVel = -flipVel * 0.35f; flipImpactAt = now; sndPlay(SND_THUD); }
        else flipVel = 0.0f;
      }
      lidTarget = 1.0f; openness = 0.6f;                                  // wide-eyed while falling
    }
    flipMoving = moving;
    if (!flipped && flipOff > -14.0f && gEyeTop == 0) { gEyeTop = EYE_CLIP_Y0; uiHudDirty = true; }
    uint32_t fa = now - flipImpactAt;
    if (flipImpactAt && fa < 160 && !smashActive) {
      float sq = 1.0f - fa / 160.0f;
      gSqH *= 1.0f - 0.3f * sq; gSqW *= 1.0f + 0.15f * sq;
    }
    flipDy = (int16_t)flipOff;
  }

  eyeLid += (lidTarget - eyeLid) * 0.15f;

  int16_t newW = (int16_t)((EYE_W + (int16_t)(openness * 22)) * gSqW);
  int16_t newH = (int16_t)((EYE_H + (int16_t)(openness * 22)) * eyeLid * gSqH);
  if (newH < 4) newH = 4;

  if (smashActive) {
    const int16_t BACK = 10;
    int16_t sgn = (smashDX != 0) ? smashDX : smashDY;
    int16_t full;
    if (smashDX < 0)      full = 2 - (eyeHover[0].curX - newW / 2);               // left wall
    else if (smashDX > 0) full = (SW - 2) - (eyeHover[1].curX + newW / 2);        // right wall
    else if (smashDY > 0) full = EYE_CLIP_Y1 - (eyeHover[0].curY + newH / 2);     // floor of the eye area
    else                  full = EYE_CLIP_Y0 - (eyeHover[0].curY - newH / 2);     // ceiling
    float off;
    if (smAge < SM_WIND) {
      off = -(float)(sgn * BACK) * eyeEase((float)smAge / SM_WIND);
    } else if (smAge < SM_LUNGE) {
      float q = (float)(smAge - SM_WIND) / (float)(SM_LUNGE - SM_WIND);
      off = -(float)(sgn * BACK) + ((float)full + (float)(sgn * BACK)) * q * q;
    } else if (smAge < SM_HOLD) {
      off = (float)full;
    } else {
      float r = (float)(smAge - SM_HOLD) / (float)(SM_END - SM_HOLD);
      off = (float)full * (1.0f - eyeEase(r));
    }
    dx = (smashDX != 0) ? (int16_t)off : 0;
    dy = (smashDX != 0) ? 0 : (int16_t)off;
  }

  dy += flipDy;
  int16_t drawX[2] = {(int16_t)(eyeHover[0].curX + dx), (int16_t)(eyeHover[1].curX + dx)};
  int16_t drawY[2] = {(int16_t)(eyeHover[0].curY + dy), (int16_t)(eyeHover[1].curY + dy)};

  for (uint8_t k = 0; k < staticN; k++) gfx->fillRect(staticR[k].x, staticR[k].y, staticR[k].w, staticR[k].h, COL_BG);
  staticN = 0;
  for (uint8_t k = 0; k < 28; k++)                                   // erase last frame's sparks
    if (sparks[k].drawn) { gfx->fillRect(sparks[k].dpx, sparks[k].dpy, 3, 3, COL_BG); sparks[k].drawn = false; }

  const int16_t PAD = 12;
  for (uint8_t i = 0; i < 2; i++) {
    int16_t nx0 = drawX[i] - newW / 2 - PAD, nx1 = drawX[i] + newW / 2 + PAD;
    int16_t ny0 = drawY[i] - newH / 2 - PAD, ny1 = drawY[i] + newH / 2 + PAD;
    if (eyeHasLastDraw) {
      int16_t ox0 = lastDrawX[i] - lastDrawW[i] / 2 - PAD, ox1 = lastDrawX[i] + lastDrawW[i] / 2 + PAD;
      int16_t oy0 = lastDrawY[i] - lastDrawH[i] / 2 - PAD, oy1 = lastDrawY[i] + lastDrawH[i] / 2 + PAD;
      nx0 = min(nx0, ox0); nx1 = max(nx1, ox1);
      ny0 = min(ny0, oy0); ny1 = max(ny1, oy1);
    }
    if (ny0 < gEyeTop) ny0 = gEyeTop;
    if (ny1 > EYE_CLIP_Y1) ny1 = EYE_CLIP_Y1;
    if (nx0 < 2) nx0 = 2;
    if (nx1 > SW - 2) nx1 = SW - 2;
    gfx->fillRect(nx0, ny0, nx1 - nx0, ny1 - ny0, COL_BG);
    lastDrawX[i] = drawX[i]; lastDrawY[i] = drawY[i];
    lastDrawW[i] = newW;     lastDrawH[i] = newH;
  }
  eyeHasLastDraw = true;

  drawEye(drawX[0], drawY[0], true,  openness, color, eyeLid);
  drawEye(drawX[1], drawY[1], false, openness, color, eyeLid);

  // red sparks (petting)
  {
    float sdt = lastSparkT ? (now - lastSparkT) / 1000.0f : 0.02f;
    if (sdt > 0.06f) sdt = 0.06f;
    lastSparkT = now;
    int toEmit = petting ? 2 : 0;
    if (petBurst) { toEmit += petBurst; petBurst = 0; }
    bool anyAlive = false;
    static const uint16_t SPK[3] = { 0xF800, JC_RED, 0x8000 };
    for (uint8_t k = 0; k < 28; k++) {
      Spark &sp = sparks[k];
      if (!sp.alive && toEmit > 0) {
        uint8_t e = random(2);
        sp.x = drawX[e] + random(-34, 35); sp.y = drawY[e] + random(-18, 6);
        sp.vx = random(-80, 81); sp.vy = -(float)random(70, 190);
        sp.born = now; sp.alive = true; toEmit--;
      }
      if (!sp.alive) continue;
      uint32_t age = now - sp.born;
      if (age > 650) { sp.alive = false; continue; }
      sp.vy += 300.0f * sdt; sp.x += sp.vx * sdt; sp.y += sp.vy * sdt;
      if (sp.x < 1 || sp.x > SW - 4 || sp.y < gEyeTop || sp.y > EYE_CLIP_Y1 - 4) { sp.alive = false; continue; }
      int sz = (age < 300) ? 3 : 2;
      gfx->fillRect((int16_t)sp.x, (int16_t)sp.y, sz, sz, SPK[age < 250 ? 0 : (age < 450 ? 1 : 2)]);
      sp.dpx = (int16_t)sp.x; sp.dpy = (int16_t)sp.y; sp.drawn = true; anyAlive = true;
    }
    eyeFast = petting || flipMoving || anyAlive;
  }

  // night-light: moon and drifting Zs while he sleeps
  static bool nightDrawn = false;
  if (T.sleeping && T.species != SP_DEAD) {
    gfx->fillRect(2, EYE_CLIP_Y0, 40, 44, COL_BG);
    gfx->fillRect(SW - 42, EYE_CLIP_Y0, 40, EYE_CLIP_Y1 - EYE_CLIP_Y0, COL_BG);
    gfx->fillCircle(22, EYE_CLIP_Y0 + 20, 11, COL_SILVER);
    gfx->fillCircle(28, EYE_CLIP_Y0 + 16, 10, COL_BG);
    for (uint8_t k = 0; k < 3; k++) {
      float ph = (float)((now / 40 + k * 25) % 75) / 75.0f;
      int16_t zy = EYE_CLIP_Y1 - 16 - (int16_t)(ph * (EYE_CLIP_Y1 - EYE_CLIP_Y0 - 24));
      int16_t zx = SW - 34 + k * 6 + (int16_t)(4.0f * sinf(ph * 6.28f));
      gfx->setTextSize(k == 0 ? 1 : 2);
      gfx->setTextColor(k == 2 ? COL_SILVER : COL_DIM);
      gfx->setCursor(zx, zy);
      gfx->print(k == 0 ? "z" : "Z");
    }
    nightDrawn = true;
  } else if (nightDrawn) {
    gfx->fillRect(2, EYE_CLIP_Y0, 40, 44, COL_BG);
    gfx->fillRect(SW - 42, EYE_CLIP_Y0, 40, EYE_CLIP_Y1 - EYE_CLIP_Y0, COL_BG);
    nightDrawn = false;
  }

  // red static at the impact point
  if (smashActive && smashHit && smAge >= SM_LUNGE) {
    float inten = 1.0f - (float)(smAge - SM_LUNGE) / (float)(SM_HOLD + 140 - SM_LUNGE);
    if (inten > 0.0f) {
      int px[2], py[2]; uint8_t pn = 0;
      if (smashDX < 0)      { px[0] = drawX[0] - newW / 2; py[0] = drawY[0]; pn = 1; }
      else if (smashDX > 0) { px[0] = drawX[1] + newW / 2; py[0] = drawY[1]; pn = 1; }
      else for (uint8_t i = 0; i < 2; i++) {
        px[i] = drawX[i]; py[i] = drawY[i] + ((smashDY > 0) ? 1 : -1) * (newH / 2); pn = 2;
      }
      static const uint16_t REDS[4] = { JC_RED, 0xF800, 0xC000, 0x8000 };
      for (uint8_t k = 0; k < pn; k++) {
        int hx = (smashDX != 0) ? 16 : 30, hy = (smashDX != 0) ? 26 : 14;
        int rx0 = constrain(px[k] - hx, 0, SW), rx1 = constrain(px[k] + hx, 0, SW);
        int ry0 = constrain(py[k] - hy, EYE_CLIP_Y0, EYE_CLIP_Y1), ry1 = constrain(py[k] + hy, EYE_CLIP_Y0, EYE_CLIP_Y1);
        if (rx1 <= rx0 || ry1 <= ry0) continue;
        staticR[staticN++] = SRect{(int16_t)rx0, (int16_t)ry0, (int16_t)(rx1 - rx0), (int16_t)(ry1 - ry0)};
        int cnt = 8 + (int)(40.0f * inten);
        for (int c = 0; c < cnt; c++) {
          int x = random(rx0, rx1), y = random(ry0, ry1), w = random(1, 6), h = random(1, 3);
          if (x + w > rx1) w = rx1 - x;
          if (y + h > ry1) h = ry1 - y;
          gfx->fillRect(x, y, w, h, REDS[random(4)]);
        }
        if (inten > 0.35f) {
          for (int l = 0; l < 3; l++) {
            int y = random(ry0, ry1), x = random(rx0, rx1), len = random(8, 26);
            if (x + len > rx1) len = rx1 - x;
            gfx->fillRect(x, y, len, 1, JC_RED);
          }
        }
      }
    }
  }
  frameDirty = true;
}

// ----------------------------------------------------------------------------
//  PET LIFECYCLE / PERSISTENCE (NVS only - no SD in this port)
// ----------------------------------------------------------------------------
// ----------------------------------------------------------------------------
//  RTC (PCF85063 @0x51): keeps real time while he is switched off
// ----------------------------------------------------------------------------
#define RTC_ADDR 0x51
static bool rtcOk = false;
static uint8_t bcd2d(uint8_t b) { return (b >> 4) * 10 + (b & 15); }
static uint8_t d2bcd(uint8_t d) { return ((d / 10) << 4) | (d % 10); }

static void buildDate(uint16_t &y, uint8_t &mo, uint8_t &d) {   // compile date = fallback date
  static const char* M = "JanFebMarAprMayJunJulAugSepOctNovDec";
  mo = 1;
  for (uint8_t i = 0; i < 12; i++) if (!strncmp(__DATE__, M + i * 3, 3)) { mo = i + 1; break; }
  d = (uint8_t)atoi(__DATE__ + 4);
  y = (uint16_t)atoi(__DATE__ + 7);
}
static bool rtcRead(RtcTime &t) {
  Wire.beginTransmission(RTC_ADDR);
  Wire.write(0x04);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)RTC_ADDR, (uint8_t)7) != 7) return false;
  uint8_t b[7];
  for (uint8_t i = 0; i < 7; i++) b[i] = Wire.read();
  t.valid = !(b[0] & 0x80);                       // bit 7 = oscillator stopped = time lost
  t.s = bcd2d(b[0] & 0x7F); t.mi = bcd2d(b[1] & 0x7F); t.h = bcd2d(b[2] & 0x3F);
  t.d = bcd2d(b[3] & 0x3F); t.mo = bcd2d(b[5] & 0x1F); t.y = 2000 + bcd2d(b[6]);
  if (t.s > 59 || t.mi > 59 || t.h > 23 || t.d < 1 || t.d > 31 || t.mo < 1 || t.mo > 12) t.valid = false;
  return true;
}
static bool rtcWrite(const RtcTime &t) {
  Wire.beginTransmission(RTC_ADDR);
  Wire.write(0x04);
  Wire.write(d2bcd(t.s));                          // writing seconds with bit 7 = 0 clears the flag
  Wire.write(d2bcd(t.mi)); Wire.write(d2bcd(t.h)); Wire.write(d2bcd(t.d));
  Wire.write((uint8_t)0);                          // weekday (unused)
  Wire.write(d2bcd(t.mo)); Wire.write(d2bcd(t.y % 100));
  return Wire.endTransmission() == 0;
}
static uint32_t rtcEpoch(const RtcTime &t) {       // seconds since 1970 (only differences matter)
  int y = t.y - (t.mo <= 2);
  int era = y / 400;
  unsigned yoe = y - era * 400;
  unsigned doy = (153 * (t.mo + (t.mo > 2 ? -3 : 9)) + 2) / 5 + t.d - 1;
  unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
  uint32_t days = (uint32_t)(era * 146097 + (int)doe - 719468);
  return days * 86400UL + t.h * 3600UL + t.mi * 60UL + t.s;
}
static void rtcStampSave() {                       // remember when we last saved, for catch-up
  if (!rtcOk) return;
  RtcTime t;
  if (!rtcRead(t) || !t.valid) return;
  Preferences p;
  if (p.begin("jitter_rtc", false)) { p.putULong("last", rtcEpoch(t)); p.end(); }
}
static uint8_t rtcState = 0;                       // 0 = no RTC chip, 1 = RTC ok, 2 = RTC lost power (using saved time)

// Wall-clock persistence in its own NVS key (seconds since midnight), used when the RTC has no time.
static void clockPersist() {
  Preferences p;
  if (p.begin("jitter_clk", false)) {
    p.putUInt("t", (uint32_t)T.clockHour * 3600UL + (uint32_t)T.clockMin * 60UL + T.clockSec);
    p.end();
  }
}
static bool clockRestore() {
  bool ok = false;
  Preferences p;
  if (p.begin("jitter_clk", true)) {
    uint32_t v = p.getUInt("t", 0xFFFFFFFFUL);
    p.end();
    if (v < 86400UL) {
      T.clockHour = (uint8_t)(v / 3600UL);
      T.clockMin  = (uint8_t)((v % 3600UL) / 60UL);
      T.clockSec  = (uint8_t)(v % 60UL);
      ok = true;
    }
  }
  return ok;
}
static void rtcSetFromPet() {                      // called after you set the clock by hand
  clockPersist();
  if (!rtcOk) return;
  RtcTime t;
  if (!rtcRead(t) || !t.valid) { buildDate(t.y, t.mo, t.d); }
  t.h = T.clockHour; t.mi = T.clockMin; t.s = T.clockSec;
  rtcWrite(t);
}

void tamaInflictSickness(uint8_t causeType, uint8_t doses) {
  sfxQuiet(SND_SICK);
  T.sickType = causeType;
  T.sickDosesLeft = doses;
  uiHudDirty = true;
  tDirty = true;
}

void tamaFreshEgg() {
  uint8_t prevScale = (T.timeScale == 1 || T.timeScale == 10 || T.timeScale == 60) ? T.timeScale : 1;
  uint8_t hr = T.clockHour < 24 ? T.clockHour : 12;
  uint8_t mn = T.clockMin < 60 ? T.clockMin : 0;
  memset(&T, 0, sizeof(T));
  T.magic = TAMA_MAGIC;
  T.id = (uint32_t)esp_random();
  T.species = SP_EGG;
  T.hungry = JG_MAX_HEARTS;
  T.happy = JG_MAX_HEARTS;
  T.weightOz = 5;
  T.sickType = SICK_NONE;
  T.timeScale = prevScale;
  T.clockHour = hr;
  T.clockMin = mn;
  tDirty = true;
}

void tamaSave() {
  if (tPrefs.begin("jitter_g3", false)) {
    tPrefs.putBytes("st", &T, sizeof(T));
    tPrefs.end();
  }
  if (jxDirty) jxSave();
  rtcStampSave();
  clockPersist();
  tDirty = false;
  tLastSave = millis();
}

void tamaLoad() {
  memset(&T, 0, sizeof(T));
  bool ok = false;
  if (tPrefs.begin("jitter_g3", true)) {
    if (tPrefs.getBytesLength("st") == sizeof(T)) {
      tPrefs.getBytes("st", &T, sizeof(T));
      ok = (T.magic == TAMA_MAGIC);
    }
    tPrefs.end();
  }
  if (!ok) {
    T.clockHour = 12; T.clockMin = 0; T.timeScale = 1;
    tamaFreshEgg();
    tamaSave();
  }
  if (T.species > SP_DEAD) T.species = SP_EGG;
  if (T.sickDosesLeft == 0) T.sickType = SICK_NONE;
  else if (T.sickType == SICK_NONE || T.sickType > SICK_MALWARE) T.sickType = SICK_CORRUPT;
  if (T.timeScale != 1 && T.timeScale != 10 && T.timeScale != 60) T.timeScale = 1;
  if (T.species == SP_DEAD) uiScreen = SCR_DEAD;
}

void playAlert(uint8_t reason) {
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  if (inQuietHours()) return;
  if (T.sleeping && reason != ATT_SLEEP) return;          // quiet while asleep (except the bedtime lights call)
  switch (reason) {
    case ATT_HUNGRY:     sndPlay(SND_ALERT_HUNGRY); break;
    case ATT_HAPPY:      sndPlay(SND_ALERT_BORED);  break;
    case ATT_SLEEP:      sndPlay(SND_ALERT_LIGHTS); break;
    case ATT_DISCIPLINE: sndPlay(SND_ALERT_SCOLD);  break;
  }
}

void tamaRaiseAttention(uint8_t reason) {
  if (T.attnReason == ATT_NONE) {
    T.attnReason = reason;
    T.attnTimerSec = JG_ATTN_SEC;
    if (!T.sleeping) markActivity();
    uiHudDirty = true;
    alertAt = millis();
    playAlert(reason);
  }
}

void tamaClearAttention(uint8_t reason) {
  if (reason == ATT_NONE || T.attnReason == reason) {
    T.attnReason = ATT_NONE;
    T.attnTimerSec = 0;
    uiHudDirty = true;
  }
}

void tamaKill(uint8_t cause) {
  if (!inQuietHours()) sndPlay(SND_DEATH);
  T.species = SP_DEAD;
  T.deathCause = cause;
  T.sleeping = 0;
  T.attnReason = ATT_NONE;
  selIcon = ICON_NONE;
  uiScreen = SCR_DEAD;
  uiNeedsFullRedraw = true;
  tDirty = true;
  tamaSave();
}

void tamaEvolveTo(uint8_t nextSpecies) {
  bool wasEgg = (T.species == SP_EGG);
  T.species = nextSpecies;
  T.stageSec = 0;
  T.careMistakes = 0;
  T.discMistakes = 0;
  T.snackCount = 0;
  if (T.weightOz < SP_BASE_WT[nextSpecies]) T.weightOz = SP_BASE_WT[nextSpecies];
  triggerEvolutionDance(SP_NAME[nextSpecies]);
  if (!inQuietHours()) sndPlay(wasEgg ? SND_HATCH : SND_EVOLVE);
  uiHudDirty = true;
  tDirty = true;
  tamaSave();
}

void tamaCheckEvolutions() {
  uint8_t sp = T.species;
  if (sp == SP_EGG) {
    if (T.stageSec >= 300) {
      T.hungry = JG_MAX_HEARTS; T.happy = JG_MAX_HEARTS; T.weightOz = 5;
      tamaEvolveTo(SP_BITLING);
    }
  } else if (sp == SP_BITLING) {
    if (!T.babyNapDone && T.stageSec >= 1800 && T.stageSec < 2400) {
      T.sleeping = 1; T.babyNapDone = 1; uiHudDirty = true;
    } else if (T.sleeping && T.stageSec >= 2400) {
      T.sleeping = 0; T.lightsOff = 0; uiHudDirty = true;
    }
    if (!T.babySickDone && T.stageSec >= 2700) {
      tamaInflictSickness(SICK_MALWARE, 2);
      T.babySickDone = 1;
    }
    if (T.stageSec >= 3900) {
      T.sleeping = 0; T.lightsOff = 0;
      if (!inQuietHours()) sndPlay(SND_WAKE);
      tamaEvolveTo(SP_BYTEKIN);
    }
  } else if (sp == SP_BYTEKIN) {
    if (T.stageSec >= 172800UL) {
      if (T.careMistakes <= 2 && T.discipline >= 75) tamaEvolveTo(SP_SYNTHRA);
      else tamaEvolveTo(SP_GLITCHLING);
    }
  } else if (sp == SP_SYNTHRA) {
    if (T.stageSec >= 259200UL) {
      if (T.careMistakes == 0 && T.discipline == 100) tamaEvolveTo(SP_AEGIS9);
      else if (T.careMistakes <= 2 && T.discipline >= 75) tamaEvolveTo(SP_PROXYFOX);
      else tamaEvolveTo(SP_NULLMIND);
    }
  } else if (sp == SP_GLITCHLING) {
    if (T.stageSec >= 259200UL) {
      if (T.careMistakes <= 2 && T.discipline >= 75) tamaEvolveTo(SP_HEXHOUND);
      else if (T.careMistakes <= 4) tamaEvolveTo(SP_VOIDCRAWLER);
      else tamaEvolveTo(SP_ROTBIT);
    }
  } else if (sp == SP_NULLMIND) {
    if (T.stageSec >= 172800UL && T.careMistakes == 0 && T.discipline == 100) {
      tamaEvolveTo(SP_ARCHONX);
    }
  }
}

// Age him for the time he was switched off. Gentle: hearts never drop below 1, at most
// one fragment, no sickness, no care mistakes, no death while the power was off.
void tamaCatchUp(uint32_t sec) {
  if (T.species == SP_DEAD || sec == 0) return;
  T.ageSec += sec; T.stageSec += sec;
  if (T.species != SP_EGG) {
    uint32_t hi = (uint32_t)SP_HEART_INT[T.species] * JG_DRAIN_NUM / JG_DRAIN_DEN;
    if (hi) {
      uint32_t lost = (sec * 2 / 3) / hi;                 // about a third of the time he sleeps
      if (T.hungry > 0) T.hungry = (lost >= T.hungry) ? 1 : (uint8_t)(T.hungry - lost);
      if (T.happy > 0)  T.happy  = (lost >= T.happy)  ? 1 : (uint8_t)(T.happy - lost);
    }
    if (sec >= 9000 && T.poopCount < 1) T.poopCount = 1;
  }
  tDirty = true;
}

void rtcBoot() {                                    // call after tamaLoad()
  Wire.beginTransmission(RTC_ADDR);
  rtcOk = (Wire.endTransmission() == 0);
  if (!rtcOk) { rtcState = 0; clockRestore(); Serial.println("RTC: not found - pet clock only (restored saved time)"); return; }
  RtcTime t;
  if (!rtcRead(t)) { rtcOk = false; rtcState = 0; clockRestore(); Serial.println("RTC: read failed (restored saved time)"); return; }
  if (!t.valid) {                                   // never set / lost power: seed it from the saved time
    rtcState = 2;
    clockRestore();
    buildDate(t.y, t.mo, t.d);
    t.h = T.clockHour; t.mi = T.clockMin; t.s = T.clockSec;
    rtcWrite(t);
    Serial.println("RTC: time was not set - seeded from the pet clock (set it once on the clock screen)");
    return;
  }
  rtcState = 1;
  uint32_t nowE = rtcEpoch(t), last = 0;
  { Preferences p; if (p.begin("jitter_rtc", true)) { last = p.getULong("last", 0); p.end(); } }
  T.clockHour = t.h; T.clockMin = t.mi; T.clockSec = t.s;
  uint32_t away = (last && nowE > last) ? (nowE - last) : 0;
  if (away > 60) {
    uint32_t used = (away > JG_CATCHUP_MAX_SEC) ? JG_CATCHUP_MAX_SEC : away;
    tamaCatchUp(used);
    Serial.printf("RTC: away %lu s, aged him %lu s\n", (unsigned long)away, (unsigned long)used);
  } else {
    Serial.printf("RTC: ok %02u:%02u\n", t.h, t.mi);
  }
}

// keep the pet clock honest: re-read the RTC every 30 min
void serviceRtcSync() {
  static uint32_t lastSync = 0;
  if (!rtcOk || T.timeScale != 1 || clockSetMode) return;
  if (millis() - lastSync < 1800000UL) return;
  lastSync = millis();
  RtcTime t;
  if (rtcRead(t) && t.valid) { T.clockHour = t.h; T.clockMin = t.mi; T.clockSec = t.s; }
}

void tamaService() {
  uint32_t now = millis();
  if (tLastTickMs == 0) tLastTickMs = now;
  if (now - tLastTickMs < 1000) return;

  uint32_t realElapsed = (now - tLastTickMs) / 1000;
  tLastTickMs += realElapsed * 1000;

  if (uiScreen == SCR_CLOCK && clockSetMode) return;
  if (T.species == SP_DEAD) return;

  uint32_t dt = realElapsed * (uint32_t)T.timeScale;

  uint32_t totalDaySec = (uint32_t)T.clockHour * 3600UL + (uint32_t)T.clockMin * 60UL + (uint32_t)T.clockSec + dt;
  totalDaySec %= 86400UL;
  T.clockHour = (uint8_t)(totalDaySec / 3600UL);
  T.clockMin  = (uint8_t)((totalDaySec % 3600UL) / 60UL);
  T.clockSec  = (uint8_t)(totalDaySec % 60UL);

  { static uint32_t lastClkSave = 0;               // keep the saved wall-clock fresh (every 60 s)
    if (now - lastClkSave >= 60000UL) { lastClkSave = now; clockPersist(); } }

  T.ageSec += dt;
  T.stageSec += dt;
  tDirty = true;

  if (T.species == SP_EGG) {
    tamaCheckEvolutions();
    uiHudDirty = true;
    return;
  }

  uint8_t bedHr = SP_BED_HR[T.species];
  uint8_t wakeHr = SP_WAKE_HR[T.species];
  if (bedHr <= 23) {
    bool shouldSleep = (T.clockHour >= bedHr || T.clockHour < wakeHr);
    if (shouldSleep && !T.sleeping) {
      T.sleeping = 1;
      if (!inQuietHours()) sndPlay(SND_SLEEP);
      if (!T.lightsOff) tamaRaiseAttention(ATT_SLEEP);
      uiHudDirty = true;
    } else if (!shouldSleep && T.sleeping) {
      T.sleeping = 0; T.lightsOff = 0;
      tamaClearAttention(ATT_SLEEP);
      uiHudDirty = true;
    }
  }

  if (T.attnReason != ATT_NONE) {
    if (T.attnTimerSec > dt) {
      T.attnTimerSec -= dt;
    } else {
      uint8_t expired = T.attnReason;
      T.attnReason = ATT_NONE;
      T.attnTimerSec = 0;
      if (expired == ATT_DISCIPLINE) T.discMistakes++;
      else { T.careMistakes++; T.totalMistakes++; }
      uiHudDirty = true;
    }
  }

  if (!T.sleeping) {
    uint32_t heartInterval = SP_HEART_INT[T.species] * JG_DRAIN_NUM / JG_DRAIN_DEN;
    uint32_t ageDays = T.ageSec / 86400UL;
    if (T.species >= SP_AEGIS9 && ageDays >= 10 && heartInterval > 300) {
      uint32_t accel = (ageDays - 9) * 350;
      heartInterval = (heartInterval > accel + 240) ? (heartInterval - accel) : 240;
    }

    T.hungryAccSec += dt;
    if (T.hungryAccSec >= heartInterval) {
      T.hungryAccSec %= heartInterval;
      if (T.hungry > 0) {
        T.hungry--;
        if (T.hungry == 0) tamaRaiseAttention(ATT_HUNGRY);
        uiHudDirty = true;
      }
    }

    T.happyAccSec += dt;
    if (T.happyAccSec >= heartInterval) {
      T.happyAccSec %= heartInterval;
      if (T.happy > 0) {
        T.happy--;
        if (T.happy == 0) tamaRaiseAttention(ATT_HAPPY);
        uiHudDirty = true;
      }
    }

    uint32_t poopInterval = ((T.species == SP_BITLING) ? 720UL : 9000UL) * JG_DRAIN_NUM / JG_DRAIN_DEN;
    T.poopAccSec += dt;
    if (T.poopAccSec >= poopInterval) {
      T.poopAccSec %= poopInterval;
      if (T.poopCount < 4) {
        T.poopCount++;
        sfxQuiet(SND_FRAG);
        if (T.poopCount >= 2 && T.sickDosesLeft == 0) tamaInflictSickness(SICK_CORRUPT, 2);
        uiHudDirty = true;
      }
    }

    T.discCallAccSec += dt;
    if (T.discCallAccSec >= 12600UL) {
      T.discCallAccSec = 0;
      if (T.hungry > 0 && T.happy > 0 && T.sickDosesLeft == 0 && T.discipline < 100) {
        tamaRaiseAttention(ATT_DISCIPLINE);
      }
    }
  }

  if (T.sickDosesLeft > 0) {
    T.sickAccSec += dt;
    if (T.sickAccSec >= JG_SICK_DEATH_SEC) { tamaKill(1); return; }
  } else {
    T.sickAccSec = 0;
    T.sickType = SICK_NONE;
  }

  uint8_t maxCM = (T.species == SP_ROTBIT) ? JG_MAXCM_ROT : JG_MAXCM;
  if (T.careMistakes >= maxCM) {
    tamaKill(T.ageSec >= 10 * 86400UL ? 3 : 1);
    return;
  }

  tamaCheckEvolutions();

  if (tDirty && (now - tLastSave > 180000UL)) tamaSave();
}

// ----------------------------------------------------------------------------
//  ACTIONS
// ----------------------------------------------------------------------------
void actionFeedMeal() {
  if (T.sleeping || T.sickDosesLeft > 0) { sndPlay(SND_DENY); return; }
  if (T.attnReason == ATT_DISCIPLINE) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  if (T.hungry >= JG_MAX_HEARTS) { sndPlay(SND_DENY); return; }
  sndPlay(SND_EAT);
  T.hungry++;
  T.weightOz++;
  jxAward(2);
  triggerEyeChomp();
  if (T.hungry > 0) tamaClearAttention(ATT_HUNGRY);
  uiHudDirty = true;
  tDirty = true;
}

void actionFeedSnack() {
  if (T.sleeping || T.sickDosesLeft > 0) { sndPlay(SND_DENY); return; }
  if (T.attnReason == ATT_DISCIPLINE) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  sndPlay(SND_SNACK);
  if (T.happy < JG_MAX_HEARTS) T.happy++;
  T.weightOz += 2;
  T.snackCount++;
  jxAward(1);
  triggerEyeChomp();
  if (T.happy > 0) tamaClearAttention(ATT_HAPPY);
  if (T.snackCount >= 6 && T.sickDosesLeft == 0) tamaInflictSickness(SICK_THERMAL, 2);
  if (T.snackCount >= JG_SNACK_KILL && T.species <= SP_GLITCHLING) { tamaKill(2); return; }
  uiHudDirty = true;
  tDirty = true;
}

void startNumbersGame() {
  uint8_t minWt = SP_BASE_WT[T.species];
  if (T.sleeping || T.sickDosesLeft > 0) { sndPlay(SND_DENY); return; }
  if (T.attnReason == ATT_DISCIPLINE) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  if (T.happy >= JG_MAX_HEARTS && T.weightOz <= minWt) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  sndPlay(SND_GAME_START);
  gameRound = 1;
  gameWins = 0;
  gameLeftNum = (uint8_t)random(1, 10);
  gameRightNum = (uint8_t)random(1, 10);
  gameRevealState = 0;
  uiScreen = SCR_GAME_HILO;
  uiNeedsFullRedraw = true;
}

void submitNumbersGuess(bool guessHigher) {
  if (gameRevealState != 0) return;
  gameLastWon = guessHigher ? (gameRightNum > gameLeftNum) : (gameRightNum < gameLeftNum);
  if (gameLastWon) gameWins++;
  sndPlay(gameLastWon ? SND_ROUND_WIN : SND_ROUND_LOSE);
  gameRevealState = 1;
  gameRevealAt = millis();
  uiNeedsFullRedraw = true;
}

void finishNumbersGame() {
  if (gameWins >= 3) sndPlay(SND_FANFARE);
  uint8_t minWt = SP_BASE_WT[T.species];
  if (T.weightOz > minWt) T.weightOz--;
  if (gameWins >= 5) T.happy = min((int)JG_MAX_HEARTS, (int)T.happy + 2);
  else if (gameWins >= 3) T.happy = min((int)JG_MAX_HEARTS, (int)T.happy + 1);
  if (T.happy > 0) tamaClearAttention(ATT_HAPPY);
  jxAward(gameWins >= 5 ? 5 : (gameWins >= 3 ? 3 : 1));
  uiScreen = SCR_MAIN;
  selIcon = ICON_NONE;
  uiNeedsFullRedraw = true;
  tDirty = true;
}

void executeMenuIcon(uint8_t icon) {
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  switch (icon) {
    case ICON_FEED:
      if (!T.sleeping && T.sickDosesLeft == 0) {
        feedChoice = 0;
        uiScreen = SCR_FEED_MENU;
        uiNeedsFullRedraw = true;
      }
      break;
    case ICON_GAME:
      startNumbersGame();
      break;
    case ICON_CLEAN:
      if (T.poopCount == 0) sndPlay(SND_DENY);
      if (T.poopCount > 0) {
        sndPlay(SND_DEFRAG);
        T.poopCount = 0;
        triggerEyeChomp();
        uiHudDirty = true; tDirty = true;
      }
      break;
    case ICON_LIGHT:
      T.lightsOff = T.lightsOff ? 0 : 1;
      sndPlay(T.lightsOff ? SND_LIGHT_OFF : SND_LIGHT_ON);
      if (T.sleeping && T.lightsOff) tamaClearAttention(ATT_SLEEP);
      uiHudDirty = true; tDirty = true;
      break;
    case ICON_MEDS:
      sndPlay(T.sickDosesLeft > 0 ? SND_PATCH : SND_DENY);
      if (T.sickDosesLeft > 0) {
        T.sickDosesLeft--;
        if (T.sickDosesLeft == 0) T.sickType = SICK_NONE;
        T.snackCount = 0;
        triggerEyeChomp();
        uiHudDirty = true; tDirty = true;
      }
      break;
    case ICON_SCOLD:
      if (T.attnReason == ATT_DISCIPLINE) {
        sndPlay(SND_SCOLD_OK);
        if (T.discipline < 100) T.discipline = min(100, (int)T.discipline + 25);
        tamaClearAttention(ATT_DISCIPLINE);
        triggerEyeChomp();
      } else {
        sndPlay(SND_SCOLD_BAD);
        if (T.happy > 0) T.happy--;
        if (T.happy == 0) tamaRaiseAttention(ATT_HAPPY);
      }
      uiHudDirty = true; tDirty = true;
      break;
    case ICON_STATS:
      uiScreen = SCR_STATS_1;
      uiNeedsFullRedraw = true;
      break;
  }
}

// ----------------------------------------------------------------------------
//  BUTTON LOGIC  (A = cycle/left, B = select/middle, C = back/right, AC = combo)
// ----------------------------------------------------------------------------
// Leave the clock screen back to the face. Edited time is applied (RTC + NVS); if nothing was
// edited the clock catches up by the seconds spent here, so visiting never sets it backwards.
static void clockLeaveToFace() {
  if (clockEdited) {
    rtcSetFromPet();
  } else {
    uint32_t el = (millis() - clockEnterMs) / 1000UL;
    uint32_t t = ((uint32_t)T.clockHour * 3600UL + (uint32_t)T.clockMin * 60UL + T.clockSec + el) % 86400UL;
    T.clockHour = (uint8_t)(t / 3600UL);
    T.clockMin  = (uint8_t)((t % 3600UL) / 60UL);
    T.clockSec  = (uint8_t)(t % 60UL);
    clockPersist();
  }
  clockSetMode = false;
  clockSetField = 0;
  clockEdited = false;
  tamaSave();
  uiScreen = SCR_MAIN;
  selIcon = ICON_NONE;
  uiNeedsFullRedraw = true;
}

static void clockEnter() {
  clockSetMode = true;
  clockSetField = 0;
  clockEdited = false;
  clockEnterMs = millis();
  uiScreen = SCR_CLOCK;
  uiNeedsFullRedraw = true;
}

// CAL button on the clock screen: calibrate touch, then back to the face.
void onClockCal() {
  if (uiScreen != SCR_CLOCK) return;
  runTouchCal();
  clockLeaveToFace();
}

void onButtonA() {
  sndPlay(SND_NAV);
  if (uiScreen == SCR_MAIN) {
    if (T.species == SP_EGG) return;
    selIcon = (uint8_t)((selIcon + 1) % ICON_COUNT);
    uiHudDirty = true;
  } else if (uiScreen == SCR_FEED_MENU) {
    feedChoice = (feedChoice + 1) % 2;
    uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_GAME_HILO) {
    if (gameRevealState == 0) submitNumbersGuess(false);
  } else if (uiScreen == SCR_STATS_1) {
    uiScreen = SCR_STATS_2; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_STATS_2) {
    uiScreen = SCR_STATS_1; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_CLOCK) {
    if (clockSetMode) {
      if (clockSetField == 0) T.clockHour = (T.clockHour + 1) % 24;
      else if (clockSetField == 1) T.clockMin = (T.clockMin + 1) % 60;
      else T.clockSec = (T.clockSec + 1) % 60;
      clockEdited = true;
      tDirty = true;
      uiNeedsFullRedraw = true;
    } else {
      uiScreen = SCR_MAIN; uiNeedsFullRedraw = true;
    }
  }
}

void onButtonB() {
  sndPlay(SND_SELECT);
  if (uiScreen == SCR_MAIN) {
    if (selIcon == ICON_NONE) {
      clockEnter();
    } else {
      executeMenuIcon(selIcon);
    }
  } else if (uiScreen == SCR_FEED_MENU) {
    if (feedChoice == 0) actionFeedMeal();
    else actionFeedSnack();
    if (uiScreen == SCR_FEED_MENU) {
      uiScreen = SCR_MAIN;
      selIcon = ICON_NONE;
      uiNeedsFullRedraw = true;
    }
  } else if (uiScreen == SCR_GAME_HILO) {
    if (gameRevealState == 0) submitNumbersGuess(true);
    else if (gameRevealState == 2) finishNumbersGame();
  } else if (uiScreen == SCR_STATS_1) {
    uiScreen = SCR_STATS_2; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_STATS_2) {
    uiScreen = SCR_MAIN; selIcon = ICON_NONE; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_CLOCK) {
    if (clockSetMode) {
      clockSetField = (clockSetField + 1) % 3;
      uiNeedsFullRedraw = true;
    } else {
      uiScreen = SCR_MAIN; uiNeedsFullRedraw = true;
    }
  }
}

void onButtonC() {
  sndPlay(SND_BACK);
  if (uiScreen == SCR_MAIN) {
    if (selIcon != ICON_NONE) { selIcon = ICON_NONE; uiHudDirty = true; }
  } else if (uiScreen == SCR_GAME_HILO && gameRevealState == 2) {
    finishNumbersGame();
  } else if (uiScreen != SCR_DEAD) {
    if (uiScreen == SCR_CLOCK) { clockLeaveToFace(); return; }
    uiScreen = SCR_MAIN;
    selIcon = ICON_NONE;
    uiNeedsFullRedraw = true;
  }
}

void onButtonACCombo() {
  if (uiScreen == SCR_CLOCK) {
    onClockCal();                 // BOOT button hold 1.4 s = CAL on the clock screen
  } else if (uiScreen == SCR_DEAD || T.species == SP_DEAD) {
    sndPlay(SND_NEWEGG);
    tamaFreshEgg();
    tamaSave();
    uiScreen = SCR_MAIN;
    selIcon = ICON_NONE;
    uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_MAIN) {
    clockEnter();
  }
}

// ----------------------------------------------------------------------------
//  HARDWARE: I2C helpers
// ----------------------------------------------------------------------------
void i2cScan(TwoWire &w, const char* name) {
  Serial.printf("I2C scan (%s):", name);
  uint8_t found = 0;
  for (uint8_t a = 1; a < 127; a++) {
    w.beginTransmission(a);
    if (w.endTransmission() == 0) { Serial.printf(" 0x%02X", a); found++; }
  }
  if (!found) Serial.print(" (none)");
  Serial.println();
}

// ----------------------------------------------------------------------------
//  TOUCH: CST816D (I2C 0x15 on IIC_SDA/IIC_SCL, reset TP_RST, int TP_INT)
// ----------------------------------------------------------------------------
TwoWire* tpWire = &Wire;
bool tpOk = false;
bool touchDebug = false;

bool i2cProbe(TwoWire &w, uint8_t addr) {
  w.beginTransmission(addr);
  return w.endTransmission() == 0;
}

void touchBegin() {
  tpWire = &Wire;
  pinMode(TP_RST, OUTPUT);               // hardware reset of the touch controller
  digitalWrite(TP_RST, LOW);  delay(10);
  digitalWrite(TP_RST, HIGH); delay(60);
  tpOk = i2cProbe(Wire, TP_ADDR);
  if (tpOk) {
    tpWire->beginTransmission(TP_ADDR);   // disable auto-sleep so touch always answers
    tpWire->write(0xFE);
    tpWire->write(0x01);
    tpWire->endTransmission();
    Serial.println("Touch CST816D OK (0x15)");
  } else {
    Serial.println("WARN: CST816D (0x15) not found - use BOOT button instead");
  }
  pinMode(TP_INT_PIN, INPUT_PULLUP);
}

// returns true if a finger is down; px,py in panel-native coords (x 0..239, y 0..283)
bool touchRead(int16_t &px, int16_t &py) {
  if (!tpOk) return false;
  tpWire->beginTransmission(TP_ADDR);
  tpWire->write(0x01);
  if (tpWire->endTransmission() != 0) return false;
  if (tpWire->requestFrom((uint8_t)TP_ADDR, (uint8_t)6) != 6) return false;
  uint8_t b[6];
  for (uint8_t i = 0; i < 6; i++) b[i] = tpWire->read();
  if (b[1] == 0) return false;
  int16_t x = ((b[2] & 0x0F) << 8) | b[3];
  int16_t y = ((b[4] & 0x0F) << 8) | b[5];
#if JG_TOUCH_SWAP_XY
  { int16_t t = x; x = y; y = t; }
#endif
#if JG_TOUCH_FLIP_X
  x = PW - 1 - x;
#endif
#if JG_TOUCH_FLIP_Y
  y = PH - 1 - y;
#endif
  px = constrain(x, 0, PW - 1);
  py = constrain(y, 0, PH - 1);
  return true;
}

// panel-native -> logical (rotated) coordinates; matches Arduino_Canvas rotation
static bool  calValid = false, calCapturing = false;
static float calXa = 1, calXb = 0, calYa = 1, calYb = 0;

void touchToLogical(int16_t px, int16_t py, int16_t &lx, int16_t &ly) {
  if (JG_ROTATION == 1) { lx = py;          ly = PW - 1 - px; }
  else                  { lx = PH - 1 - py; ly = px; }
  if (calValid && !calCapturing) {                       // user calibration (2-point, per axis)
    long vx = lroundf(calXa * (float)lx + calXb);
    long vy = lroundf(calYa * (float)ly + calYb);
    lx = (int16_t)constrain(vx, 0L, (long)(SW - 1));
    ly = (int16_t)constrain(vy, 0L, (long)(SH - 1));
  }
}

static bool touchCalLoad() {
  Preferences p;
  if (!p.begin("jitter_cal", true)) return false;
  bool ok = p.isKey("xa") && p.isKey("xb") && p.isKey("ya") && p.isKey("yb");
  if (ok) {
    calXa = p.getFloat("xa", 1); calXb = p.getFloat("xb", 0);
    calYa = p.getFloat("ya", 1); calYb = p.getFloat("yb", 0);
    ok = (fabsf(calXa) > 0.2f && fabsf(calYa) > 0.2f && fabsf(calXa) < 5.0f && fabsf(calYa) < 5.0f);
  }
  p.end();
  calValid = ok;
  return ok;
}

struct TouchState {
  bool down = false;
  uint32_t downAt = 0;
  uint8_t zone = 0;        // 1=A 2=B 3=C 9=consumed
  bool comboFired = false;
  uint32_t lastPoll = 0;
  uint8_t missed = 0;
} tp;

static void calDrawTarget(int16_t x, int16_t y, const char* msg) {
  gfx->fillScreen(COL_BG);
  gfx->setTextSize(2);
  gfx->setTextColor(COL_WHITE, COL_BG);
  gfx->setCursor(40, 96);
  gfx->print("TOUCH CALIBRATION");
  gfx->setTextSize(1);
  gfx->setTextColor(COL_SILVER, COL_BG);
  gfx->setCursor(40, 126);
  gfx->print(msg);
  gfx->drawCircle(x, y, 10, COL_ACCENT);
  gfx->drawFastHLine(x - 16, y, 33, COL_WHITE);
  gfx->drawFastVLine(x, y - 16, 33, COL_WHITE);
  gfx->flush();
}

// wait for a press, average its logical position, wait for release
static bool calCapture(int16_t &cx, int16_t &cy) {
  int16_t px, py;
  uint32_t t0 = millis();
  while (!touchRead(px, py)) { if (millis() - t0 > 30000UL) return false; delay(10); }
  delay(120);
  int32_t sx = 0, sy = 0; uint8_t n = 0;
  for (uint8_t i = 0; i < 15; i++) {
    if (touchRead(px, py)) { int16_t lx, ly; touchToLogical(px, py, lx, ly); sx += lx; sy += ly; n++; }
    delay(15);
  }
  uint32_t r0 = millis();
  while (millis() - r0 < 250) { if (touchRead(px, py)) r0 = millis(); delay(10); }
  if (n < 5) return false;
  cx = (int16_t)(sx / n); cy = (int16_t)(sy / n);
  return true;
}

void runTouchCal() {
  if (!tpOk) return;                                      // no touch chip: nothing to calibrate
  { int16_t px, py; uint32_t w0 = millis(); while (touchRead(px, py) && millis() - w0 < 3000) delay(10); delay(250); }
  const int16_t X1 = 30, Y1 = 30, X2 = SW - 30, Y2 = SH - 30;
  int16_t ax = 0, ay = 0, bx = 0, by = 0;
  calCapturing = true;                                    // capture un-calibrated positions
  for (uint8_t attempt = 0; attempt < 3; attempt++) {
    calDrawTarget(X1, Y1, "Tap the crosshair (top-left)");
    if (!calCapture(ax, ay)) continue;
    calDrawTarget(X2, Y2, "Tap the crosshair (bottom-right)");
    if (!calCapture(bx, by)) continue;
    if (abs(bx - ax) < 80 || abs(by - ay) < 80) {
      calDrawTarget(X1, Y1, "Taps too close together - try again");
      delay(1200);
      continue;
    }
    calXa = (float)(X2 - X1) / (float)(bx - ax);
    calXb = (float)X1 - calXa * (float)ax;
    calYa = (float)(Y2 - Y1) / (float)(by - ay);
    calYb = (float)Y1 - calYa * (float)ay;
    calValid = true;
    { Preferences p;
      if (p.begin("jitter_cal", false)) {
        p.putFloat("xa", calXa); p.putFloat("xb", calXb);
        p.putFloat("ya", calYa); p.putFloat("yb", calYb);
        p.end();
      } }
    gfx->fillScreen(COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(0x07E0, COL_BG);
    gfx->setCursor(30, 110);
    gfx->print("CALIBRATION SAVED");
    gfx->flush();
    delay(1000);
    break;
  }
  calCapturing = false;
  tp.down = false; tp.missed = 0; tp.zone = 0; tp.comboFired = false;
  uiNeedsFullRedraw = true;
  uiHudDirty = true;
}

void serviceTouch() {
  uint32_t now = millis();
  if (now - tp.lastPoll < 20) return;
  tp.lastPoll = now;

  int16_t px, py;
  bool pressed = touchRead(px, py);

  if (pressed) {
    markActivity();
    tp.missed = 0;
    int16_t lx, ly;
    touchToLogical(px, py, lx, ly);
    if (touchDebug) Serial.printf("TOUCH raw=%d,%d logical=%d,%d\n", px, py, lx, ly);

    if (!tp.down) {
      tp.down = true;
      tp.downAt = now;
      tp.zone = 0;
      tp.comboFired = false;

      bool titleTap = (uiScreen == SCR_MAIN && ly < ICON_Y - 8);     // tap the title row = volume
      if (titleTap) {
        sndCycleLevel(); volShownAt = millis(); uiHudDirty = true; tp.zone = 9;
      } else if (uiScreen == SCR_MAIN) {
        triggerSmashAt(lx, ly);
      }
      bool iconBand = (ly >= ICON_Y - 6 && ly <= ICON_Y + ICON_H + 8 &&
                       lx >= ICON_X0 - 4 && lx < ICON_X0 + ICON_W * 7 + 4);
      if (!titleTap && uiScreen == SCR_MAIN && iconBand && T.species != SP_EGG && T.species != SP_DEAD) {
        int16_t cell = (lx - ICON_X0) / ICON_W;
        uint8_t picked = (uint8_t)constrain(cell, 0, 6) + 1;
        if (selIcon == picked) executeMenuIcon(picked);
        else { selIcon = picked; uiHudDirty = true; sndPlay(SND_NAV); }
        tp.zone = 9;
      } else if (!titleTap && ly >= BTN_Y - 10) {
        if (uiScreen == SCR_CLOCK) {
          // clock screen: four buttons (+1, H/M, RUN, CAL), all fire on press
          tp.zone = (uint8_t)(1 + constrain((lx - 4) / 70, 0, 3));
          tp.comboFired = true;                        // suppress B-on-release
          if (tp.zone == 1) onButtonA();
          else if (tp.zone == 2) onButtonB();
          else if (tp.zone == 3) onButtonC();
          else onClockCal();
        } else {
          tp.zone = (lx < SW / 3) ? 1 : ((lx < (2 * SW) / 3) ? 2 : 3);
          if (tp.zone == 1) onButtonA();
          else if (tp.zone == 3) onButtonC();
        }
      } else if (!titleTap && uiScreen == SCR_MAIN && ly > ICON_Y + ICON_H + 8 && ly < BTN_Y - 10 &&
                 !T.sleeping && !flipped && T.species != SP_EGG && T.species != SP_DEAD) {
        tp.zone = 8;                                   // petting
        petStart = now; petRewarded = false; petBurst = 10; petLastTouch = now;
        sndPlay(SND_PET); lastPetSnd = now;
      }
    } else if (tp.zone == 2 && !tp.comboFired && now - tp.downAt >= 1100) {
      tp.comboFired = true;              // long-press middle button = A+C combo
      onButtonACCombo();
    }
    if (tp.zone == 8) {                                // finger still on him
      petLastTouch = now;
      if (now - lastPetSnd > 900) { sndPlay(SND_PET); lastPetSnd = now; }
#if JG_PET_HAPPY
      if (!petRewarded && now - petStart >= 2000 && now - lastPetReward >= 60000UL && T.happy < JG_MAX_HEARTS) {
        petRewarded = true; lastPetReward = now;
        T.happy++; tamaClearAttention(ATT_HAPPY); uiHudDirty = true; tDirty = true;
      }
#endif
    }
  } else if (tp.down) {
    if (++tp.missed >= 2) {              // tolerate one dropped read
      if (tp.zone == 2 && !tp.comboFired) onButtonB();
      tp.down = false;
      tp.missed = 0;
    }
  }
}

// ----------------------------------------------------------------------------
//  BOOT BUTTON (GPIO0):  tap=A   double-tap=B   hold 0.55s=C   hold 1.4s=A+C
// ----------------------------------------------------------------------------
uint32_t btnPressAt = 0, btnShortAt = 0, btnDebounceAt = 0, lastBtnPoll = 0;
bool btnShortPending = false, btnRawPressed = false, btnStablePressed = false;

void serviceBootButton() {
  uint32_t now = millis();
  if (btnShortPending && now - btnShortAt >= 320) {
    btnShortPending = false;
    triggerSmash(-1, 0);
    onButtonA();
  }
  if (now - lastBtnPoll < 10) return;
  lastBtnPoll = now;

  bool pressed = (digitalRead(BOOT_BTN) == LOW);
  if (pressed) markActivity();
  if (pressed != btnRawPressed) { btnRawPressed = pressed; btnDebounceAt = now; }

  if (now - btnDebounceAt >= 30 && btnStablePressed != btnRawPressed) {
    btnStablePressed = btnRawPressed;
    if (btnStablePressed) {
      btnPressAt = now;
    } else {
      uint32_t held = now - btnPressAt;
      if (held >= 1400) { btnShortPending = false; onButtonACCombo(); }
      else if (held >= 550) { btnShortPending = false; triggerSmash(1, 0); onButtonC(); }
      else {
        if (btnShortPending && now - btnShortAt < 320) { btnShortPending = false; triggerSmash(0, 1); onButtonB(); }
        else { btnShortPending = true; btnShortAt = now; }
      }
    }
  }
}

// ----------------------------------------------------------------------------
//  MOTION SENSOR (QMI8658): tilt slides his eyes, shaking makes him dizzy
// ----------------------------------------------------------------------------
#if JG_IMU
static uint8_t imuAddr = 0;
static float imuTilt = 0.0f;
static float imuAx = 0, imuAy = 0, imuAz = 0, imuDot = 1.0f;
static uint32_t imuReads = 0, imuFails = 0;

static bool imuWrite(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(imuAddr); Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static bool imuReadAcc(float &ax, float &ay, float &az) {
  Wire.beginTransmission(imuAddr); Wire.write(0x35);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(imuAddr, (uint8_t)6) != 6) return false;
  uint8_t b[6];
  for (uint8_t i = 0; i < 6; i++) b[i] = Wire.read();
  ax = (int16_t)(b[0] | (b[1] << 8)) / 16384.0f;     // +-2 g range
  ay = (int16_t)(b[2] | (b[3] << 8)) / 16384.0f;
  az = (int16_t)(b[4] | (b[5] << 8)) / 16384.0f;
  return true;
}
void imuBegin() {
  const uint8_t cands[2] = {0x6B, 0x6A};
  for (uint8_t i = 0; i < 2 && !imuAddr; i++) {
    Wire.beginTransmission(cands[i]); Wire.write(0x00);
    if (Wire.endTransmission(false) != 0) continue;
    if (Wire.requestFrom(cands[i], (uint8_t)1) != 1) continue;
    if (Wire.read() == 0x05) imuAddr = cands[i];        // WHO_AM_I of the QMI8658
  }
  if (!imuAddr) { Serial.println("IMU: QMI8658 not found - tilt/shake off"); return; }
  imuWrite(0x02, 0x40);   // auto-increment
  imuWrite(0x08, 0x00);   // all sensors off while configuring
  delay(5);
  imuWrite(0x03, 0x05);   // accel +-2 g, 250 Hz
  imuWrite(0x04, 0x45);   // gyro +-512 dps, 250 Hz (some chips only run with both on)
  imuWrite(0x06, 0x00);   // no filters
  imuWrite(0x08, 0x03);   // accel + gyro on
  delay(40);
  Serial.printf("IMU: QMI8658 at 0x%02X\n", imuAddr);
  {
    float ax, ay, az;
    bool ok = imuReadAcc(ax, ay, az);
    Wire.beginTransmission(imuAddr); Wire.write(0x03); Wire.endTransmission(false);
    Wire.requestFrom(imuAddr, (uint8_t)1); int c2 = Wire.available() ? Wire.read() : -1;
    Wire.beginTransmission(imuAddr); Wire.write(0x08); Wire.endTransmission(false);
    Wire.requestFrom(imuAddr, (uint8_t)1); int c7 = Wire.available() ? Wire.read() : -1;
    Serial.printf("IMU: first read %s  acc=%.2f,%.2f,%.2f  CTRL2=%02X CTRL7=%02X (expect 05 and 03)\n", ok ? "ok" : "FAILED", ax, ay, az, c2, c7);
  }
}

void triggerDizzy() {
  static uint32_t winStart = 0, lastCrank = 0;
  static uint8_t count = 0;
  uint32_t now = millis();
  markActivity();
  if (uiScreen != SCR_MAIN || T.sleeping || T.species == SP_EGG || T.species == SP_DEAD || evoDanceActive) return;
  dizzyActive = true; dizzyAt = now;
  if (now - winStart > 120000UL) { winStart = now; count = 0; }
  count++;
  if (count >= 3 && now - lastCrank > 300000UL) {        // shaken too much: he gets cranky
    lastCrank = now; count = 0;
    if (T.happy > 0) T.happy--;
    if (T.happy == 0) tamaRaiseAttention(ATT_HAPPY);
    uiHudDirty = true; tDirty = true;
    sndPlay(SND_SCOLD_BAD);
  } else {
    sndPlay(SND_DIZZY);
  }
}

void serviceImu() {
  static uint32_t last = 0, firstSpike = 0, lastSpike = 0;
  static uint8_t spikes = 0;
  if (!imuAddr) return;
  uint32_t now = millis();
  if (now - last < 20) return;
  last = now;
  float ax, ay, az;
  if (!imuReadAcc(ax, ay, az)) { imuFails++; return; }
  imuReads++;

  // self-calibrating scale: whatever the sensor's units, a resting board reads "1.0"
  static float base = 0.0f;
  float mag = sqrtf(ax * ax + ay * ay + az * az);
  if (base < 0.01f) base = mag;
  base += (mag - base) * 0.01f;
  if (base > 0.05f) { ax /= base; ay /= base; az /= base; mag /= base; }
#if JG_SHAKE
  static uint32_t dizzyLockUntil = 0;
  if (fabsf(mag - 1.0f) > 1.2f && now - lastSpike > 80 && now > dizzyLockUntil) {   // hard jolt
    if (now - firstSpike > 600) { firstSpike = now; spikes = 0; }
    spikes++; lastSpike = now;
    if (spikes >= 5) { spikes = 0; dizzyLockUntil = now + 5000; triggerDizzy(); }
  }
#endif

  imuAx = ax; imuAy = ay; imuAz = az;
  // upside down? Compare gravity now with the "upright" gravity he has been learning (slow
  // average while not flipped). Works whatever way the sensor is mounted.
  {
    static float gx0 = 0, gy0 = 0, gz0 = 0;
    static bool gInit = false;
    static uint32_t flipSince = 0;
    if (!gInit) { gx0 = ax; gy0 = ay; gz0 = az; gInit = true; }
    float n0 = sqrtf(gx0 * gx0 + gy0 * gy0 + gz0 * gz0); if (n0 < 0.1f) n0 = 1.0f;
    float dot = (ax * gx0 + ay * gy0 + az * gz0) / n0;       // about +1 upright, about -1 flipped
    if (JG_IMU_FLIP_INVERT) dot = -dot;
    imuDot = dot;
    bool want = flipped ? (dot < -0.3f) : (dot < -0.65f);
    if (want != flipped) {
      if (!flipSince) flipSince = now;
      if (now - flipSince > 250) { flipped = want; flipSince = 0; markActivity(); }
    } else flipSince = 0;
    if (!flipped && dot > -0.3f) {                            // keep learning what "upright" is
      gx0 += (ax - gx0) * 0.0005f; gy0 += (ay - gy0) * 0.0005f; gz0 += (az - gz0) * 0.0005f;
    }
  }

  float t = (JG_ROTATION == 1) ? ax : -ax;            // tilt along the landscape x axis
  if (JG_IMU_INVERT) t = -t;
  if (fabsf(t) < 0.06f) t = 0;
  imuTilt += (t - imuTilt) * 0.2f;
  eyeTiltPx = (int16_t)constrain(imuTilt * 40.0f, -14.0f, 14.0f);
}
#else
void imuBegin() {}
void serviceImu() {}
#endif

// ----------------------------------------------------------------------------
//  DRAWING HELPERS (round-screen aware)
// ----------------------------------------------------------------------------
void ctext(int16_t y, const char* s, uint8_t size, uint16_t fg, uint16_t bg) {
  int16_t w = (int16_t)strlen(s) * 6 * size;
  gfx->setTextSize(size);
  gfx->setTextColor(fg, bg);
  gfx->setCursor((SW - w) / 2, y);
  gfx->print(s);
}

void ctextIn(int16_t x0, int16_t w, int16_t y, const char* s, uint8_t size, uint16_t fg, uint16_t bg) {
  int16_t tw = (int16_t)strlen(s) * 6 * size;
  gfx->setTextSize(size);
  gfx->setTextColor(fg, bg);
  gfx->setCursor(x0 + (w - tw) / 2, y);
  gfx->print(s);
}

void drawHeartRow(int16_t x, int16_t y, uint8_t count) {
  for (uint8_t i = 0; i < JG_MAX_HEARTS; i++) {
    uint16_t col = (i < count) ? COL_ACCENT : COL_DIM;
    int16_t hx = x + i * 18;
    gfx->fillCircle(hx + 3, y + 3, 3, col);
    gfx->fillCircle(hx + 9, y + 3, 3, col);
    gfx->fillTriangle(hx, y + 4, hx + 12, y + 4, hx + 6, y + 11, col);
  }
}

void drawButtons4(const char* l1, const char* l2, const char* l3, const char* l4) {
  gfx->fillRect(0, BTN_Y - 6, SW, SH - (BTN_Y - 6), COL_BG);
  const int16_t bw = 66, gap = 4;
  int16_t x0 = (SW - (4 * bw + 3 * gap)) / 2;
  const char* lbl[4] = {l1, l2, l3, l4};
  for (uint8_t i = 0; i < 4; i++) {
    int16_t bx = x0 + i * (bw + gap);
    gfx->fillRoundRect(bx, BTN_Y, bw, BTN_H, 5, COL_PANEL);
    gfx->drawRoundRect(bx, BTN_Y, bw, BTN_H, 5, i == 2 ? COL_ACCENT : COL_DIM);
    ctextIn(bx, bw, BTN_Y + 3, lbl[i], 2, i == 2 ? COL_WHITE : COL_SILVER, COL_PANEL);
  }
}

// ---------------------------------------------------------------------------
//  BATTERY (AXP2101 power chip on the system I2C bus, address 0x34)
// ---------------------------------------------------------------------------
#define AXP_ADDR 0x34
static bool    axpOk = false;
static int8_t  batPct = -1;          // -1 = unknown
static bool    batPresent = false, batCharging = false, vbusPresent = false;

static int16_t axpRead8(uint8_t reg) {
  Wire.beginTransmission(AXP_ADDR); Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return -1;
  if (Wire.requestFrom((uint8_t)AXP_ADDR, (uint8_t)1) != 1) return -1;
  return Wire.read();
}
static bool axpWrite8(uint8_t reg, uint8_t v) {
  Wire.beginTransmission(AXP_ADDR); Wire.write(reg); Wire.write(v);
  return Wire.endTransmission() == 0;
}
void axpBegin() {
  Wire.beginTransmission(AXP_ADDR);
  axpOk = (Wire.endTransmission() == 0);
  if (!axpOk) { Serial.println("BAT: AXP2101 not found"); return; }
  int16_t v;
  if ((v = axpRead8(0x18)) >= 0) axpWrite8(0x18, (uint8_t)v | 0x08);   // fuel gauge on
  if ((v = axpRead8(0x30)) >= 0) axpWrite8(0x30, (uint8_t)v | 0x01);   // VBAT ADC on
  Serial.println("BAT: AXP2101 ok");
}
static uint8_t batPctFromMv(uint16_t mv) {
  static const uint16_t MV[]  = {3300, 3600, 3700, 3750, 3800, 3850, 3950, 4050, 4200};
  static const uint8_t  PCT[] = {   0,    5,   15,   25,   40,   55,   70,   90,  100};
  if (mv <= MV[0]) return 0;
  for (uint8_t i = 1; i < 9; i++) {
    if (mv <= MV[i]) return PCT[i - 1] + (uint32_t)(mv - MV[i - 1]) * (PCT[i] - PCT[i - 1]) / (MV[i] - MV[i - 1]);
  }
  return 100;
}
void serviceBattery() {
  static uint32_t last = 0;
  uint32_t now = millis();
  if (last && now - last < 5000) return;
  last = now ? now : 1;
  if (!axpOk) return;
  int16_t st1 = axpRead8(0x00), st2 = axpRead8(0x01);
  if (st1 < 0 || st2 < 0) return;
  bool pres = (st1 & 0x08) != 0;
  bool vbus = (st1 & 0x20) != 0;
  bool chg  = ((st2 >> 5) & 0x07) == 0x01;
  int8_t pct = -1;
  if (pres) {
    int16_t g = axpRead8(0xA4);
    if (g >= 1 && g <= 100) pct = (int8_t)g;
    else {
      int16_t h = axpRead8(0x34), l = axpRead8(0x35);
      if (h >= 0 && l >= 0) {
        uint16_t mv = ((uint16_t)(h & 0x3F) << 8) | (uint16_t)l;
        if (mv > 2500 && mv < 4600) pct = (int8_t)batPctFromMv(mv);
      }
    }
  }
  if (pct != batPct || pres != batPresent || chg != batCharging || vbus != vbusPresent) {
    batPct = pct; batPresent = pres; batCharging = chg; vbusPresent = vbus;
    uiHudDirty = true;
  }
}
static void drawBatteryBar(int16_t x, int16_t y) {            // 28x12 icon + percent, top-right corner
  if (!batPresent) {
    gfx->setTextSize(1);
    gfx->setTextColor(COL_SILVER, COL_BG);
    gfx->setCursor(x + 14, y + 2);
    gfx->print(vbusPresent ? "USB" : "BAT?");
    return;
  }
  gfx->drawRect(x, y, 26, 12, COL_SILVER);
  gfx->fillRect(x + 26, y + 3, 2, 6, COL_SILVER);
  gfx->fillRect(x + 1, y + 1, 24, 10, COL_BG);
  if (batPct >= 0) {
    uint16_t c = batCharging ? 0x07E0 : (batPct > 50 ? 0x07E0 : (batPct > 20 ? COL_AMBER : 0xF800));
    int16_t w = (24 * batPct) / 100;
    if (w > 0) gfx->fillRect(x + 1, y + 1, w, 10, c);
  }
  gfx->setTextSize(1);
  gfx->setTextColor(batCharging ? 0x07E0 : COL_SILVER, COL_BG);
  gfx->setCursor(x + 32, y + 2);
  if (batPct >= 0) gfx->printf("%d%%", batPct); else gfx->print("--");
}

void drawButtons(const char* a, const char* b, const char* c) {
  gfx->fillRect(0, BTN_Y - 6, SW, SH - (BTN_Y - 6), COL_BG);
  const int16_t bw = 84, gap = 4;
  int16_t x0 = (SW - (3 * bw + 2 * gap)) / 2;
  const char* lbl[3] = {a, b, c};
  for (uint8_t i = 0; i < 3; i++) {
    int16_t bx = x0 + i * (bw + gap);
    gfx->fillRoundRect(bx, BTN_Y, bw, BTN_H, 5, COL_PANEL);
    gfx->drawRoundRect(bx, BTN_Y, bw, BTN_H, 5, i == 1 ? COL_ACCENT : COL_DIM);
    ctextIn(bx, bw, BTN_Y + 3, lbl[i], 2, i == 1 ? COL_WHITE : COL_SILVER, COL_PANEL);
  }
}

void drawMainHud() {
  static const char* const ICON_LBL[ICON_COUNT]  = { "", "FD", "GM", "DF", "LT", "PT", "SC", "ST" };
  static const char* const ICON_FULL[ICON_COUNT] = { "", "FEED", "GAME", "DFRAG", "LIGHT", "PATCH", "SCOLD", "STATS" };

  gfx->fillRect(0, 0, SW, 57, COL_BG);
  bool hideTop = (gEyeTop < EYE_CLIP_Y0);          // flipped: eyes use the top strip
  if (!hideTop) {
#if JG_SOUND
  if (volShownAt) {
    char vb[24];
    if (sndLevelPct() == 0) snprintf(vb, sizeof(vb), "SOUND: MUTE");
    else                    snprintf(vb, sizeof(vb), "VOLUME %u%%", sndLevelPct());
    ctext(6, vb, 2, COL_WHITE, COL_BG);
  } else
#endif
  if (selIcon != ICON_NONE) ctext(6, ICON_FULL[selIcon], 2, COL_WHITE, COL_BG);
  else                      ctext(6, "JITTERGOTCHI", 2, COL_SILVER, COL_BG);

  gfx->fillRoundRect(ICON_X0 - 2, ICON_Y - 2, ICON_W * 7 + 4, ICON_H + 4, 6, COL_PANEL);
  for (uint8_t i = 1; i < ICON_COUNT; i++) {
    int16_t ix = ICON_X0 + (i - 1) * ICON_W;
    bool active = (selIcon == i);
    uint16_t bg = active ? COL_ACCENT : COL_PANEL;
    if (active) gfx->fillRoundRect(ix + 1, ICON_Y, ICON_W - 2, ICON_H, 4, COL_ACCENT);
    ctextIn(ix, ICON_W, ICON_Y + 5, ICON_LBL[i], 2, active ? COL_WHITE : COL_SILVER, bg);
  }
  drawBatteryBar(222, 8);

  }

  gfx->fillRect(0, EYE_CLIP_Y1 + 1, SW, BTN_Y - EYE_CLIP_Y1 - 7, COL_BG);
  char buf[40];

  if (evoDanceActive && evoBanner[0]) {
    snprintf(buf, sizeof(buf), "EVOLVED:%s!", evoBanner);
    ctext(176, buf, 2, JC_YELLOW, COL_BG);
  } else if (T.species == SP_EGG) {
    uint32_t rem = (T.stageSec < 300) ? (300 - T.stageSec) : 0;
    ctext(154, "CYBER-EGG", 2, COL_SILVER, COL_BG);
    snprintf(buf, sizeof(buf), "HATCH IN %lum %02lus", (unsigned long)(rem / 60), (unsigned long)(rem % 60));
    ctext(176, buf, 2, COL_WHITE, COL_BG);
    snprintf(buf, sizeof(buf), "TIME %02u:%02u (%ux)", T.clockHour, T.clockMin, T.timeScale);
    ctext(202, buf, 1, COL_SILVER, COL_BG);
  } else {
    if (T.attnReason != ATT_NONE) {
      static const char* const ATT_TXT[5] = {"", "CALL:HUNGRY!", "CALL:BORED!", "CALL:LIGHTS!", "CALL:SCOLD!"};
      int16_t w = (int16_t)strlen(ATT_TXT[T.attnReason]) * 12 + 12;
      gfx->fillRoundRect((SW - w) / 2, 150, w, 20, 4, COL_ACCENT);
      ctext(153, ATT_TXT[T.attnReason], 2, COL_WHITE, COL_ACCENT);
    } else if (T.sleeping) {
      ctext(153, "SLEEPING Zzz", 2, COL_SILVER, COL_BG);
    } else {
      snprintf(buf, sizeof(buf), "WT %uoz DSC %u%%", T.weightOz, T.discipline);
      ctext(153, buf, 2, COL_SILVER, COL_BG);
    }

    gfx->setTextSize(2);
    gfx->setTextColor(COL_SILVER, COL_BG);
    gfx->setCursor(6, 171);    gfx->print("HNG");
    drawHeartRow(44, 172, T.hungry);
    gfx->setCursor(146, 171);  gfx->print("HAP");
    drawHeartRow(184, 172, T.happy);

    snprintf(buf, sizeof(buf), "%-11s %02u:%02u", SP_NAME[T.species], T.clockHour, T.clockMin);
    ctext(189, buf, 2, COL_WHITE, COL_BG);

    gfx->setTextSize(1);
    gfx->setTextColor(COL_AMBER, COL_BG);
    gfx->setCursor(20, 207);
    gfx->printf("XP:%lu", (unsigned long)Jx.v);
    if (T.poopCount > 0) {
      gfx->setTextColor(COL_AMBER, COL_BG);
      gfx->setCursor(90, 207);
      gfx->printf("FRAG:%u", T.poopCount);
    }
    if (T.sickDosesLeft > 0) {
      uint8_t st = (T.sickType >= SICK_CORRUPT && T.sickType <= SICK_MALWARE) ? T.sickType : SICK_CORRUPT;
      uint16_t badgeCol = (st == SICK_THERMAL) ? 0xC240 : ((st == SICK_MALWARE) ? 0x8010 : COL_ACCENT);
      gfx->fillRect(140, 204, 46, 12, badgeCol);
      gfx->setTextColor(COL_WHITE, badgeCol);
      gfx->setCursor(143, 207);
      gfx->printf("%s:%u", SICK_BADGE_TXT[st], T.sickDosesLeft);
    }
    uint16_t lbg = T.lightsOff ? 0x18E3 : COL_CRIMSON;
    gfx->fillRect(206, 204, 58, 12, lbg);
    gfx->setTextColor(T.lightsOff ? COL_SILVER : COL_WHITE, lbg);
    gfx->setCursor(212, 207);
    gfx->print(T.lightsOff ? "LITE:OFF" : "LITE:ON");
  }

  drawButtons("ICON", selIcon == ICON_NONE ? "TIME" : "PICK", "CLEAR");
  frameDirty = true;
}

void drawSubScreen() {
  gfx->fillScreen(COL_BG);
  char buf[40];

  if (uiScreen == SCR_FEED_MENU) {
    ctext(8, "FEED UNIT", 2, COL_ACCENT, COL_BG);
    static const char* const OPT[2] = {"PACKET +1HNG", "OVERCLK +1HAP"};
    static const char* const SUB[2] = {"+1 WEIGHT", "+2 WEIGHT"};
    for (uint8_t i = 0; i < 2; i++) {
      int16_t y = 40 + i * 64;
      if (feedChoice == i) gfx->fillRoundRect(30, y, 224, 50, 6, COL_ACCENT);
      else                 gfx->drawRoundRect(30, y, 224, 50, 6, COL_DIM);
      uint16_t bg = (feedChoice == i) ? COL_ACCENT : COL_BG;
      ctext(y + 9,  OPT[i], 2, (feedChoice == i) ? COL_WHITE : COL_SILVER, bg);
      ctext(y + 31, SUB[i], 1, (feedChoice == i) ? COL_WHITE : COL_DIM, bg);
    }
    drawButtons("NEXT", "FEED", "BACK");

  } else if (uiScreen == SCR_GAME_HILO) {
    snprintf(buf, sizeof(buf), "HI-LO %u/5", gameRound);
    ctext(6, buf, 2, COL_ACCENT, COL_BG);
    snprintf(buf, sizeof(buf), "WINS %u", gameWins);
    ctext(28, buf, 1, COL_SILVER, COL_BG);
    ctext(42, "IS THE RIGHT DIGIT LOWER OR HIGHER?", 1, COL_SILVER, COL_BG);

    gfx->drawRoundRect(34, 58, 94, 100, 8, COL_ACCENT);
    gfx->drawRoundRect(156, 58, 94, 100, 8, COL_SILVER);
    snprintf(buf, sizeof(buf), "%u", gameLeftNum);
    ctextIn(34, 94, 90, buf, 6, COL_WHITE, COL_BG);
    if (gameRevealState == 0) {
      ctextIn(156, 94, 90, "?", 6, COL_ACCENT, COL_BG);
    } else {
      snprintf(buf, sizeof(buf), "%u", gameRightNum);
      ctextIn(156, 94, 90, buf, 6, gameLastWon ? JC_GREEN : JC_RED, COL_BG);
    }

    if (gameRevealState == 2) {
      snprintf(buf, sizeof(buf), "SCORE %u/5 %s", gameWins, gameWins >= 5 ? "+2HAP" : (gameWins >= 3 ? "+1HAP" : "+0HAP"));
      ctext(176, buf, 2, JC_YELLOW, COL_BG);
      drawButtons("--", "DONE", "EXIT");
    } else {
      drawButtons("LOW", "HIGH", "QUIT");
    }

  } else if (uiScreen == SCR_STATS_1) {
    ctext(6, "STATUS", 2, COL_ACCENT, COL_BG);
    ctext(28, SP_NAME[T.species], 2, COL_SILVER, COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE, COL_BG);
    gfx->setCursor(20, 58);   gfx->printf("AGE  : %lu yr", (unsigned long)(T.ageSec / 86400UL));
    gfx->setCursor(20, 86);   gfx->printf("WT %u oz (MIN %u)", T.weightOz, SP_BASE_WT[T.species]);
    gfx->setCursor(20, 114);  gfx->printf("DISC : %u%%", T.discipline);
    gfx->setCursor(20, 142);  gfx->printf("CM/DM: %u / %u", T.careMistakes, T.discMistakes);
    uint8_t st = (T.sickDosesLeft > 0 && T.sickType <= SICK_MALWARE) ? T.sickType : SICK_NONE;
    gfx->setCursor(20, 170);  gfx->printf("STATE: %s", SICK_FULL_NAME[st]);
    drawButtons("PG2", "PG2", "FACE");

  } else if (uiScreen == SCR_STATS_2) {
    ctext(6, "HUNGRY & HAPPY", 2, COL_ACCENT, COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE, COL_BG);
    gfx->setCursor(20, 44);   gfx->printf("HUNGRY %u/%u", T.hungry, (unsigned)JG_MAX_HEARTS);
    drawHeartRow(170, 46, T.hungry);
    gfx->setCursor(20, 74);   gfx->printf("HAPPY  %u/%u", T.happy, (unsigned)JG_MAX_HEARTS);
    drawHeartRow(170, 76, T.happy);
    gfx->setCursor(20, 104);  gfx->printf("RF EXP %lu", (unsigned long)T.rfSignals);
    gfx->setTextSize(1);
    gfx->setTextColor(COL_SILVER, COL_BG);
    snprintf(buf, sizeof(buf), "SPEED:%ux  FRAG:%u/4  STAGE:%lum", T.timeScale, T.poopCount, (unsigned long)(T.stageSec / 60));
    ctext(150, buf, 1, COL_SILVER, COL_BG);
    snprintf(buf, sizeof(buf), "ID:%08lX  SAVE:NVS", (unsigned long)T.id);
    ctext(166, buf, 1, COL_SILVER, COL_BG);
    drawButtons("PG1", "FACE", "FACE");

  } else if (uiScreen == SCR_CLOCK) {
    ctext(12, "CLOCK SET [PAUSED]", 2, COL_ACCENT, COL_BG);
    snprintf(buf, sizeof(buf), "%02u:%02u:%02u", T.clockHour, T.clockMin, T.clockSec);
    ctext(50, buf, 5, JC_YELLOW, COL_BG);
    {
      int16_t ux = 22 + 90 * clockSetField;
      gfx->fillRect(ux, 94, 60, 4, COL_ACCENT);
      ctext(106, clockSetField == 0 ? "EDITING: HOUR    (AGING FROZEN)"
               : clockSetField == 1 ? "EDITING: MINUTE  (AGING FROZEN)"
                                    : "EDITING: SECOND  (AGING FROZEN)", 1, COL_SILVER, COL_BG);
      ctext(122, "RUN = APPLY + BACK TO FACE", 1, COL_SILVER, COL_BG);
      ctext(136, "CAL = CALIBRATE SCREEN, THEN FACE", 1, COL_SILVER, COL_BG);
      drawButtons4("+1", "H/M", "RUN", "CAL");
    }
    ctext(156, rtcState == 1 ? "RTC OK" : (rtcState == 2 ? "RTC LOST POWER - USING SAVED TIME" : "NO RTC CHIP FOUND"),
          1, rtcState == 1 ? COL_SILVER : JC_YELLOW, COL_BG);

  } else if (uiScreen == SCR_DEAD) {
    ctext(10, "SIGNAL LOST", 2, COL_ACCENT, COL_BG);
    ctext(32, "TERMINATED", 2, COL_ACCENT, COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE, COL_BG);
    gfx->setCursor(20, 70);   gfx->printf("UNIT : %s", SP_NAME[T.species]);
    gfx->setCursor(20, 98);   gfx->printf("AGE  : %lu yr", (unsigned long)(T.ageSec / 86400UL));
    const char* causeStr = (T.deathCause == 2) ? "THERMAL" : (T.deathCause == 3 ? "OLD AGE" : "CORRUPT");
    gfx->setCursor(20, 126);  gfx->printf("CAUSE: %s", causeStr);
    ctext(170, "HOLD [B] 1s FOR A NEW CYBER-EGG", 1, JC_YELLOW, COL_BG);
    drawButtons("--", "NEW", "--");
  }
  frameDirty = true;
}

void serviceDisplay() {
  if (volShownAt && millis() - volShownAt >= 1500) { volShownAt = 0; uiHudDirty = true; }
  if (uiScreen == SCR_GAME_HILO && gameRevealState == 1) {
    if (millis() - gameRevealAt >= 950) {
      if (gameRound < 5) {
        gameRound++;
        gameLeftNum = (uint8_t)random(1, 10);
        gameRightNum = (uint8_t)random(1, 10);
        gameRevealState = 0;
      } else {
        gameRevealState = 2;
      }
      uiNeedsFullRedraw = true;
    }
  }

  if (uiNeedsFullRedraw) {
    uiNeedsFullRedraw = false;
    if (uiScreen == SCR_MAIN) {
      gfx->fillScreen(COL_BG);
      staticN = 0;
      eyeHasLastDraw = false;
      drawMainHud();
      uiHudDirty = false;
    } else {
      drawSubScreen();
    }
  } else if (uiScreen == SCR_MAIN && uiHudDirty) {
    uiHudDirty = false;
    drawMainHud();
  }

  if (uiScreen == SCR_MAIN) serviceEyes();

  // Clock screen shows live seconds
  static uint8_t lastSecDrawn = 255;
  if (uiScreen == SCR_CLOCK && !clockSetMode && lastSecDrawn != T.clockSec) {
    lastSecDrawn = T.clockSec;
    uiNeedsFullRedraw = true;
  }

  uint32_t now = millis();
  if (frameDirty && now - lastFlushMs >= 25) {
    gfx->flush();
    frameDirty = false;
    lastFlushMs = now;
  }

  // Backlight: dim whenever the lights are off (and after idle)
  uint8_t bl = 255;
  if (T.lightsOff && T.species != SP_DEAD) bl = 25;
  else if (JG_DIM_MS && millis() - lastActivityMs >= JG_DIM_MS) bl = JG_DIM_LEVEL;
  backlightSet(bl);
}

void printTamaStatusSerial() {
  uint8_t st = (T.sickDosesLeft > 0 && T.sickType <= SICK_MALWARE) ? T.sickType : SICK_NONE;
  Serial.printf(
    "JITTER:id=%08lX;species=%s;age_yr=%lu;stage_s=%lu;hng=%u;hap=%u;wt=%u;"
    "disc=%u;cm=%u;dm=%u;frag=%u;sick=%u;sick_type=%s;sleep=%u;lights_off=%u;paused=%u;"
    "scale=%u;clock=%02u:%02u;rf=%lu;xp=%lu\n",
    (unsigned long)T.id, SP_NAME[T.species], (unsigned long)(T.ageSec / 86400UL),
    (unsigned long)T.stageSec, T.hungry, T.happy, T.weightOz, T.discipline,
    T.careMistakes, T.discMistakes, T.poopCount, T.sickDosesLeft, SICK_FULL_NAME[st],
    T.sleeping, T.lightsOff, (uiScreen == SCR_CLOCK && clockSetMode) ? 1 : 0, T.timeScale,
    T.clockHour, T.clockMin, (unsigned long)T.rfSignals, (unsigned long)Jx.v
  );
}

// ----------------------------------------------------------------------------
//  WI-FI "FOOD": passive scans -> RF signals (async, never blocks the UI)
// ----------------------------------------------------------------------------
#if JG_WIFI_FOOD
uint32_t lastScanStart = 0;
bool scanRunning = false;

// Foraging memory (RAM only, forgotten on reboot): a short hash of each network's
// hardware address + when it last paid out. No names or addresses are kept.
struct Seen { uint32_t h; uint32_t at; };
static Seen seenTab[64];
static uint8_t seenN = 0;

static uint32_t hashBssid(const uint8_t* b) {
  uint32_t h = 2166136261u;
  for (uint8_t i = 0; i < 6; i++) { h ^= b[i]; h *= 16777619u; }
  return h ? h : 1;
}
// true if this network is new (or its payout has expired); records it
static bool forageIsFresh(uint32_t h, uint32_t now) {
  int oldest = 0;
  for (uint8_t i = 0; i < seenN; i++) {
    if (seenTab[i].h == h) {
      if (now - seenTab[i].at >= JG_FORAGE_MS) { seenTab[i].at = now; return true; }
      return false;
    }
    if (now - seenTab[i].at > now - seenTab[oldest].at) oldest = i;
  }
  if (seenN < 64) seenTab[seenN++] = Seen{h, now};
  else            seenTab[oldest] = Seen{h, now};
  return true;
}

void serviceWifiFood() {
  uint32_t now = millis();
  if (!scanRunning) {
    if (now - lastScanStart >= JG_WIFI_SCAN_MS) {
      lastScanStart = now;
      WiFi.scanNetworks(true /*async*/, true /*show hidden*/);
      scanRunning = true;
    }
    return;
  }
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return;
  scanRunning = false;
  if (n > 0) {
#if JG_WIFI_HARD
    uint32_t now2 = millis();
    int fresh = 0;
    for (int i = 0; i < n; i++) {
      uint8_t* b = WiFi.BSSID(i);
      if (b && forageIsFresh(hashBssid(b), now2)) fresh++;
    }
    if (fresh > 0) {
      triggerEyeRfRx();
      rewardRfSignalActivity((uint8_t)min(fresh, 8));
    }
    Serial.printf("WIFI: %d networks, %d new -> +%d signal\n", n, fresh, min(fresh, 8));
#else
    triggerEyeRfRx();
    rewardRfSignalActivity((uint8_t)min(n, 8));
    Serial.printf("WIFI: %d networks -> +%d signal\n", n, min(n, 8));
#endif
  }
  WiFi.scanDelete();
}
#endif

// ----------------------------------------------------------------------------
//  SERIAL (same binary protocol as JitterBox6 'J' and 'Y' commands + a few
//  human-friendly lowercase debug keys)
// ----------------------------------------------------------------------------
int serialReadTimeout(uint32_t ms = 100) {
  uint32_t t0 = millis();
  while (!Serial.available() && millis() - t0 < ms) delay(1);
  return Serial.available() ? Serial.read() : -1;
}

void serviceSerial() {
  if (!Serial.available()) return;
  uint8_t cmd = Serial.read();

  if (cmd == 'J') {
    int sub = serialReadTimeout();
    if (sub < 0) { Serial.write('E'); return; }
    if (sub == 'S') printTamaStatusSerial();
    else if (sub == 'A') { onButtonA(); Serial.write('K'); }
    else if (sub == 'B') { onButtonB(); Serial.write('K'); }
    else if (sub == 'C') { onButtonC(); Serial.write('K'); }
    else if (sub == 'P') { onButtonACCombo(); Serial.write('K'); }
    else if (sub == 'I') { triggerEyeIrBlast(); Serial.write('K'); }
    else if (sub == 'T') {
      T.timeScale = (T.timeScale == 1) ? 10 : ((T.timeScale == 10) ? 60 : 1);
      uiHudDirty = true; tDirty = true;
      Serial.write('K');
    } else if (sub == 'X') {
      int k = serialReadTimeout();
      if (k == 0xA5) {
        tamaFreshEgg(); tamaSave();
        uiScreen = SCR_MAIN; selIcon = ICON_NONE; uiNeedsFullRedraw = true;
        Serial.write('K');
      } else Serial.write('E');
    } else Serial.write('E');
  } else if (cmd == 'Y') {
    // "Y<xp>\n" from JitterFood
    uint32_t t0 = millis(), xp = 0;
    while (millis() - t0 < 100) {
      if (!Serial.available()) { delay(1); continue; }
      char c = Serial.peek();
      if (c < '0' || c > '9') { Serial.read(); break; }
      xp = xp * 10 + (uint32_t)(Serial.read() - '0');
    }
    if (xp > 5000) xp = 5000;
    jxAward(xp);
    Serial.write('K');
  } else if (cmd == 'I') {
    triggerEyeIrBlast();
    Serial.write('K');
  } else if (cmd == 's') {
    printTamaStatusSerial();
  } else if (cmd == 'd') {
    touchDebug = !touchDebug;
    Serial.printf("touch debug %s\n", touchDebug ? "ON" : "OFF");
  } else if (cmd == 'r') {
    triggerEyeRfRx();
    rewardRfSignalActivity(25);
    Serial.println("simulated 25 RF signals");
  } else if (cmd == 'i') {
    i2cScan(Wire, "system bus");
  } else if (cmd == 'g') {                       // show motion sensor values
#if JG_IMU
    Serial.printf("acc x=%.2f y=%.2f z=%.2f dot=%.2f flipped=%d reads=%lu fails=%lu\n", imuAx, imuAy, imuAz, imuDot, (int)flipped, (unsigned long)imuReads, (unsigned long)imuFails);
#endif
  } else if (cmd == 'k') {                       // test the smash: left, right, down, up
    static uint8_t kd = 0; static const int8_t D[4][2] = {{-1,0},{1,0},{0,1},{0,-1}};
    triggerSmash(D[kd][0], D[kd][1]); kd = (kd + 1) % 4;
  }
#if JG_SOUND
  else if (cmd == 't') {                         // play every sound in turn
    static uint8_t tid = 0;
    Serial.printf("sound %u: %s\n", tid, SND_NAMES[tid]);
    sndPlay(tid); tid = (tid + 1) % SND_COUNT;
  } else if (cmd == 'v') {
    sndCycleLevel(); Serial.printf("volume %u%%\n", sndLevelPct());
  }
#endif
}

// repeat an unanswered alert every JG_SND_REMIND_MS (never for the bedtime call, never while asleep)
void serviceAlertReminder() {
  if (T.attnReason == ATT_NONE || T.attnReason == ATT_SLEEP || T.sleeping) return;
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  if (millis() - alertAt >= JG_SND_REMIND_MS) { alertAt = millis(); playAlert(T.attnReason); }
}

// ----------------------------------------------------------------------------
//  SETUP / LOOP
// ----------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 1500) delay(10);
  Serial.println("\nJITTERGOTCHI booting (Waveshare ESP32-S3-Touch-LCD-1.83)");

  pinMode(BOOT_BTN, INPUT_PULLUP);
  backlightInit();
  backlightSet(0);                       // stay dark until the first frame is ready

  Wire.begin(IIC_SDA, IIC_SCL);
  axpBegin();
  Wire.setClock(400000);
  Wire.setTimeOut(50);
  i2cScan(Wire, "system bus");

  touchBegin();
  touchCalLoad();
  sndInit();

  if (!gfx->begin()) {
    Serial.println("ERROR: display init failed (is PSRAM set to OPI?)");
  }
  gfx->setRotation(JG_ROTATION);
  gfx->setTextWrap(false);
  // quick R/G/B colour test so you can see the panel is alive
  { const uint16_t c[3] = { 0xF800, 0x07E0, 0x001F };
    for (uint8_t i = 0; i < 3; i++) { gfx->fillScreen(c[i]); gfx->flush(); if (i == 0) backlightSet(255); delay(250); } }
  gfx->fillScreen(COL_BG);
  gfx->flush();

  tamaLoad();
  rtcBoot();
  imuBegin();
  markActivity();
  jxLoad();
  initEyes();
  uiNeedsFullRedraw = true;

#if JG_WIFI_FOOD
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  lastScanStart = millis() - JG_WIFI_SCAN_MS + 8000;   // first scan ~8s after boot
#endif

  serviceDisplay();
  backlightSet(255);
  if (!inQuietHours()) sndPlay(SND_BOOT);
  Serial.printf("Ready. species=%s PSRAM=%u bytes free\n", SP_NAME[T.species], (unsigned)ESP.getFreePsram());
}

void loop() {
  serviceSerial();
  serviceTouch();
  serviceBootButton();
  tamaService();
  serviceImu();
  serviceRtcSync();
  serviceBattery();
  serviceDisplay();
  serviceAlertReminder();
#if JG_WIFI_FOOD
  serviceWifiFood();
#endif

  // batch XP saves (flash wear) and save pet when it matters
  if (jxDirty && millis() - jxLastSave > 10000UL) jxSave();
}
