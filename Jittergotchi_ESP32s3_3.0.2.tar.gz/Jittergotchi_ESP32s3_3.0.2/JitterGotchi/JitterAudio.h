// ============================================================================
//  JitterAudio.h  -  cyber sound set for the Waveshare ESP32-S3-Touch-LCD-1.83
//
//  Chain: ESP32-S3 I2S (16 kHz, 16-bit) -> ES8311 codec -> NS4150B amp -> speaker
//  Pins (from the board schematic):
//    I2S_MCLK GPIO16, I2S_SCLK(BCLK) GPIO9, I2S_LRCK(WS) GPIO45, I2S_DSDIN GPIO8,
//    PA_CTRL GPIO46 (amp enable), ES8311 on the shared I2C bus (0x18).
//  All sounds are synthesized on the fly (square/pulse/saw/triangle/noise sweeps),
//  so there are no audio files. A small FreeRTOS task on core 0 plays them.
// ============================================================================
#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>
#include "driver/i2s_std.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

#define SND_PIN_MCLK 16
#define SND_PIN_BCLK 9
#define SND_PIN_WS   45
#define SND_PIN_DOUT 8
#define SND_PIN_PA   46
#define SND_ES8311_ADDR 0x18
#define SND_RATE 16000

enum SndId : uint8_t {
  SND_NAV = 0, SND_SELECT, SND_BACK, SND_DENY,
  SND_EAT, SND_SNACK, SND_DEFRAG, SND_LIGHT_OFF, SND_LIGHT_ON, SND_PATCH,
  SND_SCOLD_OK, SND_SCOLD_BAD, SND_ROUND_WIN, SND_ROUND_LOSE, SND_FANFARE, SND_GAME_START,
  SND_ALERT_HUNGRY, SND_ALERT_BORED, SND_ALERT_LIGHTS, SND_ALERT_SCOLD,
  SND_SICK, SND_FRAG, SND_EVOLVE, SND_HATCH, SND_DEATH,
  SND_WAKE, SND_SLEEP, SND_SMASH, SND_VOL, SND_NEWEGG, SND_BOOT, SND_DIZZY, SND_PET, SND_THUD,
  SND_COUNT
};

static const char* const SND_NAMES[SND_COUNT] = {
  "nav", "select", "back", "deny", "eat", "snack", "defrag", "light-off", "light-on", "patch",
  "scold-ok", "scold-bad", "round-win", "round-lose", "fanfare", "game-start",
  "alert-hungry", "alert-bored", "alert-lights", "alert-scold",
  "sick", "fragment", "evolve", "hatch", "death",
  "wake", "sleep", "smash", "volume", "new-egg", "boot", "dizzy", "pet", "thud"
};

// ---------------------------------------------------------------------------
//  Sound data
// ---------------------------------------------------------------------------
enum : uint8_t { W_SQ = 0, W_PULSE, W_SAW, W_TRI, W_NOISE };

struct SndStep {
  int16_t  f0, f1;     // Hz at start/end of the step (noise: sample-hold rate); 0 = silence
  uint16_t ms;
  uint8_t  wave;
  uint8_t  vol;        // 0..255
  uint8_t  dec;        // 1 = linear decay over the step
  uint8_t  nz;         // 0..255 amount of noise mixed into a tone
};
struct SndDef { uint16_t start; uint16_t n; uint8_t prio; };

static SndStep sndPool[420];
static uint16_t sndPoolN = 0;
static SndDef sndDefs[SND_COUNT];
static uint8_t sndBuilding = 0;

static void sbBegin(uint8_t id, uint8_t prio) {
  sndBuilding = id;
  sndDefs[id].start = sndPoolN;
  sndDefs[id].n = 0;
  sndDefs[id].prio = prio;
}
static void sb(int f0, int f1, uint16_t ms, uint8_t wave, uint8_t vol = 200, uint8_t dec = 0, uint8_t nz = 0) {
  if (sndPoolN >= (sizeof(sndPool) / sizeof(sndPool[0]))) return;
  sndPool[sndPoolN++] = SndStep{(int16_t)f0, (int16_t)f1, ms, wave, vol, dec, nz};
  sndDefs[sndBuilding].n++;
}
static void sbGap(uint16_t ms) { sb(0, 0, ms, W_SQ, 0); }

static void sndBuildAll() {
  sndPoolN = 0;
  // ---- UI ticks (prio 2 so they cut through alerts, but not big animations)
  sbBegin(SND_NAV, 2);     sb(1500, 1900, 16, W_SQ, 150);
  sbBegin(SND_SELECT, 2);  sb(900, 900, 14, W_SQ, 170); sb(1500, 1500, 26, W_SQ, 170, 1);
  sbBegin(SND_BACK, 2);    sb(1600, 700, 34, W_SQ, 150, 1);
  sbBegin(SND_DENY, 2);    sb(190, 190, 70, W_SAW, 200); sbGap(25); sb(150, 140, 100, W_SAW, 200, 1);

  // ---- actions
  sbBegin(SND_EAT, 2);
  for (int i = 0; i < 3; i++) { sb(2600, 1800, 38, W_NOISE, 200, 1); sb(320, 200, 36, W_PULSE, 200, 1); }
  sb(1700, 2100, 28, W_SQ, 150, 1);

  sbBegin(SND_SNACK, 2);
  sb(900, 900, 30, W_PULSE, 190, 1); sbGap(10); sb(1200, 1200, 30, W_PULSE, 190, 1);
  sb(600, 1900, 70, W_SQ, 170, 1, 60); sb(3000, 3000, 22, W_NOISE, 120, 1);

  sbBegin(SND_DEFRAG, 2);
  sb(3200, 300, 170, W_SAW, 150, 1, 80); sbGap(20);
  for (int i = 0; i < 4; i++) { sb(2400, 2400, 10, W_SQ, 160); sbGap(25); }
  sb(1568, 1568, 45, W_SQ, 170); sb(2093, 2093, 80, W_SQ, 170, 1);

  sbBegin(SND_LIGHT_OFF, 2); sb(900, 180, 220, W_TRI, 220, 1);
  sbBegin(SND_LIGHT_ON, 2);  sb(180, 900, 200, W_TRI, 220); sb(900, 900, 40, W_TRI, 200, 1);

  sbBegin(SND_PATCH, 2);
  { const int f[8] = {800, 1200, 1000, 1600, 900, 1400, 1100, 1800};
    for (int i = 0; i < 8; i++) sb(f[i], f[i], 38, W_SQ, 150); }
  sbGap(25); sb(1760, 1760, 40, W_SQ, 170); sb(2349, 2349, 90, W_SQ, 170, 1);

  sbBegin(SND_SCOLD_OK, 2);  sb(420, 420, 70, W_SAW, 220); sb(300, 300, 70, W_SAW, 220); sb(160, 110, 160, W_SAW, 230, 1, 40);
  sbBegin(SND_SCOLD_BAD, 2); sb(130, 55, 260, W_SAW, 230, 1, 120);

  // ---- game
  sbBegin(SND_ROUND_WIN, 2);  sb(880, 880, 50, W_SQ, 170); sb(1320, 1320, 90, W_SQ, 170, 1);
  sbBegin(SND_ROUND_LOSE, 2); sb(330, 330, 70, W_SAW, 200); sb(220, 140, 140, W_SAW, 200, 1);
  sbBegin(SND_FANFARE, 2);
  { const int n[4] = {523, 659, 784, 1047};
    for (int i = 0; i < 4; i++) sb(n[i], n[i], 70, W_SQ, 180); }
  sb(1319, 1319, 260, W_SQ, 190, 1);
  sbBegin(SND_GAME_START, 2); sb(659, 659, 50, W_SQ, 170); sb(988, 988, 50, W_SQ, 170); sbGap(30); sb(1319, 1319, 90, W_SQ, 170, 1);

  // ---- alerts (prio 3)
  sbBegin(SND_ALERT_HUNGRY, 3);
  for (int i = 0; i < 3; i++) { sb(1100, 1100, 75, W_PULSE, 210); sbGap(55); }
  sbBegin(SND_ALERT_BORED, 3);
  sb(800, 520, 170, W_TRI, 220, 1); sbGap(60); sb(800, 520, 170, W_TRI, 220, 1);
  sbBegin(SND_ALERT_LIGHTS, 3);
  sb(700, 330, 260, W_TRI, 170, 1);
  sbBegin(SND_ALERT_SCOLD, 3);
  sb(450, 450, 60, W_SAW, 220); sbGap(30); sb(450, 450, 60, W_SAW, 220); sbGap(30); sb(680, 680, 120, W_SAW, 220, 1);

  sbBegin(SND_SICK, 3);
  for (int i = 0; i < 2; i++) { sb(2500, 2500, 25, W_NOISE, 180); sb(700, 300, 90, W_SQ, 160, 1, 70); }
  sbBegin(SND_FRAG, 2);
  sb(3000, 3000, 28, W_NOISE, 120, 1); sb(420, 300, 45, W_SQ, 140, 1, 40);

  // ---- big animations (prio 4/5)
  sbBegin(SND_EVOLVE, 4);
  sb(200, 1400, 420, W_SAW, 170, 0, 30);
  { const int n[7] = {523, 659, 784, 1047, 1319, 1568, 2093};
    for (int r = 0; r < 3; r++)
      for (int i = 0; i < 7; i++) { int f = n[i] * (r == 2 ? 2 : 1); sb(f, f, 55, W_SQ, 165, 1); } }
  for (int i = 0; i < 8; i++) { sb(1047, 1047, 30, W_SQ, 150); sb(1568, 1568, 30, W_SQ, 150); }
  sb(2093, 3136, 140, W_SQ, 150, 1); sb(3136, 3136, 200, W_TRI, 160, 1);

  sbBegin(SND_HATCH, 4);
  { const int c[4] = {2000, 2400, 2800, 3000}; const int g[4] = {90, 70, 50, 40};
    for (int i = 0; i < 4; i++) { sb(c[i], c[i], 22 + i * 6, W_NOISE, 220, 1); sbGap(g[i]); } }
  { const int n[4] = {392, 523, 659, 784};
    for (int i = 0; i < 4; i++) sb(n[i], n[i], 60, W_SQ, 170); }
  sb(1047, 1047, 200, W_TRI, 190, 1);

  sbBegin(SND_DEATH, 5);
  sb(880, 90, 950, W_SAW, 200, 1, 25); sb(1800, 200, 300, W_NOISE, 160, 1); sbGap(250); sb(1000, 1000, 700, W_SQ, 110);

  // ---- ambient / misc
  sbBegin(SND_WAKE, 2);  sb(440, 440, 60, W_SQ, 140); sb(660, 660, 60, W_SQ, 140); sb(880, 880, 100, W_SQ, 140, 1);
  sbBegin(SND_SLEEP, 2); sb(700, 250, 300, W_TRI, 130, 1);
  sbBegin(SND_SMASH, 2); sb(220, 40, 160, W_SAW, 255, 1, 200);
  sbBegin(SND_VOL, 2);   sb(1200, 1200, 45, W_SQ, 180, 1);
  sbBegin(SND_DIZZY, 2); sb(600, 1200, 90, W_TRI, 170); sb(1200, 500, 90, W_TRI, 170); sb(500, 1000, 90, W_TRI, 170); sb(1000, 400, 140, W_TRI, 170, 1);
  sbBegin(SND_PET, 1);  sb(800, 1300, 45, W_TRI, 110, 1); sbGap(15); sb(1100, 1700, 50, W_TRI, 110, 1);
  sbBegin(SND_THUD, 2); sb(150, 45, 110, W_TRI, 255, 1, 60);
  sbBegin(SND_NEWEGG, 3); sb(300, 900, 120, W_SAW, 170); sb(1319, 1319, 50, W_SQ, 170); sb(1760, 1760, 80, W_SQ, 170, 1);
  sbBegin(SND_BOOT, 3);
  sb(120, 1000, 200, W_SAW, 160, 0, 40);
  { const int n[4] = {440, 660, 880, 1320};
    for (int i = 0; i < 4; i++) sb(n[i], n[i], 55, W_SQ, 170); }
  sb(3200, 3200, 20, W_NOISE, 140, 1); sb(1760, 2640, 90, W_SQ, 170); sbGap(40);
  sb(1320, 1320, 40, W_SQ, 150); sb(1760, 1760, 160, W_SQ, 170, 1);
}

// ---------------------------------------------------------------------------
//  Engine
// ---------------------------------------------------------------------------
static i2s_chan_handle_t sndTx = nullptr;
static QueueHandle_t sndQueue = nullptr;
static bool sndReady = false;
static volatile uint8_t sndLevel = 2;                      // index into SND_LEVELS
static const uint8_t SND_LEVELS[5] = {0, 25, 50, 75, 100};  // percent; 0 = mute

static inline float sndGain() { float v = SND_LEVELS[sndLevel] / 100.0f; return v * v * 16000.0f; }   // max amplitude = 80% of the original (kid-safe cap)

// --- ES8311 minimal init (slave mode, MCLK from pin, 16 kHz, 16-bit I2S) ----
static bool es8311Write(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(SND_ES8311_ADDR);
  Wire.write(reg); Wire.write(val);
  return Wire.endTransmission() == 0;
}
static int es8311Read(uint8_t reg) {
  Wire.beginTransmission(SND_ES8311_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return -1;
  if (Wire.requestFrom((uint8_t)SND_ES8311_ADDR, (uint8_t)1) != 1) return -1;
  return Wire.read();
}

static bool es8311Init() {
  Wire.beginTransmission(SND_ES8311_ADDR);
  if (Wire.endTransmission() != 0) { Serial.println("AUDIO: ES8311 not found at 0x18"); return false; }
  Serial.printf("AUDIO: ES8311 chip id %02X %02X (expect 83 11)\n", es8311Read(0xFD), es8311Read(0xFE));

  bool ok = true;
  ok &= es8311Write(0x44, 0x08); ok &= es8311Write(0x44, 0x08);
  ok &= es8311Write(0x01, 0x30); ok &= es8311Write(0x02, 0x00); ok &= es8311Write(0x03, 0x10);
  ok &= es8311Write(0x16, 0x24); ok &= es8311Write(0x04, 0x10); ok &= es8311Write(0x05, 0x00);
  ok &= es8311Write(0x0B, 0x00); ok &= es8311Write(0x0C, 0x00); ok &= es8311Write(0x10, 0x1F);
  ok &= es8311Write(0x11, 0x7F);
  ok &= es8311Write(0x00, 0x80);                 // power on, slave mode
  delay(20);
  ok &= es8311Write(0x01, 0x3F);                 // clocks on, MCLK from pin
  // 16 kHz @ MCLK = 256*fs = 4.096 MHz
  ok &= es8311Write(0x02, 0x00);                 // pre_div 1, pre_mult x1
  ok &= es8311Write(0x05, 0x00);                 // adc/dac div 1
  ok &= es8311Write(0x03, 0x10);                 // adc osr
  ok &= es8311Write(0x04, 0x10);                 // dac osr
  ok &= es8311Write(0x07, 0x00);                 // lrck divider high
  ok &= es8311Write(0x08, 0xFF);                 // lrck divider low
  ok &= es8311Write(0x06, 0x03);                 // bclk divider 4
  ok &= es8311Write(0x09, 0x0C);                 // I2S, 16-bit in
  ok &= es8311Write(0x0A, 0x0C);                 // I2S, 16-bit out
  // power up analog + DAC path
  ok &= es8311Write(0x0D, 0x01); ok &= es8311Write(0x0E, 0x02); ok &= es8311Write(0x12, 0x00);
  ok &= es8311Write(0x13, 0x10); ok &= es8311Write(0x1C, 0x6A); ok &= es8311Write(0x37, 0x08);
  ok &= es8311Write(0x31, 0x00);                 // DAC unmuted
  ok &= es8311Write(0x32, 0xBF);                 // DAC volume 0 dB (volume is done in software)
  if (!ok) Serial.println("AUDIO: some ES8311 register writes failed (continuing)");
  return true;
}

// --- sequencer state (only touched by the audio task) ----------------------
static bool     snPlaying = false, snPaOn = false;
static uint8_t  snId = 0, snPrio = 0;
static uint16_t snStep = 0;
static uint32_t snPos = 0, snLen = 0, snLastEnd = 0;
static float    snPhase = 0.0f, snNoise = 0.0f;
static uint32_t snNoiseCnt = 0, snRng = 0x1234567;

static inline float snRand() {
  snRng = snRng * 1664525u + 1013904223u;
  return ((int32_t)(snRng >> 8) & 0xFFFF) / 32768.0f - 1.0f;
}

static void snLoadStep() { snPos = 0; snLen = (uint32_t)sndPool[sndDefs[snId].start + snStep].ms * (SND_RATE / 1000); if (!snLen) snLen = 1; }

static void snStart(uint8_t id) {
  if (id >= SND_COUNT || !SND_LEVELS[sndLevel]) return;
  snId = id; snPrio = sndDefs[id].prio; snStep = 0; snPhase = 0; snLoadStep();
  if (!snPaOn) {
    digitalWrite(SND_PIN_PA, HIGH); snPaOn = true;
    vTaskDelay(pdMS_TO_TICKS(10));
  }
  snPlaying = true;
}

static void snRender(int16_t* out, int frames) {
  const float gain = sndGain();
  for (int i = 0; i < frames; i++) {
    float s = 0.0f;
    if (snPlaying) {
      const SndStep& st = sndPool[sndDefs[snId].start + snStep];
      if (st.f0 != 0 || st.f1 != 0) {
        float t = (float)snPos / (float)snLen;
        float f = st.f0 + (st.f1 - st.f0) * t;
        float tone = 0.0f;
        if (st.wave == W_NOISE) {
          uint32_t hold = (uint32_t)(SND_RATE / (f < 200 ? 200 : f)); if (hold < 1) hold = 1;
          if (snNoiseCnt++ % hold == 0) snNoise = snRand();
          tone = snNoise;
        } else {
          snPhase += f / SND_RATE; if (snPhase >= 1.0f) snPhase -= 1.0f;
          switch (st.wave) {
            case W_SQ:    tone = snPhase < 0.5f ? 1.0f : -1.0f; break;
            case W_PULSE: tone = snPhase < 0.25f ? 1.0f : -1.0f; break;
            case W_SAW:   tone = 2.0f * snPhase - 1.0f; break;
            default:      tone = snPhase < 0.5f ? (4.0f * snPhase - 1.0f) : (3.0f - 4.0f * snPhase); break;
          }
          if (st.nz) { float k = st.nz / 255.0f; tone = tone * (1.0f - k) + snRand() * k; }
        }
        float env = 1.0f;
        if (snPos < 24) env = snPos / 24.0f;
        uint32_t rem = snLen - snPos;
        if (rem < 40) env *= rem / 40.0f;
        if (st.dec) env *= (1.0f - 0.9f * t);
        s = tone * env * (st.vol / 255.0f) * gain;
      }
      if (++snPos >= snLen) {
        if (++snStep >= sndDefs[snId].n) { snPlaying = false; snLastEnd = millis(); }
        else snLoadStep();
      }
    }
    int32_t v = (int32_t)s; if (v > 32000) v = 32000; if (v < -32000) v = -32000;
    out[2 * i] = (int16_t)v; out[2 * i + 1] = (int16_t)v;
  }
}

static void sndTask(void*) {
  static int16_t buf[256 * 2];
  size_t written;
  for (;;) {
    uint8_t id;
    if (!snPlaying) {
      if (xQueueReceive(sndQueue, &id, pdMS_TO_TICKS(100)) == pdTRUE) snStart(id);
      else {
        if (snPaOn && millis() - snLastEnd > 900) { digitalWrite(SND_PIN_PA, LOW); snPaOn = false; }
        continue;
      }
    } else {
      while (xQueueReceive(sndQueue, &id, 0) == pdTRUE) if (sndDefs[id].prio >= snPrio) snStart(id);
    }
    snRender(buf, 256);
    i2s_channel_write(sndTx, buf, sizeof(buf), &written, 1000);
  }
}

// ---------------------------------------------------------------------------
//  Public API
// ---------------------------------------------------------------------------
static void sndPlay(uint8_t id) {
  if (sndReady && sndQueue) xQueueSend(sndQueue, &id, 0);
}
static uint8_t sndLevelPct() { return SND_LEVELS[sndLevel]; }
static void sndSaveLevel() {
  Preferences p; if (p.begin("jitter_snd", false)) { p.putUChar("lvl", sndLevel); p.end(); }
}
static void sndCycleLevel() {
  sndLevel = (sndLevel + 1) % 5;
  sndSaveLevel();
  sndPlay(SND_VOL);
}

static bool sndInit() {
  pinMode(SND_PIN_PA, OUTPUT); digitalWrite(SND_PIN_PA, LOW);
  { Preferences p; if (p.begin("jitter_snd", true)) { uint8_t l = p.getUChar("lvl", 2); if (l < 5) sndLevel = l; p.end(); } }
  sndBuildAll();

  if (!es8311Init()) return false;

  i2s_chan_config_t cc = I2S_CHANNEL_DEFAULT_CONFIG(I2S_NUM_0, I2S_ROLE_MASTER);
  cc.auto_clear = true;
  if (i2s_new_channel(&cc, &sndTx, nullptr) != ESP_OK) { Serial.println("AUDIO: i2s_new_channel failed"); return false; }
  i2s_std_config_t sc = {
    .clk_cfg  = I2S_STD_CLK_DEFAULT_CONFIG(SND_RATE),
    .slot_cfg = I2S_STD_PHILIPS_SLOT_DEFAULT_CONFIG(I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO),
    .gpio_cfg = {
      .mclk = (gpio_num_t)SND_PIN_MCLK, .bclk = (gpio_num_t)SND_PIN_BCLK,
      .ws = (gpio_num_t)SND_PIN_WS, .dout = (gpio_num_t)SND_PIN_DOUT, .din = I2S_GPIO_UNUSED,
      .invert_flags = { .mclk_inv = false, .bclk_inv = false, .ws_inv = false },
    },
  };
  if (i2s_channel_init_std_mode(sndTx, &sc) != ESP_OK) { Serial.println("AUDIO: i2s init failed"); return false; }
  if (i2s_channel_enable(sndTx) != ESP_OK) { Serial.println("AUDIO: i2s enable failed"); return false; }

  sndQueue = xQueueCreate(8, sizeof(uint8_t));
  xTaskCreatePinnedToCore(sndTask, "snd", 4096, nullptr, 2, nullptr, 0);
  sndReady = true;
  Serial.printf("AUDIO: ready, volume %u%%\n", sndLevelPct());
  return true;
}
