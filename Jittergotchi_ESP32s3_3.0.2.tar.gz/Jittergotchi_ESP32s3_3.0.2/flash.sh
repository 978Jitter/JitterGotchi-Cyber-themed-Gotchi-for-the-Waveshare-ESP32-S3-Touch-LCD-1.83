#!/usr/bin/env bash
# Flash firmware_bin/ to the board. Rebuilds first if the binaries are missing or older than the
# sketch, so stale firmware can never be flashed by accident. Your saved pet, XP, clock and
# calibration (NVS) are NOT erased by flashing.
set -euo pipefail
export PATH="$HOME/.local/bin:$PATH"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN="$DIR/firmware_bin"
INO="$DIR/JitterGotchi/JitterGotchi.ino"
APP="$BIN/JitterGotchi.ino.bin"
MERGED="$BIN/JitterGotchi.ino.merged.bin"

if [ ! -f "$APP" ] || [ "$INO" -nt "$APP" ]; then
  echo "Binaries missing or older than the sketch - building first..."
  NOUPLOAD=1 bash "$DIR/build.sh"
fi

PORT="${1:-$(ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null | head -n 1 || true)}"
[ -n "$PORT" ] || { echo "No serial port found"; exit 1; }

# Kali's apt esptool can be missing its stub files; prefer a venv copy, else use --no-stub (slower, works).
if [ -x "$HOME/esp/bin/python" ]; then
  ESPTOOL=("$HOME/esp/bin/python" -m esptool); EXTRA=(--baud 921600)
else
  ESPTOOL=(python3 -m esptool); EXTRA=(--no-stub --baud 115200)
fi

if [ -f "$MERGED" ]; then
  "${ESPTOOL[@]}" --chip esp32s3 --port "$PORT" "${EXTRA[@]}" \
    --before default_reset --after hard_reset write_flash \
    --flash_mode keep --flash_freq keep --flash_size keep 0x0 "$MERGED"
else
  "${ESPTOOL[@]}" --chip esp32s3 --port "$PORT" "${EXTRA[@]}" \
    --before default_reset --after hard_reset write_flash \
    --flash_mode keep --flash_freq keep --flash_size keep \
    0x0 "$BIN/JitterGotchi.ino.bootloader.bin" \
    0x8000 "$BIN/JitterGotchi.ino.partitions.bin" \
    0x10000 "$APP"
fi
echo "Flashed."
