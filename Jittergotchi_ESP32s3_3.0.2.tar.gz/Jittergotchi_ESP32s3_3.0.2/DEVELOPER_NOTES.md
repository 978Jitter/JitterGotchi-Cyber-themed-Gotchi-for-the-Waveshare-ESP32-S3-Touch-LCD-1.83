# Developer notes (for future edits, by hand or by Claude)

Sketch: `JitterGotchi/JitterGotchi.ino` + `JitterAudio.h` + `pin_config.h` (all in the sketch folder).
**Before changing anything read FEATURES.md and keep `check_features.sh` passing - add a check for every new feature.**

Find by name: `tamaSave/tamaLoad/tamaService`, `rtcBoot/rtcSetFromPet/serviceRtcSync`, `clockPersist/clockRestore`,
`clockEnter/clockLeaveToFace/onClockCal`, `drawButtons/drawButtons4`, `drawSubScreen` (clock screen), `drawMainHud`,
`axpBegin/serviceBattery/drawBatteryBar`, `jxLoad/jxSave`, `touchToLogical/serviceTouch/runTouchCal` (calibration is applied
inside touchToLogical), backlight in `serviceDisplay`.

Gotchas: NVS `jitter_xp/v` is a u32 (not a blob). Clock set mode freezes pet aging, so leaving unedited advances the
clock by elapsed time. core 3.3.5 + GFX 1.6.9 are pinned. Claude cannot compile in its sandbox: run `bash build.sh` after edits.
