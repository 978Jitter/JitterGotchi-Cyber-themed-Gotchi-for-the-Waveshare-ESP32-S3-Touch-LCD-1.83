#!/usr/bin/env bash
# Regression guard. Every feature listed in FEATURES.md must still be in the sketch.
# build.sh runs this first and refuses to build if anything has been lost.
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
F="$DIR/JitterGotchi/JitterGotchi.ino"
fail=0
has()  { if grep -Eq -- "$2" "$F"; then echo "  ok    $1"; else echo "  MISSING  $1"; fail=1; fi; }
hasnt(){ if grep -Eq -- "$2" "$F"; then echo "  BAD   $1"; fail=1; else echo "  ok    $1"; fi; }
echo "==> Feature check"
has  "4-button clock (+1 H/M RUN CAL)"   'drawButtons4\("\+1", "H/M", "RUN", "CAL"\)'
hasnt "no FACE/FACE/FACE clock screen"    '"FACE", "FACE", "FACE"'
has  "clock seconds field"                'EDITING: SECOND'
has  "clock persistence (NVS)"            'static void clockPersist'
has  "clock restore on boot"              'clockRestore\(\)'
has  "RTC status on clock screen"         'RTC LOST POWER'
has  "leave clock without edits is safe"  'clockEdited'
has  "XP load fix"                        'Jx\.v = p\.getULong\("v", 0\)'
hasnt "old broken XP load"                'getBytesLength\("v"\)'
has  "XP namespace"                       'jitter_xp'
has  "XP saved within 10 s"               'jxLastSave > 10000UL'
has  "foraging Wi-Fi food on"             '#define JG_WIFI_FOOD +1'
has  "foraging hard mode on"              '#define JG_WIFI_HARD +1'
has  "dim when lights off"                'if \(T\.lightsOff && T\.species != SP_DEAD\) bl = 25'
has  "battery sampling"                   'void serviceBattery'
has  "battery bar drawn on main screen"   'drawBatteryBar\(222, 8\)'
has  "touch calibration"                  'void runTouchCal'
has  "CAL button action"                  'void onClockCal'
has  "touch cal loaded at boot"           'touchCalLoad\(\)'

if [ "$fail" != 0 ]; then echo "FEATURE CHECK FAILED - a previously working feature is missing. Not building."; exit 1; fi
echo "==> All features present"
