#!/usr/bin/env bash
# One-time setup (build.sh runs this automatically when needed). Safe to re-run.
set -e
export PATH="$HOME/.local/bin:$PATH"
if ! command -v arduino-cli >/dev/null 2>&1; then
  mkdir -p "$HOME/.local/bin"
  curl -fsSL https://raw.githubusercontent.com/arduino/arduino-cli/master/install.sh | BINDIR="$HOME/.local/bin" sh
  grep -q '.local/bin' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/.local/bin:$PATH"' >> "$HOME/.bashrc"
fi
arduino-cli config init 2>/dev/null || true
URL="https://espressif.github.io/arduino-esp32/package_esp32_index.json"
arduino-cli config dump | grep -q "$URL" || arduino-cli config add board_manager.additional_urls "$URL"
arduino-cli core update-index
# pinned: GFX Library 1.6.9 does not build on core 4.x
arduino-cli core list | awk '$1=="esp32:esp32"{print $2}' | grep -q '^3\\.3\\.5$' || arduino-cli core install esp32:esp32@3.3.5
arduino-cli lib install "GFX Library for Arduino"
if ! id -nG "$USER" | grep -qw dialout; then
  sudo usermod -aG dialout "$USER"; echo "Added you to 'dialout' - log out and back in once."
fi
echo "Setup done."
