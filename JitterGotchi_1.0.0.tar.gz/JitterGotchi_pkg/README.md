# JitterGotchi for Waveshare ESP32-S3-Touch-LCD-1.83 (240x284)

Port of the JitterBox6 pet (same species, evolutions, decay, XP and NVS save
format) to the Waveshare 1.83" SPI screen (ST7789P + CST816D). The UI is laid out
landscape (284x240), rotated 90 deg clockwise. Pins come from Waveshare's own `pin_config.h`.

> Not yet confirmed on hardware. On boot you should see a red/green/blue flash
> test, then the pet. If something is off, see Troubleshooting. Every
> fix is a one-line `#define` at the top of `JitterGotchi/JitterGotchi.ino`.

## Quick start (Kali)

```bash
unzip JitterGotchi.zip && cd JitterGotchi_pkg
./setup.sh        # once: arduino-cli + ESP32 core + display library
./flash.sh        # compile + upload (auto-detects /dev/ttyACM0)
./monitor.sh      # optional serial log
```

If `setup.sh` says it added you to `dialout`, log out/in once (or reboot).
If the board isn't detected: hold **BOOT**, tap **RESET**, release BOOT, then
run `./flash.sh` again.

First build downloads the ESP32 toolchain (a few hundred MB), so the first
run takes a while.

## Controls

| Action | Touch | BOOT button (GPIO0) |
|---|---|---|
| A (cycle icon / left) | tap lower-left | single tap |
| B (select / middle) | tap lower-middle | double tap |
| C (clear / back) | tap lower-right | hold 0.55 s |
| A+C combo (set clock, new egg) | **hold lower-middle 1 s** | hold 1.4 s |
| Pick icon directly | tap icon in top strip (tap twice to run it) | - |

Icons, left to right: FD feed, GM game, DF defrag, LT lights, PT patch,
SC scold, ST stats. The selected icon's full name shows above the strip.

## Differences from JitterBox6

- **Food**: no nRF24/CC1101, so "RF signals" come from passive Wi-Fi scans
  every 45 s (more networks seen = more food + XP). Set `JG_WIFI_FOOD 0` to
  turn it off; feeding from the menu still works.
- **Saves**: NVS only (same keys as before). The SD backup file is gone. Your
  old pet does not transfer from the ESP32-DIV, so this starts a new egg.
- **XP** is written to flash in batches (max once a minute) to spare the flash.
- **Backlight** dims when the pet sleeps with lights off.
- Removed: radios, IR, USB-HID/Ducky, NeoPixel health LEDs.
- Serial: the `J` pet commands and `Y<xp>` (JitterFood) still work.
  Extra debug keys: `s` status, `d` touch debug, `i` I2C scan, `r` fake 25
  signals. `JT` cycles time speed 1x/10x/60x (handy for testing evolutions).

## Settings (top of JitterGotchi.ino)

| Define | Meaning |
|---|---|
| `JG_ROTATION` | 1 = landscape, 90 deg clockwise (default). 3 = the other landscape (use if upside-down). |
| `JG_IPS_PANEL` | flip 1<->0 if colors look inverted |
| `JG_TOUCH_SWAP_XY / FLIP_X / FLIP_Y` | fix touch if taps land mirrored/rotated |
| `JG_WIFI_FOOD` | Wi-Fi scan feeding on/off |

Pins (LCD_DC 4, CS 5, SCK 6, MOSI 7, RST 38, BL 40, I2C 15/14, TP_RST 39,
TP_INT 13) live in `JitterGotchi/pin_config.h`, copied from Waveshare's demo.

## Troubleshooting

- **Build error in `Arduino_ESP32LCD8.cpp` (`int8_t` to `gpio_num_t`)**: the ESP32 core is
  4.x. Run `arduino-cli core install esp32:esp32@3.3.5` (setup.sh pins this now).

- **Backlight but no picture**: you should see a red/green/blue flash at boot.
  If not, check serial for `display init failed`. PSRAM must be OPI (scripts
  set it; in Arduino IDE use PSRAM = OPI PSRAM, Flash = 16MB, USB CDC On Boot
  = Enabled). If the image is shifted or a strip is garbage, try row offset 20
  in the `Arduino_ST7789(...)` line (`0, 20, 0, 0`).
- **Colors inverted**: flip `JG_IPS_PANEL`.
- **Touch does nothing**: `./monitor.sh`, press `i` (expect 0x15 and others on
  the I2C bus), press `d` and tap to see coordinates; use `JG_TOUCH_*` flags.
  The BOOT button always works as a fallback.
- **Won't compile on library errors**: `arduino-cli lib install "GFX Library for Arduino"`.
