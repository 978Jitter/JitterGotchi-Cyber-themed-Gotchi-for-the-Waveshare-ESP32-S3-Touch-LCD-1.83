#!/usr/bin/env bash
# One-time setup for Kali (ARM64 or x86). Safe to re-run.
set -e
cd "$(dirname "$0")"
source ./config.sh

echo "==> [1/4] arduino-cli"
if ! command -v arduino-cli >/dev/null 2>&1; then
  mkdir -p "$HOME/.local/bin"
  curl -fsSL https://raw.githubusercontent.com/arduino/arduino-cli/master/install.sh \
    | BINDIR="$HOME/.local/bin" sh
fi
arduino-cli version

echo "==> [2/4] ESP32 board package"
arduino-cli config init 2>/dev/null || true
URL="https://espressif.github.io/arduino-esp32/package_esp32_index.json"
arduino-cli config dump | grep -q "$URL" || arduino-cli config add board_manager.additional_urls "$URL"
arduino-cli core update-index
arduino-cli core install esp32:esp32@3.3.5   # pinned: GFX 1.6.9 does not build on core 4.x

echo "==> [3/4] Display library"
arduino-cli lib install "GFX Library for Arduino"

echo "==> [4/4] USB serial permission"
if ! id -nG "$USER" | grep -qw dialout; then
  sudo usermod -aG dialout "$USER"
  echo "Added you to the 'dialout' group. LOG OUT AND BACK IN (or reboot) once, or flash with sudo."
fi
if dpkg -s brltty >/dev/null 2>&1; then
  echo "NOTE: 'brltty' is installed and is known to steal ESP32 serial ports."
  echo "      If the board never shows up as /dev/ttyACM0 run:  sudo apt remove brltty"
fi

echo
echo "Setup done. Next:  ./flash.sh"
