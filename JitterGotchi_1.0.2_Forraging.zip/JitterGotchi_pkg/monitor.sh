#!/usr/bin/env bash
# Serial log (115200). Debug keys: s=status  d=touch debug  i=I2C scan  r=fake 25 signals
cd "$(dirname "$0")"
source ./config.sh
PORT="${1:-$(ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null | head -n1)}"
[ -z "$PORT" ] && { echo "No serial port found."; exit 1; }
arduino-cli monitor -p "$PORT" -c baudrate=115200
