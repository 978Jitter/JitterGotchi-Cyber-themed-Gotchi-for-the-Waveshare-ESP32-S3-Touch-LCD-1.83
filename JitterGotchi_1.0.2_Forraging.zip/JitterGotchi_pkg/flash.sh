#!/usr/bin/env bash
# Compile + upload.   ./flash.sh            (auto-detects the port)
#                     ./flash.sh /dev/ttyACM0
set -e
cd "$(dirname "$0")"
source ./config.sh
ensure_core

PORT="${1:-}"
if [ -z "$PORT" ]; then
  PORT="$(ls /dev/ttyACM* /dev/ttyUSB* 2>/dev/null | head -n1 || true)"
fi
if [ -z "$PORT" ]; then
  echo "No serial port found."
  echo "Plug the board into its USB-C port. If it still doesn't appear, force download mode:"
  echo "  hold BOOT, tap RESET (or plug USB in while holding BOOT), then release BOOT."
  exit 1
fi

echo "==> Compiling"
arduino-cli compile --fqbn "$FQBN" "$SKETCH_DIR"
echo "==> Uploading to $PORT"
arduino-cli upload -p "$PORT" --fqbn "$FQBN" "$SKETCH_DIR"
echo
echo "Done. Press RESET if it doesn't restart by itself."
echo "Serial log:  ./monitor.sh $PORT"
