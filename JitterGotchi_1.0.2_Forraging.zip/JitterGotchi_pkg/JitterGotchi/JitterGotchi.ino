// =============================================================================
//  JITTERGOTCHI  -  Waveshare ESP32-S3-Touch-LCD-1.83 port (240x284 SPI)
//  Ported from JitterBox6 (ESP32-DIV v2.1 / ILI9341). Pet logic, species,
//  evolutions, decay timers, XP and NVS save format are unchanged.
//
//  What changed vs JitterBox6:
//    - Display : ST7789P 240x284, plain SPI (Arduino_GFX + PSRAM canvas)
//    - Touch   : CST816D over I2C (was XPT2046)
//    - Buttons : BOOT button (GPIO0) replaces the PCF8574 center button
//    - UI      : landscape 284x240 (JG_ROTATION 1 or 3)
//    - Removed : nRF24 / CC1101 / IR / USB-HID / SD / NeoPixels
//    - Food    : "RF signals" now come from passive Wi-Fi scans (optional)
//
//  BUILD (see README):  PSRAM = OPI, Flash = 16MB, USB CDC On Boot = enabled
// =============================================================================

#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>
#include <esp_system.h>
#include <Arduino_GFX_Library.h>

// ----------------------------------------------------------------------------
//  USER SETTINGS
// ----------------------------------------------------------------------------
#define JG_ROTATION      1   // landscape: 1 = 90 deg clockwise, 3 = 270 (flip if it's upside-down)
#define JG_WIFI_FOOD     1   // 1 = passive Wi-Fi scans feed the pet (+XP)
#define JG_WIFI_SCAN_MS  45000UL
#define JG_WIFI_HARD     1   // 1 = foraging: only NEW networks feed him, and only hunger (0 = old easy mode)
#define JG_FORAGE_MS     3600000UL   // a network can pay out again after this long (1 hour)
#define JG_TOUCH_SWAP_XY 0   // touch axis fixes if taps land in the wrong place
#define JG_TOUCH_FLIP_X  0
#define JG_TOUCH_FLIP_Y  0
#define JG_IPS_PANEL     1   // if colors look inverted, flip this 1 <-> 0
#define JG_SOUND         1   // 1 = cyber sound set (ES8311 + speaker), 0 = silent
#define JG_SND_REMIND_MS 60000UL  // repeat an unanswered alert (hungry/bored/scold) this often

#if JG_WIFI_FOOD
#include <WiFi.h>
#endif

// ----------------------------------------------------------------------------
//  PINS - all LCD/touch pins come from Waveshare's own pin_config.h
//  (LCD_DC 4, LCD_CS 5, LCD_SCK 6, LCD_MOSI 7, LCD_RST 38, LCD_BL 40,
//   IIC_SDA 15, IIC_SCL 14, TP_RST 39, TP_INT 13)
// ----------------------------------------------------------------------------
#include "pin_config.h"

#if JG_SOUND
#include "JitterAudio.h"
#else
#define sndInit()        ((void)0)
#define sndPlay(x)       ((void)0)
#define sndCycleLevel()  ((void)0)
#endif

#define TP_ADDR    0x15         // CST816D
#define TP_INT_PIN TP_INT
#define BOOT_BTN   0
#define PW 240          // panel native size (portrait)
#define PH 284
#define SW 284          // logical size after rotation (landscape) - layout uses these
#define SH 240
#if (JG_ROTATION != 1) && (JG_ROTATION != 3)
#error "JG_ROTATION must be 1 or 3 (layout is landscape)"
#endif

// ----------------------------------------------------------------------------
//  DISPLAY: SPI ST7789P -> PSRAM canvas -> flush  (same setup as Waveshare's
//  01_HelloWorld: Arduino_ESP32SPI + Arduino_ST7789, IPS, offsets 0,0,0,0)
// ----------------------------------------------------------------------------
Arduino_DataBus *bus   = new Arduino_ESP32SPI(LCD_DC, LCD_CS, LCD_SCK, LCD_MOSI);
Arduino_GFX     *panel = new Arduino_ST7789(bus, LCD_RST, 0 /*rot*/, JG_IPS_PANEL,
                                            PW, PH, 0, 0, 0, 0);
Arduino_Canvas  *gfx   = new Arduino_Canvas(PW, PH, panel);

bool frameDirty = true;
uint32_t lastFlushMs = 0;

// colors (RGB565), same palette as JitterBox
const uint16_t COL_BG      = 0x0841;
const uint16_t COL_PANEL   = 0x1082;
const uint16_t COL_ACCENT  = 0x98C5;
const uint16_t COL_CRIMSON = 0x6043;
const uint16_t COL_DIM     = 0x3186;
const uint16_t COL_SILVER  = 0xBE18;
const uint16_t COL_WHITE   = 0xF79E;
const uint16_t COL_AMBER   = 0xFD20;
const uint16_t JC_RED      = 0xF800;
const uint16_t JC_ORANGE   = 0xFD20;
const uint16_t JC_YELLOW   = 0xFFE0;
const uint16_t JC_GREEN    = 0x07E0;
const uint16_t JC_CYAN     = 0x07FF;
const uint16_t JC_MAGENTA  = 0xF81F;

// layout (logical, after rotation) - everything is kept inside the circle
#define ICON_X0   9
#define ICON_W    38
#define ICON_Y    28
#define ICON_H    26
#define BTN_Y     220
#define BTN_H     20
#define EYE_CLIP_Y0  58
#define EYE_CLIP_Y1  148

// ----------------------------------------------------------------------------
//  STATE
// ----------------------------------------------------------------------------
struct JitterXpState { uint32_t v; uint32_t magic; };
JitterXpState Jx;
static const uint32_t JX_MAGIC = 0x58505850UL;
bool jxDirty = false;
uint32_t jxLastSave = 0;

enum CyberSpecies : uint8_t {
  SP_EGG = 0, SP_BITLING, SP_BYTEKIN, SP_SYNTHRA, SP_GLITCHLING, SP_AEGIS9,
  SP_PROXYFOX, SP_NULLMIND, SP_HEXHOUND, SP_VOIDCRAWLER, SP_ROTBIT, SP_ARCHONX, SP_DEAD
};

enum MenuIcon : uint8_t {
  ICON_NONE = 0, ICON_FEED, ICON_GAME, ICON_CLEAN, ICON_LIGHT, ICON_MEDS, ICON_SCOLD, ICON_STATS, ICON_COUNT
};

enum UIScreen : uint8_t {
  SCR_MAIN = 0, SCR_FEED_MENU, SCR_GAME_HILO, SCR_STATS_1, SCR_STATS_2, SCR_CLOCK, SCR_DEAD
};

enum AttentionReason : uint8_t { ATT_NONE = 0, ATT_HUNGRY, ATT_HAPPY, ATT_SLEEP, ATT_DISCIPLINE };

enum CyberSickType : uint8_t { SICK_NONE = 0, SICK_CORRUPT, SICK_THERMAL, SICK_MALWARE };

static const char* const SICK_BADGE_TXT[4] = { "", "CRPT", "THRM", "WORM" };
static const char* const SICK_FULL_NAME[4] = { "HEALTHY", "CORRUPT", "THERMAL", "MALWARE" };

#define TAMA_MAGIC 0x47454E33UL   // same as JitterBox6 -> same NVS layout

struct TamaState {
  uint32_t magic;
  uint32_t id;
  uint8_t  species;
  uint8_t  hungry;
  uint8_t  happy;
  uint8_t  discipline;
  uint8_t  weightOz;
  uint8_t  careMistakes;
  uint8_t  totalMistakes;
  uint8_t  discMistakes;
  uint8_t  poopCount;
  uint8_t  sickDosesLeft;
  uint8_t  sickType;
  uint8_t  snackCount;
  uint8_t  lightsOff;
  uint8_t  sleeping;
  uint8_t  babyNapDone;
  uint8_t  babySickDone;
  uint8_t  deathCause;
  uint8_t  timeScale;
  uint8_t  clockHour;
  uint8_t  clockMin;
  uint8_t  clockSec;
  uint32_t ageSec;
  uint32_t stageSec;
  uint32_t hungryAccSec;
  uint32_t happyAccSec;
  uint32_t poopAccSec;
  uint32_t discCallAccSec;
  uint32_t sickAccSec;
  uint32_t attnTimerSec;
  uint8_t  attnReason;
  uint32_t rfSignals;
};

TamaState T;
Preferences tPrefs;
bool tDirty = false;
uint32_t tLastSave = 0;
uint32_t tLastTickMs = 0;
uint32_t alertAt = 0;           // when the current alert last sounded
uint32_t volShownAt = 0;        // title shows the volume for a moment after a change
#define sfxQuiet(id) do { if (!T.sleeping) sndPlay(id); } while (0)   // not while he sleeps

uint8_t uiScreen = SCR_MAIN;
uint8_t selIcon = ICON_NONE;
uint8_t feedChoice = 0;
bool clockSetMode = false;
uint8_t clockSetField = 0;
bool uiNeedsFullRedraw = true;
bool uiHudDirty = true;

uint8_t gameRound = 0, gameWins = 0, gameLeftNum = 5, gameRightNum = 5, gameRevealState = 0;
uint32_t gameRevealAt = 0;
bool gameLastWon = false;

bool evoDanceActive = false;
uint32_t evoDanceStart = 0;
char evoBanner[28] = "";

static const char* const SP_NAME[13] = {
  "CYBER-EGG", "BITLING", "BYTEKIN", "SYNTHRA", "GLITCHLING",
  "AEGIS-9", "PROXYFOX", "NULLMIND", "HEXHOUND", "VOIDCRAWLER",
  "ROTBIT", "ARCHON-X", "CORE-DUMP"
};
static const uint8_t SP_BASE_WT[13]   = { 5, 5, 10, 20, 20, 30, 30, 30, 30, 30, 20, 30, 0 };
static const uint16_t SP_HEART_INT[13] = { 0, 240, 2700, 3600, 3000, 4800, 4200, 3600, 3900, 3300, 2400, 5400, 0 };
static const uint8_t SP_BED_HR[13]    = { 25, 25, 20, 21, 21, 22, 22, 22, 22, 22, 21, 23, 25 };
static const uint8_t SP_WAKE_HR[13]   = { 0, 0, 8, 8, 9, 8, 8, 9, 8, 9, 9, 8, 0 };

// ----------------------------------------------------------------------------
//  EYES
// ----------------------------------------------------------------------------
struct EyeHover { int16_t curX, curY, fromX, fromY, toX, toY; uint32_t moveStart, moveDur; };

const int16_t EYE_BASE_CX[2] = {96, 188};
const int16_t EYE_BASE_CY = 102;
const int16_t EYE_W = 52, EYE_H = 30;
const uint16_t EYE_FRAME_MS = 40;

EyeHover eyeHover[2];
uint32_t lastEyeFrame = 0;
bool eyeHasLastDraw = false;
int16_t lastDrawX[2], lastDrawY[2], lastDrawW[2], lastDrawH[2];
float eyeLid = 1.0f;
uint32_t eyeChompAt = 0;
bool eyeChomping = false;

// "smash into the wall" reaction when you press a button (direction = where you touched)
bool smashActive = false, smashHit = false;
uint32_t smashAt = 0;
int8_t smashDX = 0, smashDY = 0;
float gSqW = 1.0f, gSqH = 1.0f;                // squash factors used by drawEye
struct SRect { int16_t x, y, w, h; };
SRect staticR[2]; uint8_t staticN = 0;         // red static rectangles to erase next frame

void triggerSmash(int8_t dx, int8_t dy) {
  if (uiScreen != SCR_MAIN || T.sleeping || T.species == SP_DEAD || evoDanceActive) return;
  smashActive = true; smashHit = false; smashAt = millis(); smashDX = dx; smashDY = dy;
}
// lx,ly = touch position in logical (landscape) coordinates
void triggerSmashAt(int16_t lx, int16_t ly) {
  if (ly >= BTN_Y - 10) {                        // bottom buttons: A=left, B=down, C=right
    if (lx < SW / 3) triggerSmash(-1, 0);
    else if (lx < (2 * SW) / 3) triggerSmash(0, 1);
    else triggerSmash(1, 0);
    return;
  }
  float nx = (lx - SW / 2) / (SW / 2.0f), ny = (ly - 102) / 110.0f;
  if (fabsf(nx) >= fabsf(ny)) triggerSmash(nx < 0 ? -1 : 1, 0);
  else                        triggerSmash(0, ny < 0 ? -1 : 1);
}

uint32_t eyeRfRxAt = 0;  bool eyeRfRxActive = false;
uint32_t eyeRfTxAt = 0;  bool eyeRfTxActive = false;
uint32_t eyeIrAt = 0;    bool eyeIrActive = false;
uint8_t rfFeedBurstAcc = 0;

void tamaClearAttention(uint8_t reason);
void tamaRaiseAttention(uint8_t reason);
void tamaSave();

// ----------------------------------------------------------------------------
//  BACKLIGHT (PWM)
// ----------------------------------------------------------------------------
uint8_t blDuty = 0;
void backlightInit() {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(LCD_BL, 5000, 8);
#else
  ledcSetup(0, 5000, 8);
  ledcAttachPin(LCD_BL, 0);
#endif
}
void backlightSet(uint8_t duty) {
  if (duty == blDuty) return;
  blDuty = duty;
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(LCD_BL, duty);
#else
  ledcWrite(0, duty);
#endif
}

// ----------------------------------------------------------------------------
//  XP
// ----------------------------------------------------------------------------
void jxLoad() {
  memset(&Jx, 0, sizeof(Jx));
  Jx.magic = JX_MAGIC;
  Preferences p;
  if (p.begin("jitter_xp", true)) {
    if (p.getBytesLength("v") == sizeof(uint32_t)) Jx.v = p.getULong("v", 0);
    p.end();
  }
}
void jxSave() {
  Preferences p;
  if (p.begin("jitter_xp", false)) { p.putULong("v", Jx.v); p.end(); }
  jxDirty = false;
  jxLastSave = millis();
}
void jxAward(uint32_t n) {
  if (n == 0) return;
  Jx.v += n;
  jxDirty = true;          // saved in batches (flash wear), see loop()
  uiHudDirty = true;
}

// ----------------------------------------------------------------------------
//  EYE REACTIONS / REWARDS
// ----------------------------------------------------------------------------
float eyeEase(float t) { return t * t * (3.0f - 2.0f * t); }

void triggerEyeChomp() { eyeChomping = true; eyeChompAt = millis(); }

void triggerEyeRfRx() {
  uint32_t now = millis();
  if (!eyeRfRxActive || now - eyeRfRxAt > 180) { eyeRfRxActive = true; eyeRfRxAt = now; }
}
void triggerEyeRfTx() { eyeRfTxActive = true; eyeRfTxAt = millis(); }

void triggerEyeIrBlast() {
  eyeIrActive = true;
  eyeIrAt = millis();
  jxAward(5);
  if (T.species != SP_EGG && T.species != SP_DEAD && !T.sleeping && T.sickDosesLeft == 0) {
    if (T.attnReason == ATT_DISCIPLINE) {
      triggerEyeChomp();
    } else if (T.happy < 4) {
      T.happy++;
      tamaClearAttention(ATT_HAPPY);
      uiHudDirty = true;
      tDirty = true;
    }
  }
}

void rewardRfSignalActivity(uint8_t weight = 1) {
  T.rfSignals += weight;
  jxAward(weight);
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  if (T.sleeping || T.sickDosesLeft > 0) return;
  if (T.attnReason == ATT_DISCIPLINE) { triggerEyeChomp(); return; }

  rfFeedBurstAcc += weight;
  if (rfFeedBurstAcc >= 25) {
    rfFeedBurstAcc %= 25;
    if (T.hungry < 4) {
      T.hungry++;
      tamaClearAttention(ATT_HUNGRY);
      uiHudDirty = true; tDirty = true;
    }
#if !JG_WIFI_HARD
    else if (T.happy < 4) {
      T.happy++;
      tamaClearAttention(ATT_HAPPY);
      uiHudDirty = true; tDirty = true;
    }
#endif
  }
}

void triggerEvolutionDance(const char* newName) {
  evoDanceActive = true;
  evoDanceStart = millis();
  strncpy(evoBanner, newName, sizeof(evoBanner) - 1);
  evoBanner[sizeof(evoBanner) - 1] = 0;
  uiHudDirty = true;
}

void pickPairedHoverTarget(uint32_t now) {
  eyeHover[0].fromX = eyeHover[0].curX;
  eyeHover[0].fromY = eyeHover[0].curY;
  eyeHover[0].toX = EYE_BASE_CX[0] + (int16_t)random(-16, 17);
  eyeHover[0].toY = EYE_BASE_CY + (int16_t)random(-10, 11);
  eyeHover[0].moveStart = now;
  eyeHover[0].moveDur = 750 + (uint32_t)random(0, 750);
}

void initEyes() {
  randomSeed(micros());
  uint32_t now = millis();
  eyeHover[0].curX = EYE_BASE_CX[0];
  eyeHover[0].curY = EYE_BASE_CY;
  pickPairedHoverTarget(now);
  eyeHover[1].curX = EYE_BASE_CX[1];
  eyeHover[1].curY = EYE_BASE_CY;
  eyeHasLastDraw = false;
}

void stepPairedHover(uint32_t now) {
  uint32_t elapsed = now - eyeHover[0].moveStart;
  if (elapsed >= eyeHover[0].moveDur) { pickPairedHoverTarget(now); elapsed = 0; }
  float t = eyeEase((float)elapsed / (float)eyeHover[0].moveDur);
  eyeHover[0].curX = eyeHover[0].fromX + (int16_t)((eyeHover[0].toX - eyeHover[0].fromX) * t);
  eyeHover[0].curY = eyeHover[0].fromY + (int16_t)((eyeHover[0].toY - eyeHover[0].fromY) * t);
  eyeHover[1].curX = eyeHover[0].curX + (EYE_BASE_CX[1] - EYE_BASE_CX[0]);
  eyeHover[1].curY = eyeHover[0].curY;
}

void drawEye(int16_t cx, int16_t cy, bool leftEye, float openness, uint16_t color, float lid) {
  int16_t w = (int16_t)((EYE_W + (int16_t)(openness * 22)) * gSqW);
  int16_t hFull = EYE_H + (int16_t)(openness * 22);
  int16_t h = (int16_t)(hFull * lid * gSqH);
  if (h < 4) h = 4;
  int16_t x0 = cx - w / 2, y0 = cy - h / 2;

  gfx->fillRoundRect(x0, y0, w, h, h / 3, color);

  if (!evoDanceActive && lid > 0.6f) {
    int16_t slant = (int16_t)((1.0f - openness) * (h / 3));
    if (slant > 2) {
      if (leftEye) gfx->fillTriangle(x0, y0, x0 + w, y0, x0 + w, y0 + slant, COL_BG);
      else         gfx->fillTriangle(x0, y0, x0 + w, y0, x0, y0 + slant, COL_BG);
    }
  }
  if (T.species >= SP_BYTEKIN && T.species != SP_DEAD && h > 14) {
    gfx->fillRect(cx - 3, cy - (h * 32) / 100, 6, (h * 64) / 100, COL_BG);
  }
  if (T.species >= SP_SYNTHRA && T.species != SP_DEAD) {
    gfx->fillRect(x0, y0 - 7, w, 2, COL_CRIMSON);
  }
  if (T.species >= SP_AEGIS9 && T.species <= SP_ARCHONX) {
    gfx->fillCircle(leftEye ? x0 - 7 : x0 + w + 7, y0 - 3, 2, color);
  }

  if (T.poopCount > 0 && T.species != SP_EGG && T.species != SP_DEAD) {
    uint8_t fragLevel = min((uint8_t)4, T.poopCount);
    uint32_t phase = millis() / 90;
    uint8_t slices = fragLevel * 2 + 1;
    for (uint8_t s = 0; s < slices; s++) {
      int16_t sy = y0 + ((s * 7 + (phase % 5)) * max(1, (int)h - 3)) / (slices * 5 + 1);
      int16_t sh = (fragLevel >= 3) ? 3 : 2;
      int16_t sx = x0 + ((s * 13 + (leftEye ? 3 : 11) + (phase * 5)) % max(1, (int)w - 14));
      int16_t sw = 8 + fragLevel * 4;
      if (sx + sw > x0 + w) sw = (x0 + w) - sx;
      if (sw > 0 && sy + sh <= y0 + h) gfx->fillRect(sx, sy, sw, sh, COL_BG);
      if (fragLevel >= 2 && (s % 2 == 0)) {
        int16_t jx = ((s + phase + (leftEye ? 0 : 1)) & 1) ? (x0 + w - 2) : (x0 - 4);
        gfx->fillRect(jx, sy, 5, 2, color);
      }
    }
  }
}

void serviceEyes() {
  if (uiScreen != SCR_MAIN) return;
  uint32_t now = millis();
  if (now - lastEyeFrame < (smashActive ? 20 : EYE_FRAME_MS)) return;
  lastEyeFrame = now;

  if (evoDanceActive && (now - evoDanceStart >= 3200)) {
    evoDanceActive = false;
    evoBanner[0] = 0;
    uiHudDirty = true;
  }

  stepPairedHover(now);

  float lidTarget = 1.0f, openness = 0.0f;
  uint16_t color = COL_ACCENT;
  int16_t dx = 0, dy = 0;

  if (T.species == SP_EGG) {
    lidTarget = 0.35f; color = COL_SILVER;
    dx = (int16_t)(4.0f * sinf(now / 260.0f));
    eyeHover[0].curX = EYE_BASE_CX[0]; eyeHover[0].curY = EYE_BASE_CY;
    eyeHover[1].curX = EYE_BASE_CX[1]; eyeHover[1].curY = EYE_BASE_CY;
  } else if (T.sleeping) {
    lidTarget = 0.14f; color = COL_DIM;
    dy = (int16_t)(2.0f * sinf(now / 850.0f));
    eyeHover[0].curX = EYE_BASE_CX[0]; eyeHover[0].curY = EYE_BASE_CY;
    eyeHover[1].curX = EYE_BASE_CX[1]; eyeHover[1].curY = EYE_BASE_CY;
  } else if (T.sickDosesLeft > 0) {
    lidTarget = 0.45f;
    color = (T.sickType == SICK_THERMAL) ? JC_ORANGE : ((T.sickType == SICK_MALWARE) ? JC_MAGENTA : COL_AMBER);
  }

  if (eyeChomping) {
    uint32_t age = now - eyeChompAt;
    if (age >= 380) eyeChomping = false;
    else { openness = 0.65f; dx = (age < 190) ? 16 : 0; }
  }
  if (eyeRfRxActive) {
    uint32_t age = now - eyeRfRxAt;
    if (age >= 420) eyeRfRxActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.55f;
      color = ((age / 60) % 2 == 0) ? JC_CYAN : COL_WHITE;
      dx = (int16_t)(12.0f * sinf(age / 35.0f));
    }
  }
  if (eyeRfTxActive) {
    uint32_t age = now - eyeRfTxAt;
    if (age >= 500) eyeRfTxActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.70f;
      color = ((age / 70) % 2 == 0) ? COL_AMBER : JC_RED;
      dy = -6;
    }
  }
  if (eyeIrActive) {
    uint32_t age = now - eyeIrAt;
    if (age >= 650) eyeIrActive = false;
    else if (!T.sleeping) {
      lidTarget = 1.0f; openness = 0.85f;
      color = ((age / 55) % 2 == 0) ? JC_MAGENTA : JC_RED;
      dx = (int16_t)(8.0f * cosf(age / 25.0f));
      dy = (int16_t)(6.0f * sinf(age / 25.0f));
    }
  }
  if (evoDanceActive) {
    static const uint16_t RAINBOW[6] = { JC_RED, JC_ORANGE, JC_YELLOW, JC_GREEN, JC_CYAN, JC_MAGENTA };
    color = RAINBOW[(uint8_t)((now / 75) % 6)];
    openness = 0.75f + 0.25f * sinf(now / 60.0f);
    lidTarget = 1.0f;
    dx = (int16_t)(16.0f * cosf(now / 85.0f));
    dy = (int16_t)(10.0f * sinf(now / 65.0f));
  }

  // ---- smash: wind-up, lunge into the wall, squash + red static, rebound
  uint32_t smAge = 0;
  const uint32_t SM_WIND = 80, SM_LUNGE = 190, SM_HOLD = 400, SM_END = 680;
  gSqW = 1.0f; gSqH = 1.0f;
  if (smashActive) {
    smAge = now - smashAt;
    if (smAge >= SM_END) {
      smashActive = false;
    } else {
      lidTarget = 1.0f;
      openness = (smAge < SM_WIND) ? 0.45f : 0.05f;
      if (smAge >= SM_LUNGE && smAge < SM_HOLD) {
        float sq = 1.0f - (float)(smAge - SM_LUNGE) / (float)(SM_HOLD - SM_LUNGE);
        if (smashDX != 0) { gSqW = 1.0f - 0.35f * sq; gSqH = 1.0f + 0.25f * sq; }
        else              { gSqH = 1.0f - 0.40f * sq; gSqW = 1.0f + 0.20f * sq; }
        color = (smAge < SM_LUNGE + 70) ? COL_WHITE : JC_RED;
        if (!smashHit) { smashHit = true; sndPlay(SND_SMASH); }
      }
    }
  }

  eyeLid += (lidTarget - eyeLid) * 0.15f;

  int16_t newW = (int16_t)((EYE_W + (int16_t)(openness * 22)) * gSqW);
  int16_t newH = (int16_t)((EYE_H + (int16_t)(openness * 22)) * eyeLid * gSqH);
  if (newH < 4) newH = 4;

  if (smashActive) {
    const int16_t BACK = 10;
    int16_t sgn = (smashDX != 0) ? smashDX : smashDY;
    int16_t full;
    if (smashDX < 0)      full = 2 - (eyeHover[0].curX - newW / 2);               // left wall
    else if (smashDX > 0) full = (SW - 2) - (eyeHover[1].curX + newW / 2);        // right wall
    else if (smashDY > 0) full = EYE_CLIP_Y1 - (eyeHover[0].curY + newH / 2);     // floor of the eye area
    else                  full = EYE_CLIP_Y0 - (eyeHover[0].curY - newH / 2);     // ceiling
    float off;
    if (smAge < SM_WIND) {
      off = -(float)(sgn * BACK) * eyeEase((float)smAge / SM_WIND);
    } else if (smAge < SM_LUNGE) {
      float q = (float)(smAge - SM_WIND) / (float)(SM_LUNGE - SM_WIND);
      off = -(float)(sgn * BACK) + ((float)full + (float)(sgn * BACK)) * q * q;
    } else if (smAge < SM_HOLD) {
      off = (float)full;
    } else {
      float r = (float)(smAge - SM_HOLD) / (float)(SM_END - SM_HOLD);
      off = (float)full * (1.0f - eyeEase(r));
    }
    dx = (smashDX != 0) ? (int16_t)off : 0;
    dy = (smashDX != 0) ? 0 : (int16_t)off;
  }

  int16_t drawX[2] = {(int16_t)(eyeHover[0].curX + dx), (int16_t)(eyeHover[1].curX + dx)};
  int16_t drawY[2] = {(int16_t)(eyeHover[0].curY + dy), (int16_t)(eyeHover[1].curY + dy)};

  for (uint8_t k = 0; k < staticN; k++) gfx->fillRect(staticR[k].x, staticR[k].y, staticR[k].w, staticR[k].h, COL_BG);
  staticN = 0;

  const int16_t PAD = 12;
  for (uint8_t i = 0; i < 2; i++) {
    int16_t nx0 = drawX[i] - newW / 2 - PAD, nx1 = drawX[i] + newW / 2 + PAD;
    int16_t ny0 = drawY[i] - newH / 2 - PAD, ny1 = drawY[i] + newH / 2 + PAD;
    if (eyeHasLastDraw) {
      int16_t ox0 = lastDrawX[i] - lastDrawW[i] / 2 - PAD, ox1 = lastDrawX[i] + lastDrawW[i] / 2 + PAD;
      int16_t oy0 = lastDrawY[i] - lastDrawH[i] / 2 - PAD, oy1 = lastDrawY[i] + lastDrawH[i] / 2 + PAD;
      nx0 = min(nx0, ox0); nx1 = max(nx1, ox1);
      ny0 = min(ny0, oy0); ny1 = max(ny1, oy1);
    }
    if (ny0 < EYE_CLIP_Y0) ny0 = EYE_CLIP_Y0;
    if (ny1 > EYE_CLIP_Y1) ny1 = EYE_CLIP_Y1;
    if (nx0 < 2) nx0 = 2;
    if (nx1 > SW - 2) nx1 = SW - 2;
    gfx->fillRect(nx0, ny0, nx1 - nx0, ny1 - ny0, COL_BG);
    lastDrawX[i] = drawX[i]; lastDrawY[i] = drawY[i];
    lastDrawW[i] = newW;     lastDrawH[i] = newH;
  }
  eyeHasLastDraw = true;

  drawEye(drawX[0], drawY[0], true,  openness, color, eyeLid);
  drawEye(drawX[1], drawY[1], false, openness, color, eyeLid);

  // red static at the impact point
  if (smashActive && smashHit && smAge >= SM_LUNGE) {
    float inten = 1.0f - (float)(smAge - SM_LUNGE) / (float)(SM_HOLD + 140 - SM_LUNGE);
    if (inten > 0.0f) {
      int px[2], py[2]; uint8_t pn = 0;
      if (smashDX < 0)      { px[0] = drawX[0] - newW / 2; py[0] = drawY[0]; pn = 1; }
      else if (smashDX > 0) { px[0] = drawX[1] + newW / 2; py[0] = drawY[1]; pn = 1; }
      else for (uint8_t i = 0; i < 2; i++) {
        px[i] = drawX[i]; py[i] = drawY[i] + ((smashDY > 0) ? 1 : -1) * (newH / 2); pn = 2;
      }
      static const uint16_t REDS[4] = { JC_RED, 0xF800, 0xC000, 0x8000 };
      for (uint8_t k = 0; k < pn; k++) {
        int hx = (smashDX != 0) ? 16 : 30, hy = (smashDX != 0) ? 26 : 14;
        int rx0 = constrain(px[k] - hx, 0, SW), rx1 = constrain(px[k] + hx, 0, SW);
        int ry0 = constrain(py[k] - hy, EYE_CLIP_Y0, EYE_CLIP_Y1), ry1 = constrain(py[k] + hy, EYE_CLIP_Y0, EYE_CLIP_Y1);
        if (rx1 <= rx0 || ry1 <= ry0) continue;
        staticR[staticN++] = SRect{(int16_t)rx0, (int16_t)ry0, (int16_t)(rx1 - rx0), (int16_t)(ry1 - ry0)};
        int cnt = 8 + (int)(40.0f * inten);
        for (int c = 0; c < cnt; c++) {
          int x = random(rx0, rx1), y = random(ry0, ry1), w = random(1, 6), h = random(1, 3);
          if (x + w > rx1) w = rx1 - x;
          if (y + h > ry1) h = ry1 - y;
          gfx->fillRect(x, y, w, h, REDS[random(4)]);
        }
        if (inten > 0.35f) {
          for (int l = 0; l < 3; l++) {
            int y = random(ry0, ry1), x = random(rx0, rx1), len = random(8, 26);
            if (x + len > rx1) len = rx1 - x;
            gfx->fillRect(x, y, len, 1, JC_RED);
          }
        }
      }
    }
  }
  frameDirty = true;
}

// ----------------------------------------------------------------------------
//  PET LIFECYCLE / PERSISTENCE (NVS only - no SD in this port)
// ----------------------------------------------------------------------------
void tamaInflictSickness(uint8_t causeType, uint8_t doses) {
  sfxQuiet(SND_SICK);
  T.sickType = causeType;
  T.sickDosesLeft = doses;
  uiHudDirty = true;
  tDirty = true;
}

void tamaFreshEgg() {
  uint8_t prevScale = (T.timeScale == 1 || T.timeScale == 10 || T.timeScale == 60) ? T.timeScale : 1;
  uint8_t hr = T.clockHour < 24 ? T.clockHour : 12;
  uint8_t mn = T.clockMin < 60 ? T.clockMin : 0;
  memset(&T, 0, sizeof(T));
  T.magic = TAMA_MAGIC;
  T.id = (uint32_t)esp_random();
  T.species = SP_EGG;
  T.hungry = 4;
  T.happy = 4;
  T.weightOz = 5;
  T.sickType = SICK_NONE;
  T.timeScale = prevScale;
  T.clockHour = hr;
  T.clockMin = mn;
  tDirty = true;
}

void tamaSave() {
  if (tPrefs.begin("jitter_g3", false)) {
    tPrefs.putBytes("st", &T, sizeof(T));
    tPrefs.end();
  }
  if (jxDirty) jxSave();
  tDirty = false;
  tLastSave = millis();
}

void tamaLoad() {
  memset(&T, 0, sizeof(T));
  bool ok = false;
  if (tPrefs.begin("jitter_g3", true)) {
    if (tPrefs.getBytesLength("st") == sizeof(T)) {
      tPrefs.getBytes("st", &T, sizeof(T));
      ok = (T.magic == TAMA_MAGIC);
    }
    tPrefs.end();
  }
  if (!ok) {
    T.clockHour = 12; T.clockMin = 0; T.timeScale = 1;
    tamaFreshEgg();
    tamaSave();
  }
  if (T.species > SP_DEAD) T.species = SP_EGG;
  if (T.sickDosesLeft == 0) T.sickType = SICK_NONE;
  else if (T.sickType == SICK_NONE || T.sickType > SICK_MALWARE) T.sickType = SICK_CORRUPT;
  if (T.timeScale != 1 && T.timeScale != 10 && T.timeScale != 60) T.timeScale = 1;
  if (T.species == SP_DEAD) uiScreen = SCR_DEAD;
}

void playAlert(uint8_t reason) {
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  if (T.sleeping && reason != ATT_SLEEP) return;          // quiet while asleep (except the bedtime lights call)
  switch (reason) {
    case ATT_HUNGRY:     sndPlay(SND_ALERT_HUNGRY); break;
    case ATT_HAPPY:      sndPlay(SND_ALERT_BORED);  break;
    case ATT_SLEEP:      sndPlay(SND_ALERT_LIGHTS); break;
    case ATT_DISCIPLINE: sndPlay(SND_ALERT_SCOLD);  break;
  }
}

void tamaRaiseAttention(uint8_t reason) {
  if (T.attnReason == ATT_NONE) {
    T.attnReason = reason;
    T.attnTimerSec = 900;
    uiHudDirty = true;
    alertAt = millis();
    playAlert(reason);
  }
}

void tamaClearAttention(uint8_t reason) {
  if (reason == ATT_NONE || T.attnReason == reason) {
    T.attnReason = ATT_NONE;
    T.attnTimerSec = 0;
    uiHudDirty = true;
  }
}

void tamaKill(uint8_t cause) {
  sndPlay(SND_DEATH);
  T.species = SP_DEAD;
  T.deathCause = cause;
  T.sleeping = 0;
  T.attnReason = ATT_NONE;
  selIcon = ICON_NONE;
  uiScreen = SCR_DEAD;
  uiNeedsFullRedraw = true;
  tDirty = true;
  tamaSave();
}

void tamaEvolveTo(uint8_t nextSpecies) {
  bool wasEgg = (T.species == SP_EGG);
  T.species = nextSpecies;
  T.stageSec = 0;
  T.careMistakes = 0;
  T.discMistakes = 0;
  T.snackCount = 0;
  if (T.weightOz < SP_BASE_WT[nextSpecies]) T.weightOz = SP_BASE_WT[nextSpecies];
  triggerEvolutionDance(SP_NAME[nextSpecies]);
  sndPlay(wasEgg ? SND_HATCH : SND_EVOLVE);
  uiHudDirty = true;
  tDirty = true;
  tamaSave();
}

void tamaCheckEvolutions() {
  uint8_t sp = T.species;
  if (sp == SP_EGG) {
    if (T.stageSec >= 300) {
      T.hungry = 4; T.happy = 4; T.weightOz = 5;
      tamaEvolveTo(SP_BITLING);
    }
  } else if (sp == SP_BITLING) {
    if (!T.babyNapDone && T.stageSec >= 1800 && T.stageSec < 2400) {
      T.sleeping = 1; T.babyNapDone = 1; uiHudDirty = true;
    } else if (T.sleeping && T.stageSec >= 2400) {
      T.sleeping = 0; T.lightsOff = 0; uiHudDirty = true;
    }
    if (!T.babySickDone && T.stageSec >= 2700) {
      tamaInflictSickness(SICK_MALWARE, 2);
      T.babySickDone = 1;
    }
    if (T.stageSec >= 3900) {
      T.sleeping = 0; T.lightsOff = 0;
      sndPlay(SND_WAKE);
      tamaEvolveTo(SP_BYTEKIN);
    }
  } else if (sp == SP_BYTEKIN) {
    if (T.stageSec >= 172800UL) {
      if (T.careMistakes <= 2 && T.discipline >= 75) tamaEvolveTo(SP_SYNTHRA);
      else tamaEvolveTo(SP_GLITCHLING);
    }
  } else if (sp == SP_SYNTHRA) {
    if (T.stageSec >= 259200UL) {
      if (T.careMistakes == 0 && T.discipline == 100) tamaEvolveTo(SP_AEGIS9);
      else if (T.careMistakes <= 2 && T.discipline >= 75) tamaEvolveTo(SP_PROXYFOX);
      else tamaEvolveTo(SP_NULLMIND);
    }
  } else if (sp == SP_GLITCHLING) {
    if (T.stageSec >= 259200UL) {
      if (T.careMistakes <= 2 && T.discipline >= 75) tamaEvolveTo(SP_HEXHOUND);
      else if (T.careMistakes <= 4) tamaEvolveTo(SP_VOIDCRAWLER);
      else tamaEvolveTo(SP_ROTBIT);
    }
  } else if (sp == SP_NULLMIND) {
    if (T.stageSec >= 172800UL && T.careMistakes == 0 && T.discipline == 100) {
      tamaEvolveTo(SP_ARCHONX);
    }
  }
}

void tamaService() {
  uint32_t now = millis();
  if (tLastTickMs == 0) tLastTickMs = now;
  if (now - tLastTickMs < 1000) return;

  uint32_t realElapsed = (now - tLastTickMs) / 1000;
  tLastTickMs += realElapsed * 1000;

  if (uiScreen == SCR_CLOCK && clockSetMode) return;
  if (T.species == SP_DEAD) return;

  uint32_t dt = realElapsed * (uint32_t)T.timeScale;

  uint32_t totalDaySec = (uint32_t)T.clockHour * 3600UL + (uint32_t)T.clockMin * 60UL + (uint32_t)T.clockSec + dt;
  totalDaySec %= 86400UL;
  T.clockHour = (uint8_t)(totalDaySec / 3600UL);
  T.clockMin  = (uint8_t)((totalDaySec % 3600UL) / 60UL);
  T.clockSec  = (uint8_t)(totalDaySec % 60UL);

  T.ageSec += dt;
  T.stageSec += dt;
  tDirty = true;

  if (T.species == SP_EGG) {
    tamaCheckEvolutions();
    uiHudDirty = true;
    return;
  }

  uint8_t bedHr = SP_BED_HR[T.species];
  uint8_t wakeHr = SP_WAKE_HR[T.species];
  if (bedHr <= 23) {
    bool shouldSleep = (T.clockHour >= bedHr || T.clockHour < wakeHr);
    if (shouldSleep && !T.sleeping) {
      T.sleeping = 1;
      sndPlay(SND_SLEEP);
      if (!T.lightsOff) tamaRaiseAttention(ATT_SLEEP);
      uiHudDirty = true;
    } else if (!shouldSleep && T.sleeping) {
      T.sleeping = 0; T.lightsOff = 0;
      tamaClearAttention(ATT_SLEEP);
      uiHudDirty = true;
    }
  }

  if (T.attnReason != ATT_NONE) {
    if (T.attnTimerSec > dt) {
      T.attnTimerSec -= dt;
    } else {
      uint8_t expired = T.attnReason;
      T.attnReason = ATT_NONE;
      T.attnTimerSec = 0;
      if (expired == ATT_DISCIPLINE) T.discMistakes++;
      else { T.careMistakes++; T.totalMistakes++; }
      uiHudDirty = true;
    }
  }

  if (!T.sleeping) {
    uint32_t heartInterval = SP_HEART_INT[T.species];
    uint32_t ageDays = T.ageSec / 86400UL;
    if (T.species >= SP_AEGIS9 && ageDays >= 10 && heartInterval > 300) {
      uint32_t accel = (ageDays - 9) * 350;
      heartInterval = (heartInterval > accel + 240) ? (heartInterval - accel) : 240;
    }

    T.hungryAccSec += dt;
    if (T.hungryAccSec >= heartInterval) {
      T.hungryAccSec %= heartInterval;
      if (T.hungry > 0) {
        T.hungry--;
        if (T.hungry == 0) tamaRaiseAttention(ATT_HUNGRY);
        uiHudDirty = true;
      }
    }

    T.happyAccSec += dt;
    if (T.happyAccSec >= heartInterval) {
      T.happyAccSec %= heartInterval;
      if (T.happy > 0) {
        T.happy--;
        if (T.happy == 0) tamaRaiseAttention(ATT_HAPPY);
        uiHudDirty = true;
      }
    }

    uint32_t poopInterval = (T.species == SP_BITLING) ? 720UL : 9000UL;
    T.poopAccSec += dt;
    if (T.poopAccSec >= poopInterval) {
      T.poopAccSec %= poopInterval;
      if (T.poopCount < 4) {
        T.poopCount++;
        sfxQuiet(SND_FRAG);
        if (T.poopCount >= 2 && T.sickDosesLeft == 0) tamaInflictSickness(SICK_CORRUPT, 2);
        uiHudDirty = true;
      }
    }

    T.discCallAccSec += dt;
    if (T.discCallAccSec >= 12600UL) {
      T.discCallAccSec = 0;
      if (T.hungry > 0 && T.happy > 0 && T.sickDosesLeft == 0 && T.discipline < 100) {
        tamaRaiseAttention(ATT_DISCIPLINE);
      }
    }
  }

  if (T.sickDosesLeft > 0) {
    T.sickAccSec += dt;
    if (T.sickAccSec >= 14400UL) { tamaKill(1); return; }
  } else {
    T.sickAccSec = 0;
    T.sickType = SICK_NONE;
  }

  uint8_t maxCM = (T.species == SP_ROTBIT) ? 6 : 9;
  if (T.careMistakes >= maxCM) {
    tamaKill(T.ageSec >= 10 * 86400UL ? 3 : 1);
    return;
  }

  tamaCheckEvolutions();

  if (tDirty && (now - tLastSave > 180000UL)) tamaSave();
}

// ----------------------------------------------------------------------------
//  ACTIONS
// ----------------------------------------------------------------------------
void actionFeedMeal() {
  if (T.sleeping || T.sickDosesLeft > 0) { sndPlay(SND_DENY); return; }
  if (T.attnReason == ATT_DISCIPLINE) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  if (T.hungry >= 4) { sndPlay(SND_DENY); return; }
  sndPlay(SND_EAT);
  T.hungry++;
  T.weightOz++;
  jxAward(2);
  triggerEyeChomp();
  if (T.hungry > 0) tamaClearAttention(ATT_HUNGRY);
  uiHudDirty = true;
  tDirty = true;
}

void actionFeedSnack() {
  if (T.sleeping || T.sickDosesLeft > 0) { sndPlay(SND_DENY); return; }
  if (T.attnReason == ATT_DISCIPLINE) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  sndPlay(SND_SNACK);
  if (T.happy < 4) T.happy++;
  T.weightOz += 2;
  T.snackCount++;
  jxAward(1);
  triggerEyeChomp();
  if (T.happy > 0) tamaClearAttention(ATT_HAPPY);
  if (T.snackCount >= 6 && T.sickDosesLeft == 0) tamaInflictSickness(SICK_THERMAL, 2);
  if (T.snackCount >= 12 && T.species <= SP_GLITCHLING) { tamaKill(2); return; }
  uiHudDirty = true;
  tDirty = true;
}

void startNumbersGame() {
  uint8_t minWt = SP_BASE_WT[T.species];
  if (T.sleeping || T.sickDosesLeft > 0) { sndPlay(SND_DENY); return; }
  if (T.attnReason == ATT_DISCIPLINE) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  if (T.happy >= 4 && T.weightOz <= minWt) { sndPlay(SND_DENY); triggerEyeChomp(); return; }
  sndPlay(SND_GAME_START);
  gameRound = 1;
  gameWins = 0;
  gameLeftNum = (uint8_t)random(1, 10);
  gameRightNum = (uint8_t)random(1, 10);
  gameRevealState = 0;
  uiScreen = SCR_GAME_HILO;
  uiNeedsFullRedraw = true;
}

void submitNumbersGuess(bool guessHigher) {
  if (gameRevealState != 0) return;
  gameLastWon = guessHigher ? (gameRightNum > gameLeftNum) : (gameRightNum < gameLeftNum);
  if (gameLastWon) gameWins++;
  sndPlay(gameLastWon ? SND_ROUND_WIN : SND_ROUND_LOSE);
  gameRevealState = 1;
  gameRevealAt = millis();
  uiNeedsFullRedraw = true;
}

void finishNumbersGame() {
  if (gameWins >= 3) sndPlay(SND_FANFARE);
  uint8_t minWt = SP_BASE_WT[T.species];
  if (T.weightOz > minWt) T.weightOz--;
  if (gameWins >= 5) T.happy = min(4, (int)T.happy + 2);
  else if (gameWins >= 3) T.happy = min(4, (int)T.happy + 1);
  if (T.happy > 0) tamaClearAttention(ATT_HAPPY);
  jxAward(gameWins >= 5 ? 5 : (gameWins >= 3 ? 3 : 1));
  uiScreen = SCR_MAIN;
  selIcon = ICON_NONE;
  uiNeedsFullRedraw = true;
  tDirty = true;
}

void executeMenuIcon(uint8_t icon) {
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  switch (icon) {
    case ICON_FEED:
      if (!T.sleeping && T.sickDosesLeft == 0) {
        feedChoice = 0;
        uiScreen = SCR_FEED_MENU;
        uiNeedsFullRedraw = true;
      }
      break;
    case ICON_GAME:
      startNumbersGame();
      break;
    case ICON_CLEAN:
      if (T.poopCount == 0) sndPlay(SND_DENY);
      if (T.poopCount > 0) {
        sndPlay(SND_DEFRAG);
        T.poopCount = 0;
        triggerEyeChomp();
        uiHudDirty = true; tDirty = true;
      }
      break;
    case ICON_LIGHT:
      T.lightsOff = T.lightsOff ? 0 : 1;
      sndPlay(T.lightsOff ? SND_LIGHT_OFF : SND_LIGHT_ON);
      if (T.sleeping && T.lightsOff) tamaClearAttention(ATT_SLEEP);
      uiHudDirty = true; tDirty = true;
      break;
    case ICON_MEDS:
      sndPlay(T.sickDosesLeft > 0 ? SND_PATCH : SND_DENY);
      if (T.sickDosesLeft > 0) {
        T.sickDosesLeft--;
        if (T.sickDosesLeft == 0) T.sickType = SICK_NONE;
        T.snackCount = 0;
        triggerEyeChomp();
        uiHudDirty = true; tDirty = true;
      }
      break;
    case ICON_SCOLD:
      if (T.attnReason == ATT_DISCIPLINE) {
        sndPlay(SND_SCOLD_OK);
        if (T.discipline < 100) T.discipline = min(100, (int)T.discipline + 25);
        tamaClearAttention(ATT_DISCIPLINE);
        triggerEyeChomp();
      } else {
        sndPlay(SND_SCOLD_BAD);
        if (T.happy > 0) T.happy--;
        if (T.happy == 0) tamaRaiseAttention(ATT_HAPPY);
      }
      uiHudDirty = true; tDirty = true;
      break;
    case ICON_STATS:
      uiScreen = SCR_STATS_1;
      uiNeedsFullRedraw = true;
      break;
  }
}

// ----------------------------------------------------------------------------
//  BUTTON LOGIC  (A = cycle/left, B = select/middle, C = back/right, AC = combo)
// ----------------------------------------------------------------------------
void onButtonA() {
  sndPlay(SND_NAV);
  if (uiScreen == SCR_MAIN) {
    if (T.species == SP_EGG) return;
    selIcon = (uint8_t)((selIcon + 1) % ICON_COUNT);
    uiHudDirty = true;
  } else if (uiScreen == SCR_FEED_MENU) {
    feedChoice = (feedChoice + 1) % 2;
    uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_GAME_HILO) {
    if (gameRevealState == 0) submitNumbersGuess(false);
  } else if (uiScreen == SCR_STATS_1) {
    uiScreen = SCR_STATS_2; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_STATS_2) {
    uiScreen = SCR_STATS_1; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_CLOCK) {
    if (clockSetMode) {
      if (clockSetField == 0) T.clockHour = (T.clockHour + 1) % 24;
      else T.clockMin = (T.clockMin + 1) % 60;
      tDirty = true;
      uiNeedsFullRedraw = true;
    } else {
      uiScreen = SCR_MAIN; uiNeedsFullRedraw = true;
    }
  }
}

void onButtonB() {
  sndPlay(SND_SELECT);
  if (uiScreen == SCR_MAIN) {
    if (selIcon == ICON_NONE) {
      clockSetMode = false;
      uiScreen = SCR_CLOCK;
      uiNeedsFullRedraw = true;
    } else {
      executeMenuIcon(selIcon);
    }
  } else if (uiScreen == SCR_FEED_MENU) {
    if (feedChoice == 0) actionFeedMeal();
    else actionFeedSnack();
    if (uiScreen == SCR_FEED_MENU) {
      uiScreen = SCR_MAIN;
      selIcon = ICON_NONE;
      uiNeedsFullRedraw = true;
    }
  } else if (uiScreen == SCR_GAME_HILO) {
    if (gameRevealState == 0) submitNumbersGuess(true);
    else if (gameRevealState == 2) finishNumbersGame();
  } else if (uiScreen == SCR_STATS_1) {
    uiScreen = SCR_STATS_2; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_STATS_2) {
    uiScreen = SCR_MAIN; selIcon = ICON_NONE; uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_CLOCK) {
    if (clockSetMode) {
      clockSetField = (clockSetField + 1) % 2;
      uiNeedsFullRedraw = true;
    } else {
      uiScreen = SCR_MAIN; uiNeedsFullRedraw = true;
    }
  }
}

void onButtonC() {
  sndPlay(SND_BACK);
  if (uiScreen == SCR_MAIN) {
    if (selIcon != ICON_NONE) { selIcon = ICON_NONE; uiHudDirty = true; }
  } else if (uiScreen == SCR_GAME_HILO && gameRevealState == 2) {
    finishNumbersGame();
  } else if (uiScreen != SCR_DEAD) {
    if (uiScreen == SCR_CLOCK && clockSetMode) {
      clockSetMode = false;
      tamaSave();
    }
    uiScreen = SCR_MAIN;
    selIcon = ICON_NONE;
    uiNeedsFullRedraw = true;
  }
}

void onButtonACCombo() {
  if (uiScreen == SCR_CLOCK) {
    clockSetMode = !clockSetMode;
    clockSetField = 0;
    if (!clockSetMode) tamaSave();
    uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_DEAD || T.species == SP_DEAD) {
    sndPlay(SND_NEWEGG);
    tamaFreshEgg();
    tamaSave();
    uiScreen = SCR_MAIN;
    selIcon = ICON_NONE;
    uiNeedsFullRedraw = true;
  } else if (uiScreen == SCR_MAIN) {
    clockSetMode = true;
    clockSetField = 0;
    uiScreen = SCR_CLOCK;
    uiNeedsFullRedraw = true;
  }
}

// ----------------------------------------------------------------------------
//  HARDWARE: I2C helpers
// ----------------------------------------------------------------------------
void i2cScan(TwoWire &w, const char* name) {
  Serial.printf("I2C scan (%s):", name);
  uint8_t found = 0;
  for (uint8_t a = 1; a < 127; a++) {
    w.beginTransmission(a);
    if (w.endTransmission() == 0) { Serial.printf(" 0x%02X", a); found++; }
  }
  if (!found) Serial.print(" (none)");
  Serial.println();
}

// ----------------------------------------------------------------------------
//  TOUCH: CST816D (I2C 0x15 on IIC_SDA/IIC_SCL, reset TP_RST, int TP_INT)
// ----------------------------------------------------------------------------
TwoWire* tpWire = &Wire;
bool tpOk = false;
bool touchDebug = false;

bool i2cProbe(TwoWire &w, uint8_t addr) {
  w.beginTransmission(addr);
  return w.endTransmission() == 0;
}

void touchBegin() {
  tpWire = &Wire;
  pinMode(TP_RST, OUTPUT);               // hardware reset of the touch controller
  digitalWrite(TP_RST, LOW);  delay(10);
  digitalWrite(TP_RST, HIGH); delay(60);
  tpOk = i2cProbe(Wire, TP_ADDR);
  if (tpOk) {
    tpWire->beginTransmission(TP_ADDR);   // disable auto-sleep so touch always answers
    tpWire->write(0xFE);
    tpWire->write(0x01);
    tpWire->endTransmission();
    Serial.println("Touch CST816D OK (0x15)");
  } else {
    Serial.println("WARN: CST816D (0x15) not found - use BOOT button instead");
  }
  pinMode(TP_INT_PIN, INPUT_PULLUP);
}

// returns true if a finger is down; px,py in panel-native coords (x 0..239, y 0..283)
bool touchRead(int16_t &px, int16_t &py) {
  if (!tpOk) return false;
  tpWire->beginTransmission(TP_ADDR);
  tpWire->write(0x01);
  if (tpWire->endTransmission() != 0) return false;
  if (tpWire->requestFrom((uint8_t)TP_ADDR, (uint8_t)6) != 6) return false;
  uint8_t b[6];
  for (uint8_t i = 0; i < 6; i++) b[i] = tpWire->read();
  if (b[1] == 0) return false;
  int16_t x = ((b[2] & 0x0F) << 8) | b[3];
  int16_t y = ((b[4] & 0x0F) << 8) | b[5];
#if JG_TOUCH_SWAP_XY
  { int16_t t = x; x = y; y = t; }
#endif
#if JG_TOUCH_FLIP_X
  x = PW - 1 - x;
#endif
#if JG_TOUCH_FLIP_Y
  y = PH - 1 - y;
#endif
  px = constrain(x, 0, PW - 1);
  py = constrain(y, 0, PH - 1);
  return true;
}

// panel-native -> logical (rotated) coordinates; matches Arduino_Canvas rotation
void touchToLogical(int16_t px, int16_t py, int16_t &lx, int16_t &ly) {
  if (JG_ROTATION == 1) { lx = py;          ly = PW - 1 - px; }
  else                  { lx = PH - 1 - py; ly = px; }
}

struct TouchState {
  bool down = false;
  uint32_t downAt = 0;
  uint8_t zone = 0;        // 1=A 2=B 3=C 9=consumed
  bool comboFired = false;
  uint32_t lastPoll = 0;
  uint8_t missed = 0;
} tp;

void serviceTouch() {
  uint32_t now = millis();
  if (now - tp.lastPoll < 20) return;
  tp.lastPoll = now;

  int16_t px, py;
  bool pressed = touchRead(px, py);

  if (pressed) {
    tp.missed = 0;
    int16_t lx, ly;
    touchToLogical(px, py, lx, ly);
    if (touchDebug) Serial.printf("TOUCH raw=%d,%d logical=%d,%d\n", px, py, lx, ly);

    if (!tp.down) {
      tp.down = true;
      tp.downAt = now;
      tp.zone = 0;
      tp.comboFired = false;

      bool titleTap = (uiScreen == SCR_MAIN && ly < ICON_Y - 8);     // tap the title row = volume
      if (titleTap) {
        sndCycleLevel(); volShownAt = millis(); uiHudDirty = true; tp.zone = 9;
      } else if (uiScreen == SCR_MAIN) {
        triggerSmashAt(lx, ly);
      }
      bool iconBand = (ly >= ICON_Y - 6 && ly <= ICON_Y + ICON_H + 8 &&
                       lx >= ICON_X0 - 4 && lx < ICON_X0 + ICON_W * 7 + 4);
      if (!titleTap && uiScreen == SCR_MAIN && iconBand && T.species != SP_EGG && T.species != SP_DEAD) {
        int16_t cell = (lx - ICON_X0) / ICON_W;
        uint8_t picked = (uint8_t)constrain(cell, 0, 6) + 1;
        if (selIcon == picked) executeMenuIcon(picked);
        else { selIcon = picked; uiHudDirty = true; sndPlay(SND_NAV); }
        tp.zone = 9;
      } else if (!titleTap && ly >= BTN_Y - 10) {
        tp.zone = (lx < SW / 3) ? 1 : ((lx < (2 * SW) / 3) ? 2 : 3);
        if (tp.zone == 1) onButtonA();
        else if (tp.zone == 3) onButtonC();
      }
    } else if (tp.zone == 2 && !tp.comboFired && now - tp.downAt >= 1100) {
      tp.comboFired = true;              // long-press middle button = A+C combo
      onButtonACCombo();
    }
  } else if (tp.down) {
    if (++tp.missed >= 2) {              // tolerate one dropped read
      if (tp.zone == 2 && !tp.comboFired) onButtonB();
      tp.down = false;
      tp.missed = 0;
    }
  }
}

// ----------------------------------------------------------------------------
//  BOOT BUTTON (GPIO0):  tap=A   double-tap=B   hold 0.55s=C   hold 1.4s=A+C
// ----------------------------------------------------------------------------
uint32_t btnPressAt = 0, btnShortAt = 0, btnDebounceAt = 0, lastBtnPoll = 0;
bool btnShortPending = false, btnRawPressed = false, btnStablePressed = false;

void serviceBootButton() {
  uint32_t now = millis();
  if (btnShortPending && now - btnShortAt >= 320) {
    btnShortPending = false;
    triggerSmash(-1, 0);
    onButtonA();
  }
  if (now - lastBtnPoll < 10) return;
  lastBtnPoll = now;

  bool pressed = (digitalRead(BOOT_BTN) == LOW);
  if (pressed != btnRawPressed) { btnRawPressed = pressed; btnDebounceAt = now; }

  if (now - btnDebounceAt >= 30 && btnStablePressed != btnRawPressed) {
    btnStablePressed = btnRawPressed;
    if (btnStablePressed) {
      btnPressAt = now;
    } else {
      uint32_t held = now - btnPressAt;
      if (held >= 1400) { btnShortPending = false; onButtonACCombo(); }
      else if (held >= 550) { btnShortPending = false; triggerSmash(1, 0); onButtonC(); }
      else {
        if (btnShortPending && now - btnShortAt < 320) { btnShortPending = false; triggerSmash(0, 1); onButtonB(); }
        else { btnShortPending = true; btnShortAt = now; }
      }
    }
  }
}

// ----------------------------------------------------------------------------
//  DRAWING HELPERS (round-screen aware)
// ----------------------------------------------------------------------------
void ctext(int16_t y, const char* s, uint8_t size, uint16_t fg, uint16_t bg) {
  int16_t w = (int16_t)strlen(s) * 6 * size;
  gfx->setTextSize(size);
  gfx->setTextColor(fg, bg);
  gfx->setCursor((SW - w) / 2, y);
  gfx->print(s);
}

void ctextIn(int16_t x0, int16_t w, int16_t y, const char* s, uint8_t size, uint16_t fg, uint16_t bg) {
  int16_t tw = (int16_t)strlen(s) * 6 * size;
  gfx->setTextSize(size);
  gfx->setTextColor(fg, bg);
  gfx->setCursor(x0 + (w - tw) / 2, y);
  gfx->print(s);
}

void drawHeartRow(int16_t x, int16_t y, uint8_t count) {
  for (uint8_t i = 0; i < 4; i++) {
    uint16_t col = (i < count) ? COL_ACCENT : COL_DIM;
    int16_t hx = x + i * 18;
    gfx->fillCircle(hx + 3, y + 3, 3, col);
    gfx->fillCircle(hx + 9, y + 3, 3, col);
    gfx->fillTriangle(hx, y + 4, hx + 12, y + 4, hx + 6, y + 11, col);
  }
}

void drawButtons(const char* a, const char* b, const char* c) {
  gfx->fillRect(0, BTN_Y - 6, SW, SH - (BTN_Y - 6), COL_BG);
  const int16_t bw = 84, gap = 4;
  int16_t x0 = (SW - (3 * bw + 2 * gap)) / 2;
  const char* lbl[3] = {a, b, c};
  for (uint8_t i = 0; i < 3; i++) {
    int16_t bx = x0 + i * (bw + gap);
    gfx->fillRoundRect(bx, BTN_Y, bw, BTN_H, 5, COL_PANEL);
    gfx->drawRoundRect(bx, BTN_Y, bw, BTN_H, 5, i == 1 ? COL_ACCENT : COL_DIM);
    ctextIn(bx, bw, BTN_Y + 3, lbl[i], 2, i == 1 ? COL_WHITE : COL_SILVER, COL_PANEL);
  }
}

void drawMainHud() {
  static const char* const ICON_LBL[ICON_COUNT]  = { "", "FD", "GM", "DF", "LT", "PT", "SC", "ST" };
  static const char* const ICON_FULL[ICON_COUNT] = { "", "FEED", "GAME", "DFRAG", "LIGHT", "PATCH", "SCOLD", "STATS" };

  gfx->fillRect(0, 0, SW, 57, COL_BG);
#if JG_SOUND
  if (volShownAt) {
    char vb[24];
    if (sndLevelPct() == 0) snprintf(vb, sizeof(vb), "SOUND: MUTE");
    else                    snprintf(vb, sizeof(vb), "VOLUME %u%%", sndLevelPct());
    ctext(6, vb, 2, COL_WHITE, COL_BG);
  } else
#endif
  if (selIcon != ICON_NONE) ctext(6, ICON_FULL[selIcon], 2, COL_WHITE, COL_BG);
  else                      ctext(6, "JITTERGOTCHI", 2, COL_SILVER, COL_BG);

  gfx->fillRoundRect(ICON_X0 - 2, ICON_Y - 2, ICON_W * 7 + 4, ICON_H + 4, 6, COL_PANEL);
  for (uint8_t i = 1; i < ICON_COUNT; i++) {
    int16_t ix = ICON_X0 + (i - 1) * ICON_W;
    bool active = (selIcon == i);
    uint16_t bg = active ? COL_ACCENT : COL_PANEL;
    if (active) gfx->fillRoundRect(ix + 1, ICON_Y, ICON_W - 2, ICON_H, 4, COL_ACCENT);
    ctextIn(ix, ICON_W, ICON_Y + 5, ICON_LBL[i], 2, active ? COL_WHITE : COL_SILVER, bg);
  }

  gfx->fillRect(0, EYE_CLIP_Y1 + 1, SW, BTN_Y - EYE_CLIP_Y1 - 7, COL_BG);
  char buf[40];

  if (evoDanceActive && evoBanner[0]) {
    snprintf(buf, sizeof(buf), "EVOLVED:%s!", evoBanner);
    ctext(176, buf, 2, JC_YELLOW, COL_BG);
  } else if (T.species == SP_EGG) {
    uint32_t rem = (T.stageSec < 300) ? (300 - T.stageSec) : 0;
    ctext(154, "CYBER-EGG", 2, COL_SILVER, COL_BG);
    snprintf(buf, sizeof(buf), "HATCH IN %lum %02lus", (unsigned long)(rem / 60), (unsigned long)(rem % 60));
    ctext(176, buf, 2, COL_WHITE, COL_BG);
    snprintf(buf, sizeof(buf), "TIME %02u:%02u (%ux)", T.clockHour, T.clockMin, T.timeScale);
    ctext(202, buf, 1, COL_SILVER, COL_BG);
  } else {
    if (T.attnReason != ATT_NONE) {
      static const char* const ATT_TXT[5] = {"", "CALL:HUNGRY!", "CALL:BORED!", "CALL:LIGHTS!", "CALL:SCOLD!"};
      int16_t w = (int16_t)strlen(ATT_TXT[T.attnReason]) * 12 + 12;
      gfx->fillRoundRect((SW - w) / 2, 150, w, 20, 4, COL_ACCENT);
      ctext(153, ATT_TXT[T.attnReason], 2, COL_WHITE, COL_ACCENT);
    } else if (T.sleeping) {
      ctext(153, "SLEEPING Zzz", 2, COL_SILVER, COL_BG);
    } else {
      snprintf(buf, sizeof(buf), "WT %uoz DSC %u%%", T.weightOz, T.discipline);
      ctext(153, buf, 2, COL_SILVER, COL_BG);
    }

    gfx->setTextSize(2);
    gfx->setTextColor(COL_SILVER, COL_BG);
    gfx->setCursor(20, 171);   gfx->print("HNG");
    drawHeartRow(60, 172, T.hungry);
    gfx->setCursor(150, 171);  gfx->print("HAP");
    drawHeartRow(190, 172, T.happy);

    snprintf(buf, sizeof(buf), "%-11s %02u:%02u", SP_NAME[T.species], T.clockHour, T.clockMin);
    ctext(189, buf, 2, COL_WHITE, COL_BG);

    gfx->setTextSize(1);
    gfx->setTextColor(COL_AMBER, COL_BG);
    gfx->setCursor(20, 207);
    gfx->printf("XP:%lu", (unsigned long)Jx.v);
    if (T.poopCount > 0) {
      gfx->setTextColor(COL_AMBER, COL_BG);
      gfx->setCursor(90, 207);
      gfx->printf("FRAG:%u", T.poopCount);
    }
    if (T.sickDosesLeft > 0) {
      uint8_t st = (T.sickType >= SICK_CORRUPT && T.sickType <= SICK_MALWARE) ? T.sickType : SICK_CORRUPT;
      uint16_t badgeCol = (st == SICK_THERMAL) ? 0xC240 : ((st == SICK_MALWARE) ? 0x8010 : COL_ACCENT);
      gfx->fillRect(140, 204, 46, 12, badgeCol);
      gfx->setTextColor(COL_WHITE, badgeCol);
      gfx->setCursor(143, 207);
      gfx->printf("%s:%u", SICK_BADGE_TXT[st], T.sickDosesLeft);
    }
    uint16_t lbg = T.lightsOff ? 0x18E3 : COL_CRIMSON;
    gfx->fillRect(206, 204, 58, 12, lbg);
    gfx->setTextColor(T.lightsOff ? COL_SILVER : COL_WHITE, lbg);
    gfx->setCursor(212, 207);
    gfx->print(T.lightsOff ? "LITE:OFF" : "LITE:ON");
  }

  drawButtons("ICON", selIcon == ICON_NONE ? "TIME" : "PICK", "CLEAR");
  frameDirty = true;
}

void drawSubScreen() {
  gfx->fillScreen(COL_BG);
  char buf[40];

  if (uiScreen == SCR_FEED_MENU) {
    ctext(8, "FEED UNIT", 2, COL_ACCENT, COL_BG);
    static const char* const OPT[2] = {"PACKET +1HNG", "OVERCLK +1HAP"};
    static const char* const SUB[2] = {"+1 WEIGHT", "+2 WEIGHT"};
    for (uint8_t i = 0; i < 2; i++) {
      int16_t y = 40 + i * 64;
      if (feedChoice == i) gfx->fillRoundRect(30, y, 224, 50, 6, COL_ACCENT);
      else                 gfx->drawRoundRect(30, y, 224, 50, 6, COL_DIM);
      uint16_t bg = (feedChoice == i) ? COL_ACCENT : COL_BG;
      ctext(y + 9,  OPT[i], 2, (feedChoice == i) ? COL_WHITE : COL_SILVER, bg);
      ctext(y + 31, SUB[i], 1, (feedChoice == i) ? COL_WHITE : COL_DIM, bg);
    }
    drawButtons("NEXT", "FEED", "BACK");

  } else if (uiScreen == SCR_GAME_HILO) {
    snprintf(buf, sizeof(buf), "HI-LO %u/5", gameRound);
    ctext(6, buf, 2, COL_ACCENT, COL_BG);
    snprintf(buf, sizeof(buf), "WINS %u", gameWins);
    ctext(28, buf, 1, COL_SILVER, COL_BG);
    ctext(42, "IS THE RIGHT DIGIT LOWER OR HIGHER?", 1, COL_SILVER, COL_BG);

    gfx->drawRoundRect(34, 58, 94, 100, 8, COL_ACCENT);
    gfx->drawRoundRect(156, 58, 94, 100, 8, COL_SILVER);
    snprintf(buf, sizeof(buf), "%u", gameLeftNum);
    ctextIn(34, 94, 90, buf, 6, COL_WHITE, COL_BG);
    if (gameRevealState == 0) {
      ctextIn(156, 94, 90, "?", 6, COL_ACCENT, COL_BG);
    } else {
      snprintf(buf, sizeof(buf), "%u", gameRightNum);
      ctextIn(156, 94, 90, buf, 6, gameLastWon ? JC_GREEN : JC_RED, COL_BG);
    }

    if (gameRevealState == 2) {
      snprintf(buf, sizeof(buf), "SCORE %u/5 %s", gameWins, gameWins >= 5 ? "+2HAP" : (gameWins >= 3 ? "+1HAP" : "+0HAP"));
      ctext(176, buf, 2, JC_YELLOW, COL_BG);
      drawButtons("--", "DONE", "EXIT");
    } else {
      drawButtons("LOW", "HIGH", "QUIT");
    }

  } else if (uiScreen == SCR_STATS_1) {
    ctext(6, "STATUS", 2, COL_ACCENT, COL_BG);
    ctext(28, SP_NAME[T.species], 2, COL_SILVER, COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE, COL_BG);
    gfx->setCursor(20, 58);   gfx->printf("AGE  : %lu yr", (unsigned long)(T.ageSec / 86400UL));
    gfx->setCursor(20, 86);   gfx->printf("WT %u oz (MIN %u)", T.weightOz, SP_BASE_WT[T.species]);
    gfx->setCursor(20, 114);  gfx->printf("DISC : %u%%", T.discipline);
    gfx->setCursor(20, 142);  gfx->printf("CM/DM: %u / %u", T.careMistakes, T.discMistakes);
    uint8_t st = (T.sickDosesLeft > 0 && T.sickType <= SICK_MALWARE) ? T.sickType : SICK_NONE;
    gfx->setCursor(20, 170);  gfx->printf("STATE: %s", SICK_FULL_NAME[st]);
    drawButtons("PG2", "PG2", "FACE");

  } else if (uiScreen == SCR_STATS_2) {
    ctext(6, "HUNGRY & HAPPY", 2, COL_ACCENT, COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE, COL_BG);
    gfx->setCursor(20, 44);   gfx->printf("HUNGRY %u/4", T.hungry);
    drawHeartRow(170, 46, T.hungry);
    gfx->setCursor(20, 74);   gfx->printf("HAPPY  %u/4", T.happy);
    drawHeartRow(170, 76, T.happy);
    gfx->setCursor(20, 104);  gfx->printf("RF EXP %lu", (unsigned long)T.rfSignals);
    gfx->setTextSize(1);
    gfx->setTextColor(COL_SILVER, COL_BG);
    snprintf(buf, sizeof(buf), "SPEED:%ux  FRAG:%u/4  STAGE:%lum", T.timeScale, T.poopCount, (unsigned long)(T.stageSec / 60));
    ctext(150, buf, 1, COL_SILVER, COL_BG);
    snprintf(buf, sizeof(buf), "ID:%08lX  SAVE:NVS", (unsigned long)T.id);
    ctext(166, buf, 1, COL_SILVER, COL_BG);
    drawButtons("PG1", "FACE", "FACE");

  } else if (uiScreen == SCR_CLOCK) {
    ctext(12, clockSetMode ? "CLOCK SET [PAUSED]" : "SYSTEM CLOCK", 2, COL_ACCENT, COL_BG);
    snprintf(buf, sizeof(buf), "%02u:%02u:%02u", T.clockHour, T.clockMin, T.clockSec);
    ctext(50, buf, 5, clockSetMode ? JC_YELLOW : COL_WHITE, COL_BG);
    if (clockSetMode) {
      int16_t ux = (clockSetField == 0) ? 22 : 112;
      gfx->fillRect(ux, 94, 60, 4, COL_ACCENT);
      ctext(114, clockSetField == 0 ? "EDITING: HOUR  (AGING FROZEN)" : "EDITING: MINUTE (AGING FROZEN)", 1, COL_SILVER, COL_BG);
      ctext(130, "HOLD [B] 1s OR TAP [C] TO RESUME", 1, COL_SILVER, COL_BG);
      drawButtons("+1", "H/M", "RUN");
    } else {
      ctext(114, "HOLD [B] 1s TO SET THE CLOCK", 1, COL_SILVER, COL_BG);
      drawButtons("FACE", "FACE", "FACE");
    }

  } else if (uiScreen == SCR_DEAD) {
    ctext(10, "SIGNAL LOST", 2, COL_ACCENT, COL_BG);
    ctext(32, "TERMINATED", 2, COL_ACCENT, COL_BG);
    gfx->setTextSize(2);
    gfx->setTextColor(COL_WHITE, COL_BG);
    gfx->setCursor(20, 70);   gfx->printf("UNIT : %s", SP_NAME[T.species]);
    gfx->setCursor(20, 98);   gfx->printf("AGE  : %lu yr", (unsigned long)(T.ageSec / 86400UL));
    const char* causeStr = (T.deathCause == 2) ? "THERMAL" : (T.deathCause == 3 ? "OLD AGE" : "CORRUPT");
    gfx->setCursor(20, 126);  gfx->printf("CAUSE: %s", causeStr);
    ctext(170, "HOLD [B] 1s FOR A NEW CYBER-EGG", 1, JC_YELLOW, COL_BG);
    drawButtons("--", "NEW", "--");
  }
  frameDirty = true;
}

void serviceDisplay() {
  if (volShownAt && millis() - volShownAt >= 1500) { volShownAt = 0; uiHudDirty = true; }
  if (uiScreen == SCR_GAME_HILO && gameRevealState == 1) {
    if (millis() - gameRevealAt >= 950) {
      if (gameRound < 5) {
        gameRound++;
        gameLeftNum = (uint8_t)random(1, 10);
        gameRightNum = (uint8_t)random(1, 10);
        gameRevealState = 0;
      } else {
        gameRevealState = 2;
      }
      uiNeedsFullRedraw = true;
    }
  }

  if (uiNeedsFullRedraw) {
    uiNeedsFullRedraw = false;
    if (uiScreen == SCR_MAIN) {
      gfx->fillScreen(COL_BG);
      staticN = 0;
      eyeHasLastDraw = false;
      drawMainHud();
      uiHudDirty = false;
    } else {
      drawSubScreen();
    }
  } else if (uiScreen == SCR_MAIN && uiHudDirty) {
    uiHudDirty = false;
    drawMainHud();
  }

  if (uiScreen == SCR_MAIN) serviceEyes();

  // Clock screen shows live seconds
  static uint8_t lastSecDrawn = 255;
  if (uiScreen == SCR_CLOCK && !clockSetMode && lastSecDrawn != T.clockSec) {
    lastSecDrawn = T.clockSec;
    uiNeedsFullRedraw = true;
  }

  uint32_t now = millis();
  if (frameDirty && now - lastFlushMs >= 25) {
    gfx->flush();
    frameDirty = false;
    lastFlushMs = now;
  }

  // Backlight: dim when the pet sleeps with the lights off
  backlightSet((T.sleeping && T.lightsOff && T.species != SP_DEAD) ? 25 : 255);
}

void printTamaStatusSerial() {
  uint8_t st = (T.sickDosesLeft > 0 && T.sickType <= SICK_MALWARE) ? T.sickType : SICK_NONE;
  Serial.printf(
    "JITTER:id=%08lX;species=%s;age_yr=%lu;stage_s=%lu;hng=%u;hap=%u;wt=%u;"
    "disc=%u;cm=%u;dm=%u;frag=%u;sick=%u;sick_type=%s;sleep=%u;lights_off=%u;paused=%u;"
    "scale=%u;clock=%02u:%02u;rf=%lu;xp=%lu\n",
    (unsigned long)T.id, SP_NAME[T.species], (unsigned long)(T.ageSec / 86400UL),
    (unsigned long)T.stageSec, T.hungry, T.happy, T.weightOz, T.discipline,
    T.careMistakes, T.discMistakes, T.poopCount, T.sickDosesLeft, SICK_FULL_NAME[st],
    T.sleeping, T.lightsOff, (uiScreen == SCR_CLOCK && clockSetMode) ? 1 : 0, T.timeScale,
    T.clockHour, T.clockMin, (unsigned long)T.rfSignals, (unsigned long)Jx.v
  );
}

// ----------------------------------------------------------------------------
//  WI-FI "FOOD": passive scans -> RF signals (async, never blocks the UI)
// ----------------------------------------------------------------------------
#if JG_WIFI_FOOD
uint32_t lastScanStart = 0;
bool scanRunning = false;

// Foraging memory (RAM only, forgotten on reboot): a short hash of each network's
// hardware address + when it last paid out. No names or addresses are kept.
struct Seen { uint32_t h; uint32_t at; };
static Seen seenTab[64];
static uint8_t seenN = 0;

static uint32_t hashBssid(const uint8_t* b) {
  uint32_t h = 2166136261u;
  for (uint8_t i = 0; i < 6; i++) { h ^= b[i]; h *= 16777619u; }
  return h ? h : 1;
}
// true if this network is new (or its payout has expired); records it
static bool forageIsFresh(uint32_t h, uint32_t now) {
  int oldest = 0;
  for (uint8_t i = 0; i < seenN; i++) {
    if (seenTab[i].h == h) {
      if (now - seenTab[i].at >= JG_FORAGE_MS) { seenTab[i].at = now; return true; }
      return false;
    }
    if (now - seenTab[i].at > now - seenTab[oldest].at) oldest = i;
  }
  if (seenN < 64) seenTab[seenN++] = Seen{h, now};
  else            seenTab[oldest] = Seen{h, now};
  return true;
}

void serviceWifiFood() {
  uint32_t now = millis();
  if (!scanRunning) {
    if (now - lastScanStart >= JG_WIFI_SCAN_MS) {
      lastScanStart = now;
      WiFi.scanNetworks(true /*async*/, true /*show hidden*/);
      scanRunning = true;
    }
    return;
  }
  int n = WiFi.scanComplete();
  if (n == WIFI_SCAN_RUNNING) return;
  scanRunning = false;
  if (n > 0) {
#if JG_WIFI_HARD
    uint32_t now2 = millis();
    int fresh = 0;
    for (int i = 0; i < n; i++) {
      uint8_t* b = WiFi.BSSID(i);
      if (b && forageIsFresh(hashBssid(b), now2)) fresh++;
    }
    if (fresh > 0) {
      triggerEyeRfRx();
      rewardRfSignalActivity((uint8_t)min(fresh, 8));
    }
    Serial.printf("WIFI: %d networks, %d new -> +%d signal\n", n, fresh, min(fresh, 8));
#else
    triggerEyeRfRx();
    rewardRfSignalActivity((uint8_t)min(n, 8));
    Serial.printf("WIFI: %d networks -> +%d signal\n", n, min(n, 8));
#endif
  }
  WiFi.scanDelete();
}
#endif

// ----------------------------------------------------------------------------
//  SERIAL (same binary protocol as JitterBox6 'J' and 'Y' commands + a few
//  human-friendly lowercase debug keys)
// ----------------------------------------------------------------------------
int serialReadTimeout(uint32_t ms = 100) {
  uint32_t t0 = millis();
  while (!Serial.available() && millis() - t0 < ms) delay(1);
  return Serial.available() ? Serial.read() : -1;
}

void serviceSerial() {
  if (!Serial.available()) return;
  uint8_t cmd = Serial.read();

  if (cmd == 'J') {
    int sub = serialReadTimeout();
    if (sub < 0) { Serial.write('E'); return; }
    if (sub == 'S') printTamaStatusSerial();
    else if (sub == 'A') { onButtonA(); Serial.write('K'); }
    else if (sub == 'B') { onButtonB(); Serial.write('K'); }
    else if (sub == 'C') { onButtonC(); Serial.write('K'); }
    else if (sub == 'P') { onButtonACCombo(); Serial.write('K'); }
    else if (sub == 'I') { triggerEyeIrBlast(); Serial.write('K'); }
    else if (sub == 'T') {
      T.timeScale = (T.timeScale == 1) ? 10 : ((T.timeScale == 10) ? 60 : 1);
      uiHudDirty = true; tDirty = true;
      Serial.write('K');
    } else if (sub == 'X') {
      int k = serialReadTimeout();
      if (k == 0xA5) {
        tamaFreshEgg(); tamaSave();
        uiScreen = SCR_MAIN; selIcon = ICON_NONE; uiNeedsFullRedraw = true;
        Serial.write('K');
      } else Serial.write('E');
    } else Serial.write('E');
  } else if (cmd == 'Y') {
    // "Y<xp>\n" from JitterFood
    uint32_t t0 = millis(), xp = 0;
    while (millis() - t0 < 100) {
      if (!Serial.available()) { delay(1); continue; }
      char c = Serial.peek();
      if (c < '0' || c > '9') { Serial.read(); break; }
      xp = xp * 10 + (uint32_t)(Serial.read() - '0');
    }
    if (xp > 5000) xp = 5000;
    jxAward(xp);
    Serial.write('K');
  } else if (cmd == 'I') {
    triggerEyeIrBlast();
    Serial.write('K');
  } else if (cmd == 's') {
    printTamaStatusSerial();
  } else if (cmd == 'd') {
    touchDebug = !touchDebug;
    Serial.printf("touch debug %s\n", touchDebug ? "ON" : "OFF");
  } else if (cmd == 'r') {
    triggerEyeRfRx();
    rewardRfSignalActivity(25);
    Serial.println("simulated 25 RF signals");
  } else if (cmd == 'i') {
    i2cScan(Wire, "system bus");
  } else if (cmd == 'k') {                       // test the smash: left, right, down, up
    static uint8_t kd = 0; static const int8_t D[4][2] = {{-1,0},{1,0},{0,1},{0,-1}};
    triggerSmash(D[kd][0], D[kd][1]); kd = (kd + 1) % 4;
  }
#if JG_SOUND
  else if (cmd == 't') {                         // play every sound in turn
    static uint8_t tid = 0;
    Serial.printf("sound %u: %s\n", tid, SND_NAMES[tid]);
    sndPlay(tid); tid = (tid + 1) % SND_COUNT;
  } else if (cmd == 'v') {
    sndCycleLevel(); Serial.printf("volume %u%%\n", sndLevelPct());
  }
#endif
}

// repeat an unanswered alert every JG_SND_REMIND_MS (never for the bedtime call, never while asleep)
void serviceAlertReminder() {
  if (T.attnReason == ATT_NONE || T.attnReason == ATT_SLEEP || T.sleeping) return;
  if (T.species == SP_EGG || T.species == SP_DEAD) return;
  if (millis() - alertAt >= JG_SND_REMIND_MS) { alertAt = millis(); playAlert(T.attnReason); }
}

// ----------------------------------------------------------------------------
//  SETUP / LOOP
// ----------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);
  uint32_t t0 = millis();
  while (!Serial && millis() - t0 < 1500) delay(10);
  Serial.println("\nJITTERGOTCHI booting (Waveshare ESP32-S3-Touch-LCD-1.83)");

  pinMode(BOOT_BTN, INPUT_PULLUP);
  backlightInit();
  backlightSet(0);                       // stay dark until the first frame is ready

  Wire.begin(IIC_SDA, IIC_SCL);
  Wire.setClock(400000);
  Wire.setTimeOut(50);
  i2cScan(Wire, "system bus");

  touchBegin();
  sndInit();

  if (!gfx->begin()) {
    Serial.println("ERROR: display init failed (is PSRAM set to OPI?)");
  }
  gfx->setRotation(JG_ROTATION);
  gfx->setTextWrap(false);
  // quick R/G/B colour test so you can see the panel is alive
  { const uint16_t c[3] = { 0xF800, 0x07E0, 0x001F };
    for (uint8_t i = 0; i < 3; i++) { gfx->fillScreen(c[i]); gfx->flush(); if (i == 0) backlightSet(255); delay(250); } }
  gfx->fillScreen(COL_BG);
  gfx->flush();

  tamaLoad();
  jxLoad();
  initEyes();
  uiNeedsFullRedraw = true;

#if JG_WIFI_FOOD
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  lastScanStart = millis() - JG_WIFI_SCAN_MS + 8000;   // first scan ~8s after boot
#endif

  serviceDisplay();
  backlightSet(255);
  sndPlay(SND_BOOT);
  Serial.printf("Ready. species=%s PSRAM=%u bytes free\n", SP_NAME[T.species], (unsigned)ESP.getFreePsram());
}

void loop() {
  serviceSerial();
  serviceTouch();
  serviceBootButton();
  tamaService();
  serviceDisplay();
  serviceAlertReminder();
#if JG_WIFI_FOOD
  serviceWifiFood();
#endif

  // batch XP saves (flash wear) and save pet when it matters
  if (jxDirty && millis() - jxLastSave > 60000UL) jxSave();
}
