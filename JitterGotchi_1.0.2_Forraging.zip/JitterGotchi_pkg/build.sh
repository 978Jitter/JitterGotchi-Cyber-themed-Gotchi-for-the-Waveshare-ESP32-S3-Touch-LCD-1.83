#!/usr/bin/env bash
# Compile only (no board needed).
set -e
cd "$(dirname "$0")"
source ./config.sh
ensure_core
arduino-cli compile --fqbn "$FQBN" "$SKETCH_DIR"
