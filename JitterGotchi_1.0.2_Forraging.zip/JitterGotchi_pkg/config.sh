# Shared settings for the helper scripts (edit only if you know why)
export PATH="$HOME/.local/bin:$PATH"
SKETCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/JitterGotchi"
# ESP32-S3R8 (Waveshare 1.83), 16MB flash, 8MB octal PSRAM, native USB serial (HWCDC) for logging
FQBN="esp32:esp32:esp32s3:USBMode=hwcdc,CDCOnBoot=cdc,PSRAM=opi,FlashMode=qio,FlashSize=16M,PartitionScheme=app3M_fat9M_16MB"

# GFX Library 1.6.9 does not build on ESP32 core 4.x -> keep core 3.3.5
CORE_VER="3.3.5"
ensure_core() {
  local cur
  cur="$(arduino-cli core list 2>/dev/null | awk '$1=="esp32:esp32"{print $2}')"
  if [ "$cur" != "$CORE_VER" ]; then
    echo "==> ESP32 core is '${cur:-none}', installing $CORE_VER"
    arduino-cli core install "esp32:esp32@$CORE_VER"
  fi
}
